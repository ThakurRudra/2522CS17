# Escrow state machine

Student: Rudra Pratap Singh (2522CS17) · Assignment 7

![state machine](state_machine.png)

```mermaid
stateDiagram-v2
    [*] --> Created : constructor(buyer, seller, arbiter, price, timeout)
    Created --> Funded : fund() [buyer, msg.value == price]
    Created --> Cancelled : approveCancel() by buyer AND seller
    Funded --> Released : release() [buyer] -> credit seller
    Funded --> Disputed : raiseDispute() [buyer or seller]
    Disputed --> ResolvedToBuyer : resolveToBuyer() [arbiter] / claimAfterTimeout() [buyer, now >= disputedAt + timeout]
    Disputed --> ResolvedToSeller : resolveToSeller() [arbiter]
    Released --> [*]
    ResolvedToBuyer --> [*]
    ResolvedToSeller --> [*]
    Cancelled --> [*]
```

| State | Permitted transitions (required table) | Implemented by |
|---|---|---|
| Created | Funded or Cancelled | `fund()`, `approveCancel()` ×2 |
| Funded | Released or Disputed | `release()`, `raiseDispute()` |
| Disputed | ResolvedToBuyer or ResolvedToSeller | `resolveToBuyer()`, `claimAfterTimeout()`, `resolveToSeller()` |
| Released, ResolvedToBuyer, ResolvedToSeller, Cancelled | none (terminal) | every transition reverts `InvalidState(current)` |

`withdraw()` is not a state transition: it pays out a credit recorded by `release`/`resolve*`
(pull payment) and is the only function that sends ETH.
Each (function × state × caller) combination outside this table is covered by a unit test that expects the
corresponding custom error (`test/Escrow.t.sol`), and the invariant suite drives random call sequences.
