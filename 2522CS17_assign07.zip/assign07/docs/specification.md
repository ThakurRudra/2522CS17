# Escrow — specification (written before the Solidity code)

Student: Rudra Pratap Singh (2522CS17) · Assignment 7

## Parties and parameters (fixed at deployment, `immutable`)
| name | meaning | constraints |
|---|---|---|
| `buyer` | pays into escrow | non-zero |
| `seller` | is paid on release / seller-favoured resolution | non-zero, ≠ buyer |
| `arbiter` | resolves disputes, never receives funds | non-zero, ≠ buyer, ≠ seller |
| `price` | exact amount (wei) the buyer must deposit | > 0 |
| `disputeTimeout` | seconds the arbiter has to resolve a dispute (stretch goal: time-bounded recovery) | > 0 |

## States
`Created → Funded → Released`, `Funded → Disputed → ResolvedToBuyer | ResolvedToSeller`, `Created → Cancelled`.
Terminal states: `Released`, `ResolvedToBuyer`, `ResolvedToSeller`, `Cancelled` — no state-changing
transition is allowed from them (only `withdraw` of an already recorded credit).

## Transitions
| function | caller | from → to | effect |
|---|---|---|---|
| `fund()` payable | buyer | Created → Funded | requires `msg.value == price`; `escrowed = price` |
| `release()` | buyer | Funded → Released | `credit[seller] += escrowed`; `escrowed = 0` |
| `raiseDispute()` | buyer or seller | Funded → Disputed | records `disputedAt = block.timestamp` |
| `resolveToBuyer()` | arbiter | Disputed → ResolvedToBuyer | `credit[buyer] += escrowed`; `escrowed = 0` |
| `resolveToSeller()` | arbiter | Disputed → ResolvedToSeller | `credit[seller] += escrowed`; `escrowed = 0` |
| `approveCancel()` | buyer or seller | Created → Cancelled once **both** have approved | mutual cancellation before any funds move |
| `claimAfterTimeout()` | buyer | Disputed → ResolvedToBuyer when `block.timestamp >= disputedAt + disputeTimeout` | recovery if the arbiter never acts (`>=`, never timestamp equality) |
| `withdraw()` | anyone with a credit | any state | pull payment: zero the credit, then send ETH |

Every other (caller, state) combination reverts with a custom error: `Unauthorized(caller)`,
`InvalidState(current)`, `WrongAmount(sent, expected)`, `NothingToWithdraw()`, `TransferFailed()`,
`AlreadyApproved()`, `TimeoutNotReached(now, deadline)`, `DirectPaymentRejected()`, and at deployment
`ZeroAddress()`, `RolesOverlap()`, `ZeroPrice()`, `ZeroTimeout()`.

## Events
`Funded(buyer, amount)`, `Released(seller, amount)`, `DisputeRaised(by)`, `Resolved(to, amount, byTimeout)`,
`CancelApproved(by)`, `Cancelled()`, `Withdrawn(to, amount)`, plus `StateChanged(from, to)` on every transition.

## Accounting invariant
`liabilities() = escrowed + totalCredits`, and after every action
`address(this).balance == liabilities()` (it can only be larger if someone force-sends ETH with
`selfdestruct`, which the contract cannot prevent; such ETH is never paid out).

## Security rules
* Checks-effects-interactions everywhere; the only external call is in `withdraw`, after the credit is zeroed.
* Pull payments: transitions never send ETH, so a reverting recipient cannot block a state change.
* `nonReentrant` (OpenZeppelin `ReentrancyGuard`) on `fund`, `withdraw` and every payout-recording function.
* No `tx.origin`, no loops, no timestamp equality, low-level call result always checked.
* `receive`/`fallback` revert so ETH cannot be locked by accident.
