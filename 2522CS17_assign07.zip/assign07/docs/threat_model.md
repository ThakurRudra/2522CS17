# Threat model — Escrow (Assignment 7)

Student: Rudra Pratap Singh (2522CS17)

**Assets:** the deposited ETH and the correctness of who may withdraw it.
**Actors:** buyer, seller, arbiter (all fixed and distinct), and any other address (attacker).
**Trust assumptions:** the arbiter is trusted to judge disputes honestly but is *not* trusted with
funds (the arbiter can never receive a credit). The buyer is protected against an absent arbiter by
the timeout; the seller relies on the buyer releasing or on the arbiter.

| # | Threat | Mitigation | Test evidence |
|---|---|---|---|
| 1 | **Unauthorised transition / redirecting funds** (stranger calls `release`, seller resolves own dispute) | `only(role)` modifiers with `Unauthorized(caller)`; payout targets are immutable `buyer`/`seller`, never a caller-supplied address | `test_Release_RevertsForSellerArbiterStranger`, `test_Resolve_RevertsForNonArbiter`, `testFuzz_CallerRoles`, `invariant_OnlyPartiesCredited` |
| 2 | **Reentrancy** on payout | Pull payments; credit zeroed before the call (checks-effects-interactions); OpenZeppelin `nonReentrant` on `withdraw`, `fund`, `release`, `resolve*` | `test_Reentrancy_BubblingAttackReverts`, `test_Reentrancy_SwallowedAttackPaysOnlyOnce` |
| 3 | **Paying twice from a terminal state** | `inState` checks; `escrowed` moved to a credit exactly once; credit zeroed on withdraw | `test_Release_CannotPayTwice`, `test_Resolve_TerminalCannotPayTwice`, `test_Withdraw_OnlyOnce`, `invariant_NoDoublePayment` |
| 4 | **Repeated or wrong funding** | `fund` only in `Created`, `msg.value == price` exactly | `test_Fund_RevertsWhenFundedTwice`, `testFuzz_FundAmount` |
| 5 | **Funds locked without a path** | Every non-terminal state has an exit: Created→Cancelled, Funded→Released/Disputed, Disputed→Resolved or **timeout recovery to buyer**; `receive`/`fallback` revert so ETH cannot be sent by accident; a failed transfer reverts and keeps the credit for a retry | `test_Timeout_*`, `test_DirectEthTransferRejected`, `test_Withdraw_FailedTransferKeepsCredit` |
| 6 | **Zero address / role overlap** (e.g. buyer = arbiter would let the buyer judge their own dispute) | Constructor rejects zero addresses and any overlap | `test_Constructor_*`, `testFuzz_ConstructorRoles` |
| 7 | **Denial of service by a reverting recipient** | Transitions never transfer ETH (pull model), so a hostile seller contract cannot block `release`/`resolve` | `test_Withdraw_FailedTransferKeepsCredit` |
| 8 | **Accounting drift** | `liabilities() = escrowed + totalCredits`; tests assert `balance == liabilities()` after every action; invariant fuzzing over random call sequences | `_solvent()` in every unit test, `invariant_BalanceEqualsLiabilities`, deployment script check after each tx |
| 9 | **Timestamp manipulation** | Only the timeout uses time, with `>=` (no equality); a validator can shift `block.timestamp` by seconds, irrelevant against a multi-day window | `test_Timeout_RevertsBeforeDeadline` |
| 10 | **`tx.origin` phishing, unchecked calls, unbounded loops** | Not used; the single low-level call's result is checked; no loops | code review |

## Residual risks
* **Forced ETH** (`selfdestruct` from another contract / coinbase rewards) can raise the balance above
  `liabilities()`. It cannot be withdrawn by anyone (stuck), but it can never reduce what parties are owed.
* **Arbiter collusion:** a corrupt arbiter can side with one party; this is inherent to arbitrated escrow
  (mitigations: multisig or reputation-staked arbiters).
* **Timeout policy:** after the deadline the buyer, not the seller, recovers the funds. A seller who expects
  to win must make sure the arbiter acts in time — this is the new trust assumption the stretch goal adds.
* **No partial refunds or price changes:** deliberate simplicity; any change requires a new contract.
* EIP-712 gas-sponsored approvals (other stretch goal) are not implemented, so there are no signature
  replay concerns in this version.
