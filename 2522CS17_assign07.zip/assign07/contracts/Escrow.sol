// SPDX-License-Identifier: MIT
// Assignment 7 - Solidity escrow. Rudra Pratap Singh (2522CS17), Blockchain course, IIT Patna.
pragma solidity ^0.8.24;

import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/// @title Buyer / seller / arbiter escrow with pull payments
/// @notice State machine: Created -> Funded | Cancelled; Funded -> Released | Disputed;
///         Disputed -> ResolvedToBuyer | ResolvedToSeller. Terminal states allow only withdraw().
contract Escrow is ReentrancyGuard {
    enum State { Created, Funded, Released, Disputed, ResolvedToBuyer, ResolvedToSeller, Cancelled }

    // ------------------------------------------------------------------ errors
    error ZeroAddress();
    error RolesOverlap();
    error ZeroPrice();
    error ZeroTimeout();
    error Unauthorized(address caller);
    error InvalidState(State current);
    error WrongAmount(uint256 sent, uint256 expected);
    error NothingToWithdraw();
    error TransferFailed();
    error AlreadyApproved();
    error TimeoutNotReached(uint256 nowTs, uint256 deadline);
    error DirectPaymentRejected();

    // ------------------------------------------------------------------ events
    event StateChanged(State indexed from, State indexed to);
    event Funded(address indexed buyer, uint256 amount);
    event Released(address indexed seller, uint256 amount);
    event DisputeRaised(address indexed by);
    event Resolved(address indexed to, uint256 amount, bool byTimeout);
    event CancelApproved(address indexed by);
    event Cancelled();
    event Withdrawn(address indexed to, uint256 amount);

    // ------------------------------------------------------------------ storage
    address public immutable buyer;
    address public immutable seller;
    address public immutable arbiter;
    uint256 public immutable price;
    uint256 public immutable disputeTimeout;

    State public state;
    uint256 public escrowed;                       // ETH held for the deal (0 or price)
    uint256 public totalCredits;                   // sum of all credits (recorded liabilities)
    uint256 public disputedAt;
    mapping(address => uint256) public credits;    // pull-payment balances
    bool public buyerApprovedCancel;
    bool public sellerApprovedCancel;

    constructor(address buyer_, address seller_, address arbiter_, uint256 price_, uint256 disputeTimeout_) {
        if (buyer_ == address(0) || seller_ == address(0) || arbiter_ == address(0)) revert ZeroAddress();
        if (buyer_ == seller_ || arbiter_ == buyer_ || arbiter_ == seller_) revert RolesOverlap();
        if (price_ == 0) revert ZeroPrice();
        if (disputeTimeout_ == 0) revert ZeroTimeout();
        buyer = buyer_;
        seller = seller_;
        arbiter = arbiter_;
        price = price_;
        disputeTimeout = disputeTimeout_;
        // state defaults to Created
    }

    // ------------------------------------------------------------------ modifiers
    modifier only(address who) {
        if (msg.sender != who) revert Unauthorized(msg.sender);
        _;
    }

    modifier inState(State s) {
        if (state != s) revert InvalidState(state);
        _;
    }

    function _move(State to) private {
        emit StateChanged(state, to);
        state = to;
    }

    // ------------------------------------------------------------------ transitions
    /// @notice Buyer deposits exactly `price`. Only once: a second call fails the state check.
    function fund() external payable nonReentrant only(buyer) inState(State.Created) {
        if (msg.value != price) revert WrongAmount(msg.value, price);
        escrowed = msg.value;
        _move(State.Funded);
        emit Funded(msg.sender, msg.value);
    }

    /// @notice Buyer is satisfied: the seller is credited the escrowed amount.
    function release() external nonReentrant only(buyer) inState(State.Funded) {
        uint256 amount = escrowed;
        escrowed = 0;
        _credit(seller, amount);
        _move(State.Released);
        emit Released(seller, amount);
    }

    /// @notice Buyer or seller escalates to the arbiter.
    function raiseDispute() external inState(State.Funded) {
        if (msg.sender != buyer && msg.sender != seller) revert Unauthorized(msg.sender);
        disputedAt = block.timestamp;
        _move(State.Disputed);
        emit DisputeRaised(msg.sender);
    }

    function resolveToBuyer() external nonReentrant only(arbiter) inState(State.Disputed) {
        _resolve(buyer, State.ResolvedToBuyer, false);
    }

    function resolveToSeller() external nonReentrant only(arbiter) inState(State.Disputed) {
        _resolve(seller, State.ResolvedToSeller, false);
    }

    /// @notice Stretch goal: if the arbiter has not acted within `disputeTimeout`, the buyer recovers the funds.
    function claimAfterTimeout() external nonReentrant only(buyer) inState(State.Disputed) {
        uint256 deadline = disputedAt + disputeTimeout;
        if (block.timestamp < deadline) revert TimeoutNotReached(block.timestamp, deadline);
        _resolve(buyer, State.ResolvedToBuyer, true);
    }

    /// @notice Mutual cancellation before funding: both buyer and seller must approve.
    function approveCancel() external inState(State.Created) {
        if (msg.sender == buyer) {
            if (buyerApprovedCancel) revert AlreadyApproved();
            buyerApprovedCancel = true;
        } else if (msg.sender == seller) {
            if (sellerApprovedCancel) revert AlreadyApproved();
            sellerApprovedCancel = true;
        } else {
            revert Unauthorized(msg.sender);
        }
        emit CancelApproved(msg.sender);
        if (buyerApprovedCancel && sellerApprovedCancel) {
            _move(State.Cancelled);
            emit Cancelled();
        }
    }

    /// @notice Pull payment. Checks -> effects (credit zeroed) -> interaction (ETH transfer).
    function withdraw() external nonReentrant {
        uint256 amount = credits[msg.sender];
        if (amount == 0) revert NothingToWithdraw();
        credits[msg.sender] = 0;
        totalCredits -= amount;
        emit Withdrawn(msg.sender, amount);
        (bool ok, ) = payable(msg.sender).call{value: amount}("");
        if (!ok) revert TransferFailed();
    }

    // ------------------------------------------------------------------ views
    /// @notice ETH the contract owes: still escrowed + already credited but not yet withdrawn.
    function liabilities() external view returns (uint256) {
        return escrowed + totalCredits;
    }

    function isTerminal() external view returns (bool) {
        return state == State.Released || state == State.ResolvedToBuyer || state == State.ResolvedToSeller
            || state == State.Cancelled;
    }

    // ------------------------------------------------------------------ internals
    function _resolve(address to, State terminal, bool byTimeout) private {
        uint256 amount = escrowed;
        escrowed = 0;
        _credit(to, amount);
        _move(terminal);
        emit Resolved(to, amount, byTimeout);
    }

    function _credit(address to, uint256 amount) private {
        credits[to] += amount;
        totalCredits += amount;
    }

    receive() external payable {
        revert DirectPaymentRejected();
    }

    fallback() external payable {
        revert DirectPaymentRejected();
    }
}
