# Assignment 7 — Solidity Escrow from Specification to Deployment

**Student:** Rudra Pratap Singh · **Roll:** 2522CS17 · **Course:** Blockchain (Dr. Mayank Agarwal), IIT Patna

Buyer / seller / arbiter escrow in Solidity 0.8.28 with custom errors, events, checks-effects-interactions,
pull payments and OpenZeppelin `ReentrancyGuard`; Foundry unit, fuzz and invariant tests; deployment to a
local **Anvil** node driven by a Python (web3.py) script.

## How to run
```bash
cd assign07
bash run_tests.sh          # ONE command: installs Foundry + pinned libs if missing, runs all 45 tests
pip install -r requirements.txt
forge build
python script/deploy_and_interact.py --start-anvil   # deploy + 5 scripted scenarios -> receipts/, docs/gas_report.md
forge test --gas-report    # per-function gas table
python script/state_diagram.py                      # docs/state_machine.png
```
Colab: `notebook/Assignment07_escrow_Colab.ipynb` → Run all (installs Foundry with foundryup).

## Layout
```
assign07/
├── foundry.toml, requirements.txt, run_tests.sh, .gitignore (out/, cache/, lib/ are generated)
├── contracts/Escrow.sol          the contract
├── test/Escrow.t.sol             42 unit + fuzz tests (every transition and every rejected transition)
├── test/EscrowInvariant.t.sol    3 invariants over random call sequences
├── script/deploy_and_interact.py deployment + interaction on Anvil, receipt capture, checks
├── script/state_diagram.py       state-machine figure
├── docs/specification.md         written before the Solidity code
├── docs/state_machine.md (+png), docs/threat_model.md, docs/gas_report.md (generated)
└── receipts/                     local transaction receipts per scenario + deployments.json (generated)
```

## State machine
`Created → Funded | Cancelled`, `Funded → Released | Disputed`, `Disputed → ResolvedToBuyer | ResolvedToSeller`;
terminal states allow no further state change. Stretch goal implemented: **time-bounded recovery** —
if the arbiter does not resolve within `disputeTimeout`, the buyer may `claimAfterTimeout()` (→ ResolvedToBuyer).

## Acceptance checks → evidence
| check | evidence |
|---|---|
| balance and recorded liabilities agree after every action | `_solvent()` after each unit-test step, `invariant_BalanceEqualsLiabilities`, script check after every tx |
| unauthorised users cannot redirect funds | `testFuzz_CallerRoles`, role tests, `invariant_OnlyPartiesCredited` |
| terminal states cannot pay twice | `test_*CannotPayTwice`, `test_Withdraw_OnlyOnce`, `invariant_NoDoublePayment` |
| full suite from a clean checkout with one command | `bash run_tests.sh` |
| events, final balances, gas used, deployed bytecode address | `receipts/*.json`, `docs/gas_report.md` |

Video demo: *(add the unlisted YouTube link here)*
