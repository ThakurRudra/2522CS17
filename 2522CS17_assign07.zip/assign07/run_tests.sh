#!/usr/bin/env bash
# ONE command for the full test suite from a clean checkout:   bash run_tests.sh
# Installs Foundry and the pinned libraries if they are missing, then runs unit, fuzz and invariant tests.
set -euo pipefail
cd "$(dirname "$0")"
export PATH="$HOME/.foundry/bin:$PATH"
if ! command -v forge >/dev/null 2>&1; then
  echo "Foundry not found - installing with foundryup"
  curl -sSL https://foundry.paradigm.xyz | bash
  "$HOME/.foundry/bin/foundryup"
fi
mkdir -p lib
[ -d lib/forge-std ] || git -c advice.detachedHead=false clone -q --depth 1 --branch v1.9.7 \
  https://github.com/foundry-rs/forge-std lib/forge-std
[ -d lib/openzeppelin-contracts ] || git -c advice.detachedHead=false clone -q --depth 1 --branch v5.1.0 \
  https://github.com/OpenZeppelin/openzeppelin-contracts lib/openzeppelin-contracts
forge --version | head -1
forge test -vv "$@" 2>&1 | grep -v -E "Compiling\.\.\.|Compiling [0-9]+ files"
