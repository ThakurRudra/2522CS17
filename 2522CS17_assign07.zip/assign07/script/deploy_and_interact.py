"""Deploy Escrow to a local Anvil node and drive it with scripted transactions (no GUI).

usage (from assign07/, after `forge build`):
    python script/deploy_and_interact.py --start-anvil      # spawns anvil on :8545 and stops it at the end
    python script/deploy_and_interact.py --rpc http://127.0.0.1:8545

For each scenario the script deploys a fresh Escrow, sends every transaction, and verifies
  * the emitted events (decoded from the receipt logs),
  * contract balance == liabilities() after every action,
  * final ETH balances of the parties (value received minus gas paid),
  * gas used per transaction,
  * the deployed bytecode at the contract address (runtime code from forge with immutables masked).
Receipts are written to receipts/<scenario>.json and a summary to docs/gas_report.md (+ deployments.json).
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time

from eth_abi import decode as abi_decode
from eth_utils import keccak
from web3 import Web3
from web3.exceptions import ContractCustomError, ContractLogicError

ART = "out/Escrow.sol/Escrow.json"
STATES = ["Created", "Funded", "Released", "Disputed", "ResolvedToBuyer", "ResolvedToSeller", "Cancelled"]
PRICE = Web3.to_wei(1, "ether")
TIMEOUT = 3 * 24 * 3600


def eth(wei: int) -> float:
    """Signed wei -> ETH (Web3.from_wei rejects negative numbers)."""
    return round(wei / 10**18, 9)


def load_artifact():
    with open(ART) as fh:
        art = json.load(fh)
    return art["abi"], art["bytecode"]["object"], art["deployedBytecode"]


def error_table(abi):
    t = {}
    for item in abi:
        if item["type"] == "error":
            types = [i["type"] for i in item["inputs"]]
            sig = f"{item['name']}({','.join(types)})"
            t["0x" + keccak(text=sig)[:4].hex()] = (item["name"], types)
    return t


def decode_revert(data, errors) -> str:
    if isinstance(data, tuple):
        data = data[0]
    data = data if isinstance(data, str) else str(data)
    sel, rest = data[:10], data[10:]
    if sel in errors:
        name, types = errors[sel]
        args = abi_decode(types, bytes.fromhex(rest)) if types else ()
        args = [STATES[a] if name == "InvalidState" else (a if not isinstance(a, bytes) else a.hex()) for a in args]
        return f"{name}({', '.join(map(str, args))})"
    return data


class Runner:
    def __init__(self, w3: Web3, abi, bytecode, runtime):
        self.w3, self.abi, self.bytecode, self.runtime = w3, abi, bytecode, runtime
        self.errors = error_table(abi)
        a = w3.eth.accounts
        self.roles = {"deployer": a[0], "buyer": a[1], "seller": a[2], "arbiter": a[3], "stranger": a[4]}

    def deploy(self, steps):
        C = self.w3.eth.contract(abi=self.abi, bytecode=self.bytecode)
        r = self.roles
        h = C.constructor(r["buyer"], r["seller"], r["arbiter"], PRICE, TIMEOUT).transact({"from": r["deployer"]})
        rc = self.w3.eth.wait_for_transaction_receipt(h)
        c = self.w3.eth.contract(address=rc.contractAddress, abi=self.abi)
        steps.append(self._record("deploy", "deployer", rc, c))
        return c, rc

    def _events(self, c, rc):
        out = []
        for ev in [e["name"] for e in self.abi if e["type"] == "event"]:
            for log in getattr(c.events, ev)().process_receipt(rc, errors=__import__("web3").logs.DISCARD):
                args = {k: (STATES[v] if k in ("from", "to") and isinstance(v, int) else v) for k, v in log["args"].items()}
                out.append({"event": ev, "args": args, "logIndex": log["logIndex"]})
        return sorted(out, key=lambda e: e["logIndex"])

    def _record(self, action, who, rc, c):
        bal = self.w3.eth.get_balance(c.address)
        liab = c.functions.liabilities().call()
        return {"action": action, "from": who, "tx_hash": rc.transactionHash.hex(), "block": rc.blockNumber,
                "status": rc.status, "gas_used": rc.gasUsed, "effective_gas_price": rc.effectiveGasPrice,
                "contract_address": rc.contractAddress, "events": self._events(c, rc),
                "state_after": STATES[c.functions.state().call()], "contract_balance": bal, "liabilities": liab,
                "balance_equals_liabilities": bal == liab}

    def tx(self, c, steps, who, fn, *args, value=0):
        f = getattr(c.functions, fn)(*args)
        try:
            h = f.transact({"from": self.roles[who], "value": value})
        except (ContractCustomError, ContractLogicError) as exc:
            reason = decode_revert(getattr(exc, "data", None) or exc.args[0], self.errors)
            bal, liab = self.w3.eth.get_balance(c.address), c.functions.liabilities().call()
            steps.append({"action": fn, "from": who, "status": "reverted", "revert": reason,
                          "state_after": STATES[c.functions.state().call()], "contract_balance": bal,
                          "liabilities": liab, "balance_equals_liabilities": bal == liab})
            return None
        rc = self.w3.eth.wait_for_transaction_receipt(h)
        steps.append(self._record(fn, who, rc, c))
        return rc

    def verify_code(self, address) -> dict:
        onchain = self.w3.eth.get_code(address).hex().removeprefix("0x")
        expected = self.runtime["object"].removeprefix("0x")
        masked_on, masked_exp = list(onchain), list(expected)
        for refs in self.runtime.get("immutableReferences", {}).values():
            for ref in refs:
                s, n = ref["start"] * 2, ref["length"] * 2
                masked_on[s:s + n] = ["0"] * n
                masked_exp[s:s + n] = ["0"] * n
        return {"address": address, "code_size_bytes": len(onchain) // 2,
                "matches_forge_runtime_bytecode": "".join(masked_on) == "".join(masked_exp),
                "code_keccak": "0x" + keccak(hexstr=onchain).hex()}


def scenario(runner: Runner, name: str, script) -> dict:
    w3 = runner.w3
    start = {k: w3.eth.get_balance(v) for k, v in runner.roles.items()}
    steps = []
    c, rc = runner.deploy(steps)
    script(runner, c, steps)
    end = {k: w3.eth.get_balance(v) for k, v in runner.roles.items()}
    gas_paid = {k: 0 for k in runner.roles}
    for s in steps:
        if s.get("status") == 1:
            gas_paid[s["from"]] += s["gas_used"] * s["effective_gas_price"]
    net = {k: end[k] - start[k] + gas_paid[k] for k in runner.roles}   # value moved, excluding gas
    result = {"scenario": name, "contract": runner.verify_code(c.address), "steps": steps,
              "final_state": STATES[c.functions.state().call()],
              "final_contract_balance_wei": w3.eth.get_balance(c.address),
              "net_value_change_excluding_gas_wei": net, "gas_paid_wei": gas_paid,
              "all_balances_equal_liabilities": all(s["balance_equals_liabilities"] for s in steps)}
    os.makedirs("receipts", exist_ok=True)
    with open(f"receipts/{name}.json", "w") as fh:
        json.dump(result, fh, indent=2, default=str)
    return result


def s_happy(r, c, steps):
    r.tx(c, steps, "buyer", "fund", value=PRICE)
    r.tx(c, steps, "stranger", "release")                     # unauthorised: must revert
    r.tx(c, steps, "buyer", "release")
    r.tx(c, steps, "buyer", "release")                        # terminal: cannot pay twice
    r.tx(c, steps, "seller", "withdraw")
    r.tx(c, steps, "seller", "withdraw")                      # nothing left


def s_dispute_buyer(r, c, steps):
    r.tx(c, steps, "buyer", "fund", value=PRICE)
    r.tx(c, steps, "buyer", "fund", value=PRICE)              # repeated funding: must revert
    r.tx(c, steps, "seller", "raiseDispute")
    r.tx(c, steps, "seller", "resolveToSeller")               # only the arbiter may resolve
    r.tx(c, steps, "arbiter", "resolveToBuyer")
    r.tx(c, steps, "arbiter", "withdraw")                     # arbiter is never credited
    r.tx(c, steps, "buyer", "withdraw")


def s_dispute_seller(r, c, steps):
    r.tx(c, steps, "buyer", "fund", value=PRICE)
    r.tx(c, steps, "buyer", "raiseDispute")
    r.tx(c, steps, "arbiter", "resolveToSeller")
    r.tx(c, steps, "arbiter", "resolveToBuyer")               # terminal: cannot pay twice
    r.tx(c, steps, "seller", "withdraw")


def s_cancel(r, c, steps):
    r.tx(c, steps, "stranger", "approveCancel")               # unauthorised
    r.tx(c, steps, "buyer", "approveCancel")
    r.tx(c, steps, "seller", "approveCancel")
    r.tx(c, steps, "buyer", "fund", value=PRICE)              # terminal: cannot fund


def s_timeout(r, c, steps):
    r.tx(c, steps, "buyer", "fund", value=PRICE)
    r.tx(c, steps, "seller", "raiseDispute")
    r.tx(c, steps, "buyer", "claimAfterTimeout")              # too early: must revert
    r.w3.provider.make_request("evm_increaseTime", [TIMEOUT])
    r.w3.provider.make_request("evm_mine", [])
    r.tx(c, steps, "buyer", "claimAfterTimeout")
    r.tx(c, steps, "buyer", "withdraw")


SCENARIOS = [("scenario_1_happy_path_release", s_happy), ("scenario_2_dispute_resolved_to_buyer", s_dispute_buyer),
             ("scenario_3_dispute_resolved_to_seller", s_dispute_seller), ("scenario_4_mutual_cancellation", s_cancel),
             ("scenario_5_arbiter_timeout_recovery", s_timeout)]


def write_report(results, forge_gas_txt: str | None):
    rows, gas_by_fn = [], {}
    for res in results:
        for s in res["steps"]:
            if s.get("status") == 1:
                gas_by_fn.setdefault(s["action"], []).append(s["gas_used"])
    for fn, g in sorted(gas_by_fn.items()):
        rows.append(f"| `{fn}` | {len(g)} | {min(g):,} | {sum(g) // len(g):,} | {max(g):,} |")
    sc = []
    for res in results:
        ok = sum(1 for s in res["steps"] if s.get("status") == 1)
        rev = [f"{s['action']} by {s['from']} → `{s['revert']}`" for s in res["steps"] if s.get("status") == "reverted"]
        net = res["net_value_change_excluding_gas_wei"]
        sc.append(f"| {res['scenario']} | `{res['contract']['address']}` | {res['final_state']} | {ok} | "
                  f"{'<br>'.join(rev) or '—'} | buyer {eth(net['buyer'])}, seller "
                  f"{eth(net['seller'])}, arbiter {eth(net['arbiter'])} | "
                  f"{res['all_balances_equal_liabilities']} | {res['contract']['matches_forge_runtime_bytecode']} |")
    md = f"""# Gas report and local deployment — Escrow (Assignment 7)

Student: Rudra Pratap Singh (2522CS17). Local chain: Anvil (chain id 31337). Price = 1 ETH.
Generated by `python script/deploy_and_interact.py --start-anvil`; full receipts in `receipts/`.

## Gas used by mined transactions (from receipts)
| function | txs | min gas | avg gas | max gas |
|---|---:|---:|---:|---:|
{chr(10).join(rows)}

## Scenarios
| scenario | contract address | final state | mined txs | rejected (custom error) | net value change, excl. gas (ETH) | balance == liabilities after every step | deployed bytecode matches forge build |
|---|---|---|---:|---|---|:---:|:---:|
{chr(10).join(sc)}

Interpretation: `fund` is the most expensive state change (first write of `escrowed` + state); `release` and
`resolve*` write a credit and `totalCredits`; `withdraw` is cheap because it only clears a slot and
transfers ETH. Rejected transactions are refused during gas estimation (custom error decoded from the
revert data), so they are never mined and cost nothing on the local node.
"""
    if forge_gas_txt:
        md += "\n## `forge test --gas-report` (unit + fuzz tests)\n```\n" + forge_gas_txt.strip() + "\n```\n"
    os.makedirs("docs", exist_ok=True)
    with open("docs/gas_report.md", "w") as fh:
        fh.write(md)
    with open("receipts/deployments.json", "w") as fh:
        json.dump({r["scenario"]: r["contract"] for r in results}, fh, indent=2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rpc", default="http://127.0.0.1:8545")
    ap.add_argument("--start-anvil", action="store_true")
    ap.add_argument("--forge-gas-report", help="text file with `forge test --gas-report` output to embed")
    a = ap.parse_args()
    proc = None
    if a.start_anvil:
        anvil = shutil.which("anvil") or os.path.expanduser("~/.foundry/bin/anvil")
        proc = subprocess.Popen([anvil, "--port", a.rpc.rsplit(":", 1)[1], "--silent"], stdout=subprocess.DEVNULL)
    try:
        w3 = Web3(Web3.HTTPProvider(a.rpc))
        for _ in range(100):
            if w3.is_connected():
                break
            time.sleep(0.1)
        print("connected to", a.rpc, "chain id", w3.eth.chain_id)
        abi, bytecode, runtime = load_artifact()
        runner = Runner(w3, abi, bytecode, runtime)
        results = []
        for name, fn in SCENARIOS:
            res = scenario(runner, name, fn)
            results.append(res)
            print(f"\n== {name}  contract {res['contract']['address']}  (bytecode verified: "
                  f"{res['contract']['matches_forge_runtime_bytecode']})")
            for s in res["steps"]:
                if s.get("status") == "reverted":
                    print(f"   {s['action']:18s} by {s['from']:8s} REVERTED {s['revert']}")
                else:
                    evs = ", ".join(e["event"] for e in s["events"])
                    print(f"   {s['action']:18s} by {s['from']:8s} gas {s['gas_used']:>7,}  -> {s['state_after']:16s} "
                          f"balance {Web3.from_wei(s['contract_balance'], 'ether')} == liabilities "
                          f"{Web3.from_wei(s['liabilities'], 'ether')}  [{evs}]")
            net = res["net_value_change_excluding_gas_wei"]
            print("   net value change (ETH, excluding gas):",
                  {k: eth(v) for k, v in net.items() if v})
        txt = open(a.forge_gas_report).read() if a.forge_gas_report and os.path.exists(a.forge_gas_report) else None
        write_report(results, txt)
        ok = all(r["all_balances_equal_liabilities"] and r["contract"]["matches_forge_runtime_bytecode"] for r in results)
        print("\nall checks passed:", ok, "-> receipts/*.json, docs/gas_report.md")
        return 0 if ok else 1
    finally:
        if proc:
            proc.terminate()


if __name__ == "__main__":
    sys.exit(main())
