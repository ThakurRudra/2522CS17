"""Draw docs/state_machine.png (run from assign07/: python script/state_diagram.py)."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyBboxPatch  # noqa: E402

W, H = 0.85, 0.36   # half width / half height of a state box
pos = {"Created": (0, 0), "Funded": (4.2, 0), "Cancelled": (0, -2.7), "Released": (8.6, 1.7),
       "Disputed": (8.6, -1.7), "ResolvedToBuyer": (13.2, -0.5), "ResolvedToSeller": (13.2, -2.9)}
terminal = {"Cancelled", "Released", "ResolvedToBuyer", "ResolvedToSeller"}
# (from, to, label, label position, alignment)
edges = [("Created", "Funded", "fund()\n[buyer, msg.value == price]", (2.1, 0.12), "center"),
         ("Created", "Cancelled", "approveCancel()\n[buyer AND seller]", (0.15, -1.35), "left"),
         ("Funded", "Released", "release() [buyer]\nseller credited", (5.9, 1.25), "right"),
         ("Funded", "Disputed", "raiseDispute()\n[buyer or seller]", (5.9, -1.25), "right"),
         ("Disputed", "ResolvedToBuyer", "resolveToBuyer() [arbiter]\nclaimAfterTimeout() [buyer, now >= deadline]",
          (10.6, -0.15), "center"),
         ("Disputed", "ResolvedToSeller", "resolveToSeller()\n[arbiter]", (10.9, -2.75), "center")]
fig, ax = plt.subplots(figsize=(14, 6))
for name, (x, y) in pos.items():
    fc, ec = ("#f4cccc", "#990000") if name in terminal else ("#cfe2f3", "#1c4587")
    ax.add_patch(FancyBboxPatch((x - W, y - H), 2 * W, 2 * H, boxstyle="round,pad=0.03", fc=fc, ec=ec, lw=2))
    ax.text(x, y, name, ha="center", va="center", fontsize=10.5, weight="bold")


def anchor(a, b):
    (x0, y0), (x1, y1) = pos[a], pos[b]
    if abs(x1 - x0) < 1e-9:                      # vertical edge
        return (x0, y0 - H), (x1, y1 + H)
    return (x0 + W, y0), (x1 - W, y1)


for a, b, label, (lx, ly), ha in edges:
    st, en = anchor(a, b)
    ax.annotate("", xy=en, xytext=st, arrowprops=dict(arrowstyle="-|>", lw=1.6, color="#333"))
    ax.text(lx, ly, label, fontsize=8.5, ha=ha, va="center", color="#222",
            bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.9))
ax.text(6.6, -3.75, "Red = terminal state: no further state-changing transition (only withdraw() of a recorded credit).\n"
        "withdraw() is a pull payment available in any state to an address with a credit.", ha="center", fontsize=9)
ax.set_xlim(-1.2, 14.4); ax.set_ylim(-4.1, 2.4); ax.axis("off")
ax.set_title("Escrow state machine", fontsize=13)
fig.tight_layout()
fig.savefig("docs/state_machine.png", dpi=130)
print("wrote docs/state_machine.png")
