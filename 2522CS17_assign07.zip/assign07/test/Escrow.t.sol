// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {Escrow} from "../contracts/Escrow.sol";

/// Seller contract that tries to re-enter withdraw() while receiving ETH.
contract ReentrantSeller {
    Escrow public escrow;
    bool public swallow;          // true: ignore the failed re-entry; false: bubble it up
    uint256 public reentryAttempts;
    bool public reentrySucceeded;

    function setEscrow(Escrow e, bool swallow_) external {
        escrow = e;
        swallow = swallow_;
    }

    function pull() external {
        escrow.withdraw();
    }

    receive() external payable {
        reentryAttempts++;
        if (reentryAttempts == 1) {
            if (swallow) {
                try escrow.withdraw() { reentrySucceeded = true; } catch {}
            } else {
                escrow.withdraw(); // reverts -> whole outer call reverts
            }
        }
    }
}

/// Recipient that refuses ETH, to check that a failed transfer reverts and keeps the credit.
contract RefusingBuyer {
    receive() external payable {
        revert("no thanks");
    }

    function fund(Escrow e) external payable {
        e.fund{value: msg.value}();
    }

    function dispute(Escrow e) external {
        e.raiseDispute();
    }

    function pull(Escrow e) external {
        e.withdraw();
    }
}

contract EscrowTest is Test {
    Escrow internal esc;
    address internal buyer = makeAddr("buyer");
    address internal seller = makeAddr("seller");
    address internal arbiter = makeAddr("arbiter");
    address internal stranger = makeAddr("stranger");
    uint256 internal constant PRICE = 1 ether;
    uint256 internal constant TIMEOUT = 7 days;

    event StateChanged(Escrow.State indexed from, Escrow.State indexed to);
    event Funded(address indexed buyer, uint256 amount);
    event Released(address indexed seller, uint256 amount);
    event DisputeRaised(address indexed by);
    event Resolved(address indexed to, uint256 amount, bool byTimeout);
    event CancelApproved(address indexed by);
    event Cancelled();
    event Withdrawn(address indexed to, uint256 amount);

    function setUp() public {
        esc = new Escrow(buyer, seller, arbiter, PRICE, TIMEOUT);
        vm.deal(buyer, 10 ether);
        vm.deal(stranger, 10 ether);
        vm.deal(seller, 10 ether);
    }

    // -------------------------------------------------------------- helpers
    function _solvent() internal view {
        assertEq(address(esc).balance, esc.liabilities(), "balance != recorded liabilities");
    }

    function _fund() internal {
        vm.prank(buyer);
        esc.fund{value: PRICE}();
        _solvent();
    }

    function _dispute(address who) internal {
        _fund();
        vm.prank(who);
        esc.raiseDispute();
        _solvent();
    }

    function _expectState(Escrow.State s) internal view {
        assertEq(uint8(esc.state()), uint8(s));
    }

    // -------------------------------------------------------------- constructor
    function test_Constructor_RejectsZeroAddresses() public {
        vm.expectRevert(Escrow.ZeroAddress.selector);
        new Escrow(address(0), seller, arbiter, PRICE, TIMEOUT);
        vm.expectRevert(Escrow.ZeroAddress.selector);
        new Escrow(buyer, address(0), arbiter, PRICE, TIMEOUT);
        vm.expectRevert(Escrow.ZeroAddress.selector);
        new Escrow(buyer, seller, address(0), PRICE, TIMEOUT);
    }

    function test_Constructor_RejectsRoleOverlap() public {
        vm.expectRevert(Escrow.RolesOverlap.selector);
        new Escrow(buyer, buyer, arbiter, PRICE, TIMEOUT);
        vm.expectRevert(Escrow.RolesOverlap.selector);
        new Escrow(buyer, seller, buyer, PRICE, TIMEOUT);
        vm.expectRevert(Escrow.RolesOverlap.selector);
        new Escrow(buyer, seller, seller, PRICE, TIMEOUT);
    }

    function test_Constructor_RejectsZeroPriceAndTimeout() public {
        vm.expectRevert(Escrow.ZeroPrice.selector);
        new Escrow(buyer, seller, arbiter, 0, TIMEOUT);
        vm.expectRevert(Escrow.ZeroTimeout.selector);
        new Escrow(buyer, seller, arbiter, PRICE, 0);
    }

    function test_InitialState() public view {
        _expectState(Escrow.State.Created);
        assertEq(esc.buyer(), buyer);
        assertEq(esc.liabilities(), 0);
        assertFalse(esc.isTerminal());
    }

    // -------------------------------------------------------------- Created -> Funded
    function test_Fund_EmitsAndMovesToFunded() public {
        vm.expectEmit(true, true, false, true, address(esc));
        emit StateChanged(Escrow.State.Created, Escrow.State.Funded);
        vm.expectEmit(true, false, false, true, address(esc));
        emit Funded(buyer, PRICE);
        _fund();
        _expectState(Escrow.State.Funded);
        assertEq(address(esc).balance, PRICE);
        assertEq(esc.escrowed(), PRICE);
    }

    function test_Fund_RevertsWrongAmount() public {
        vm.prank(buyer);
        vm.expectRevert(abi.encodeWithSelector(Escrow.WrongAmount.selector, 0.5 ether, PRICE));
        esc.fund{value: 0.5 ether}();
    }

    function test_Fund_RevertsForNonBuyer() public {
        vm.prank(stranger);
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, stranger));
        esc.fund{value: PRICE}();
    }

    function test_Fund_RevertsWhenFundedTwice() public {
        _fund();
        vm.prank(buyer);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Funded));
        esc.fund{value: PRICE}();
        _solvent();
    }

    // -------------------------------------------------------------- Funded -> Released
    function test_Release_CreditsSellerAndMovesToReleased() public {
        _fund();
        vm.expectEmit(true, false, false, true, address(esc));
        emit Released(seller, PRICE);
        vm.prank(buyer);
        esc.release();
        _expectState(Escrow.State.Released);
        assertEq(esc.credits(seller), PRICE);
        assertEq(esc.escrowed(), 0);
        assertTrue(esc.isTerminal());
        _solvent();
    }

    function test_Release_RevertsForSellerArbiterStranger() public {
        _fund();
        address[3] memory who = [seller, arbiter, stranger];
        for (uint256 i = 0; i < 3; i++) {
            vm.prank(who[i]);
            vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, who[i]));
            esc.release();
        }
    }

    function test_Release_RevertsBeforeFunding() public {
        vm.prank(buyer);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Created));
        esc.release();
    }

    function test_Release_CannotPayTwice() public {
        _fund();
        vm.prank(buyer);
        esc.release();
        vm.prank(buyer);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Released));
        esc.release();
        assertEq(esc.credits(seller), PRICE);
    }

    // -------------------------------------------------------------- Funded -> Disputed
    function test_Dispute_ByBuyer() public {
        vm.warp(1_000);
        _fund();
        vm.expectEmit(true, false, false, false, address(esc));
        emit DisputeRaised(buyer);
        vm.prank(buyer);
        esc.raiseDispute();
        _expectState(Escrow.State.Disputed);
        assertEq(esc.disputedAt(), 1_000);
        _solvent();
    }

    function test_Dispute_BySeller() public {
        _dispute(seller);
        _expectState(Escrow.State.Disputed);
    }

    function test_Dispute_RevertsForArbiterAndStranger() public {
        _fund();
        vm.prank(arbiter);
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, arbiter));
        esc.raiseDispute();
        vm.prank(stranger);
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, stranger));
        esc.raiseDispute();
    }

    function test_Dispute_RevertsInCreatedAndAfterRelease() public {
        vm.prank(buyer);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Created));
        esc.raiseDispute();
        _fund();
        vm.prank(buyer);
        esc.release();
        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Released));
        esc.raiseDispute();
    }

    function test_Dispute_CannotBeRaisedTwice() public {
        _dispute(buyer);
        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Disputed));
        esc.raiseDispute();
    }

    function test_Release_RevertsWhileDisputed() public {
        _dispute(seller);
        vm.prank(buyer);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Disputed));
        esc.release();
    }

    // -------------------------------------------------------------- Disputed -> Resolved*
    function test_ResolveToBuyer() public {
        _dispute(seller);
        vm.expectEmit(true, false, false, true, address(esc));
        emit Resolved(buyer, PRICE, false);
        vm.prank(arbiter);
        esc.resolveToBuyer();
        _expectState(Escrow.State.ResolvedToBuyer);
        assertEq(esc.credits(buyer), PRICE);
        assertEq(esc.credits(seller), 0);
        _solvent();
    }

    function test_ResolveToSeller() public {
        _dispute(buyer);
        vm.prank(arbiter);
        esc.resolveToSeller();
        _expectState(Escrow.State.ResolvedToSeller);
        assertEq(esc.credits(seller), PRICE);
        _solvent();
    }

    function test_Resolve_RevertsForNonArbiter() public {
        _dispute(buyer);
        address[3] memory who = [buyer, seller, stranger];
        for (uint256 i = 0; i < 3; i++) {
            vm.startPrank(who[i]);
            vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, who[i]));
            esc.resolveToBuyer();
            vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, who[i]));
            esc.resolveToSeller();
            vm.stopPrank();
        }
    }

    function test_Resolve_RevertsWhenNotDisputed() public {
        _fund();
        vm.prank(arbiter);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Funded));
        esc.resolveToSeller();
    }

    function test_Resolve_TerminalCannotPayTwice() public {
        _dispute(buyer);
        vm.prank(arbiter);
        esc.resolveToSeller();
        vm.prank(arbiter);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.ResolvedToSeller));
        esc.resolveToBuyer();
        assertEq(esc.credits(buyer), 0);
        assertEq(esc.totalCredits(), PRICE);
    }

    // -------------------------------------------------------------- timeout recovery (stretch)
    function test_Timeout_BuyerRecoversAfterDeadline() public {
        vm.warp(10_000);
        _dispute(seller);
        vm.warp(10_000 + TIMEOUT);       // deadline reached (>=, no equality trap)
        vm.expectEmit(true, false, false, true, address(esc));
        emit Resolved(buyer, PRICE, true);
        vm.prank(buyer);
        esc.claimAfterTimeout();
        _expectState(Escrow.State.ResolvedToBuyer);
        _solvent();
    }

    function test_Timeout_RevertsBeforeDeadline() public {
        vm.warp(10_000);
        _dispute(seller);
        vm.warp(10_000 + TIMEOUT - 1);
        vm.prank(buyer);
        vm.expectRevert(abi.encodeWithSelector(Escrow.TimeoutNotReached.selector, 10_000 + TIMEOUT - 1, 10_000 + TIMEOUT));
        esc.claimAfterTimeout();
    }

    function test_Timeout_OnlyBuyer() public {
        _dispute(seller);
        vm.warp(block.timestamp + TIMEOUT);
        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, seller));
        esc.claimAfterTimeout();
    }

    // -------------------------------------------------------------- Created -> Cancelled
    function test_Cancel_NeedsBothParties() public {
        vm.expectEmit(true, false, false, false, address(esc));
        emit CancelApproved(buyer);
        vm.prank(buyer);
        esc.approveCancel();
        _expectState(Escrow.State.Created);   // one approval is not enough
        vm.expectEmit(false, false, false, false, address(esc));
        emit Cancelled();
        vm.prank(seller);
        esc.approveCancel();
        _expectState(Escrow.State.Cancelled);
        assertTrue(esc.isTerminal());
        _solvent();
    }

    function test_Cancel_RevertsForArbiterAndStranger() public {
        vm.prank(arbiter);
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, arbiter));
        esc.approveCancel();
        vm.prank(stranger);
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, stranger));
        esc.approveCancel();
    }

    function test_Cancel_RevertsDoubleApproval() public {
        vm.startPrank(buyer);
        esc.approveCancel();
        vm.expectRevert(Escrow.AlreadyApproved.selector);
        esc.approveCancel();
        vm.stopPrank();
    }

    function test_Cancel_RevertsAfterFunding() public {
        _fund();
        vm.prank(buyer);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Funded));
        esc.approveCancel();
    }

    function test_Cancelled_IsTerminal() public {
        vm.prank(buyer);
        esc.approveCancel();
        vm.prank(seller);
        esc.approveCancel();
        vm.prank(buyer);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Cancelled));
        esc.fund{value: PRICE}();
        vm.prank(seller);
        vm.expectRevert(abi.encodeWithSelector(Escrow.InvalidState.selector, Escrow.State.Cancelled));
        esc.approveCancel();
    }

    // -------------------------------------------------------------- withdraw (pull payments)
    function test_Withdraw_SellerAfterRelease() public {
        _fund();
        vm.prank(buyer);
        esc.release();
        uint256 before = seller.balance;
        vm.expectEmit(true, false, false, true, address(esc));
        emit Withdrawn(seller, PRICE);
        vm.prank(seller);
        esc.withdraw();
        assertEq(seller.balance, before + PRICE);
        assertEq(address(esc).balance, 0);
        _solvent();
    }

    function test_Withdraw_OnlyOnce() public {
        _fund();
        vm.prank(buyer);
        esc.release();
        vm.startPrank(seller);
        esc.withdraw();
        vm.expectRevert(Escrow.NothingToWithdraw.selector);
        esc.withdraw();
        vm.stopPrank();
    }

    function test_Withdraw_LoserAndStrangerGetNothing() public {
        _dispute(buyer);
        vm.prank(arbiter);
        esc.resolveToSeller();
        address[3] memory who = [buyer, arbiter, stranger];
        for (uint256 i = 0; i < 3; i++) {
            vm.prank(who[i]);
            vm.expectRevert(Escrow.NothingToWithdraw.selector);
            esc.withdraw();
        }
        _solvent();
    }

    function test_Withdraw_FailedTransferKeepsCredit() public {
        RefusingBuyer rb = new RefusingBuyer();
        Escrow e = new Escrow(address(rb), seller, arbiter, PRICE, TIMEOUT);
        vm.deal(address(rb), PRICE);
        vm.prank(address(rb));
        e.fund{value: PRICE}();
        vm.prank(address(rb));
        e.raiseDispute();
        vm.prank(arbiter);
        e.resolveToBuyer();
        vm.expectRevert(Escrow.TransferFailed.selector);
        rb.pull(e);
        assertEq(e.credits(address(rb)), PRICE);   // nothing lost, can retry later
        assertEq(address(e).balance, e.liabilities());
    }

    // -------------------------------------------------------------- reentrancy
    function _escrowWithAttacker(bool swallow) internal returns (Escrow e, ReentrantSeller attacker) {
        attacker = new ReentrantSeller();
        e = new Escrow(buyer, address(attacker), arbiter, PRICE, TIMEOUT);
        attacker.setEscrow(e, swallow);
        vm.prank(buyer);
        e.fund{value: PRICE}();
        vm.prank(buyer);
        e.release();
    }

    function test_Reentrancy_BubblingAttackReverts() public {
        (Escrow e, ReentrantSeller attacker) = _escrowWithAttacker(false);
        vm.expectRevert(Escrow.TransferFailed.selector);
        attacker.pull();
        assertEq(address(attacker).balance, 0);
        assertEq(e.credits(address(attacker)), PRICE);
        assertEq(address(e).balance, PRICE);
    }

    function test_Reentrancy_SwallowedAttackPaysOnlyOnce() public {
        (Escrow e, ReentrantSeller attacker) = _escrowWithAttacker(true);
        attacker.pull();
        assertFalse(attacker.reentrySucceeded());
        assertEq(address(attacker).balance, PRICE);    // paid exactly once
        assertEq(address(e).balance, 0);
        assertEq(e.liabilities(), 0);
    }

    // -------------------------------------------------------------- direct payments
    function test_DirectEthTransferRejected() public {
        vm.prank(stranger);
        (bool ok, ) = address(esc).call{value: 1 wei}("");
        assertFalse(ok);
        vm.prank(stranger);
        (ok, ) = address(esc).call{value: 1 wei}(hex"deadbeef");
        assertFalse(ok);
        assertEq(address(esc).balance, 0);
    }

    // -------------------------------------------------------------- fuzz tests
    /// Deposited amount: only exactly `price` is accepted.
    function testFuzz_FundAmount(uint96 amount) public {
        vm.deal(buyer, uint256(amount) + 1);
        vm.prank(buyer);
        if (amount != PRICE) {
            vm.expectRevert(abi.encodeWithSelector(Escrow.WrongAmount.selector, uint256(amount), PRICE));
            esc.fund{value: amount}();
            _expectState(Escrow.State.Created);
        } else {
            esc.fund{value: amount}();
            _expectState(Escrow.State.Funded);
        }
        _solvent();
    }

    /// Any price works end to end and the books always balance.
    function testFuzz_PriceFullFlow(uint96 p, bool toBuyer) public {
        vm.assume(p > 0);
        Escrow e = new Escrow(buyer, seller, arbiter, p, TIMEOUT);
        vm.deal(buyer, p);
        vm.prank(buyer);
        e.fund{value: p}();
        assertEq(address(e).balance, e.liabilities());
        vm.prank(seller);
        e.raiseDispute();
        vm.prank(arbiter);
        if (toBuyer) e.resolveToBuyer(); else e.resolveToSeller();
        assertEq(address(e).balance, e.liabilities());
        address winner = toBuyer ? buyer : seller;
        uint256 before = winner.balance;
        vm.prank(winner);
        e.withdraw();
        assertEq(winner.balance, before + p);
        assertEq(address(e).balance, 0);
        assertEq(e.liabilities(), 0);
    }

    /// Caller roles: a random address can never move the state or redirect funds.
    function testFuzz_CallerRoles(address caller) public {
        vm.assume(caller != buyer && caller != seller && caller != arbiter);
        vm.deal(caller, 2 ether);
        vm.startPrank(caller);
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, caller));
        esc.fund{value: PRICE}();
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, caller));
        esc.approveCancel();
        vm.stopPrank();
        _fund();
        vm.startPrank(caller);
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, caller));
        esc.release();
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, caller));
        esc.raiseDispute();
        vm.stopPrank();
        vm.prank(seller);
        esc.raiseDispute();
        vm.startPrank(caller);
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, caller));
        esc.resolveToSeller();
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, caller));
        esc.resolveToBuyer();
        vm.expectRevert(abi.encodeWithSelector(Escrow.Unauthorized.selector, caller));
        esc.claimAfterTimeout();
        vm.expectRevert(Escrow.NothingToWithdraw.selector);
        esc.withdraw();
        vm.stopPrank();
        _expectState(Escrow.State.Disputed);
        _solvent();
    }

    /// Fuzzed role assignment at deployment: any overlap or zero address is refused.
    function testFuzz_ConstructorRoles(address b, address s, address a) public {
        bool bad = b == address(0) || s == address(0) || a == address(0) || b == s || a == b || a == s;
        if (bad) {
            vm.expectRevert();
            new Escrow(b, s, a, PRICE, TIMEOUT);
        } else {
            Escrow e = new Escrow(b, s, a, PRICE, TIMEOUT);
            assertEq(e.arbiter(), a);
        }
    }
}
