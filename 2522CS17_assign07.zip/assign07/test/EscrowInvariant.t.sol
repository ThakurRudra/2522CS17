// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {Escrow} from "../contracts/Escrow.sol";

/// Handler: random sequences of calls by random actors (buyer, seller, arbiter, stranger).
contract Handler is Test {
    Escrow public esc;
    address[4] public actors;
    uint256 public paidOut;
    uint256 public deposited;

    constructor(Escrow e, address b, address s, address a, address x) {
        esc = e;
        actors = [b, s, a, x];
        for (uint256 i = 0; i < 4; i++) vm.deal(actors[i], 100 ether);
    }

    function _actor(uint256 seed) internal view returns (address) {
        return actors[seed % 4];
    }

    function fund(uint256 seed, uint96 amount) external {
        vm.prank(_actor(seed));
        try esc.fund{value: amount % 2 == 0 ? esc.price() : amount}() { deposited += esc.price(); } catch {}
    }

    function release(uint256 seed) external { vm.prank(_actor(seed)); try esc.release() {} catch {} }
    function dispute(uint256 seed) external { vm.prank(_actor(seed)); try esc.raiseDispute() {} catch {} }
    function toBuyer(uint256 seed) external { vm.prank(_actor(seed)); try esc.resolveToBuyer() {} catch {} }
    function toSeller(uint256 seed) external { vm.prank(_actor(seed)); try esc.resolveToSeller() {} catch {} }
    function cancel(uint256 seed) external { vm.prank(_actor(seed)); try esc.approveCancel() {} catch {} }

    function timeout(uint256 seed, uint32 dt) external {
        vm.warp(block.timestamp + dt);
        vm.prank(_actor(seed));
        try esc.claimAfterTimeout() {} catch {}
    }

    function withdraw(uint256 seed) external {
        address who = _actor(seed);
        uint256 c = esc.credits(who);
        vm.prank(who);
        try esc.withdraw() { paidOut += c; } catch {}
    }
}

contract EscrowInvariantTest is Test {
    Escrow internal esc;
    Handler internal h;
    address internal stranger = makeAddr("stranger");

    function setUp() public {
        esc = new Escrow(makeAddr("buyer"), makeAddr("seller"), makeAddr("arbiter"), 1 ether, 3 days);
        h = new Handler(esc, esc.buyer(), esc.seller(), esc.arbiter(), stranger);
        targetContract(address(h));
    }

    /// Balance always equals recorded liabilities.
    function invariant_BalanceEqualsLiabilities() public view {
        assertEq(address(esc).balance, esc.liabilities());
    }

    /// Never pays out more than was deposited (terminal states cannot pay twice).
    function invariant_NoDoublePayment() public view {
        assertLe(h.paidOut(), h.deposited());
        assertLe(h.deposited(), esc.price());
    }

    /// The arbiter and strangers can never hold a credit (unauthorised users cannot redirect funds).
    function invariant_OnlyPartiesCredited() public view {
        assertEq(esc.credits(esc.arbiter()), 0);
        assertEq(esc.credits(stranger), 0);
    }
}
