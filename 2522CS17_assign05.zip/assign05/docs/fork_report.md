# Fork report — blocks, proof of work, forks and reorganisation

Student: Rudra Pratap Singh (2522CS17) · Assignment 5 · machine: Linux x86_64, Python 3.13.18

## 1. Block header hex dump (block B3, the winning tip)
Header layout: `version u32 | prev_hash 32 | merkle_root 32 | timestamp u64 | target 32 | nonce u64` = 116 bytes, big-endian.
PoW rule: `int(SHA256d(header)) ≤ target`.
```
offset size  field        bytes (hex)
     0    4  version      00000001
     4   32  prev_hash    0022cd480b3ddd03d303d2f9cc2ad45bebad388f4f4f7a53cae4d7395a21c74c
    36   32  merkle_root  fdcfe9fa2728cc2d2bd09ddb5428671fc4382ab03d5fd6be0fc8425e448aeafd
    68    8  timestamp    000000006955b9b4
    76   32  target       003fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
   108    8  nonce        00000000000001f4

00000000  00 00 00 01 00 22 cd 48 0b 3d dd 03 d3 03 d2 f9
00000010  cc 2a d4 5b eb ad 38 8f 4f 4f 7a 53 ca e4 d7 39
00000020  5a 21 c7 4c fd cf e9 fa 27 28 cc 2d 2b d0 9d db
00000030  54 28 67 1f c4 38 2a b0 3d 5f d6 be 0f c8 42 5e
00000040  44 8a ea fd 00 00 00 00 69 55 b9 b4 00 3f ff ff
00000050  ff ff ff ff ff ff ff ff ff ff ff ff ff ff ff ff
00000060  ff ff ff ff ff ff ff ff ff ff ff ff 00 00 00 00
00000070  00 00 01 f4                                    
block_hash = SHA256d(header) = 0010ec69a1f5ae0cd42779f75ceb9cb5544a504a789c63eb112dea8bd056a15d
```
Header JSON:
```json
{
  "version": 1,
  "prev_hash": "0022cd480b3ddd03d303d2f9cc2ad45bebad388f4f4f7a53cae4d7395a21c74c",
  "merkle_root": "fdcfe9fa2728cc2d2bd09ddb5428671fc4382ab03d5fd6be0fc8425e448aeafd",
  "timestamp": 1767225780,
  "target": "003fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
  "nonce": 500
}
```

## 2. Two miners, competing blocks, fork resolution
Alice's 23-unit change is double-spent: miner A includes *Alice→Bob 20* in **A2**, miner B includes
*Alice→Carol 21* in **B2**, both on top of **A1**. With equal work every node keeps the block it saw first.
Miner B then finds **B3**; branch B now has more cumulative work, so every node disconnects A2 (restoring
Alice's spent output), connects B2 and B3, and the conflicting Alice→Bob transaction is returned but is
no longer valid.

![branches](fork_diagram.png)

```mermaid
graph RL
  A1[A1 h=1 002104ed] --> G[G h=0 00b47233]
  A2[A2 h=2 003c14c7 STALE] --> A1
  B2[B2 h=2 0022cd48] --> A1
  B3[B3 h=3 0010ec69 TIP] --> B2
  style A2 fill:#f4cccc,stroke:#990000
  style B2 fill:#c9ead3,stroke:#38761d
  style B3 fill:#c9ead3,stroke:#38761d
```

| event | node | block | status | height | tip | chain work | details |
|---|---|---|---|---:|---|---:|---|
| A1 mined by A | A | `002104ed42f3` | **connected** | 1 | `002104ed42f3` | 1,280 |  |
| A1 mined by A | B | `002104ed42f3` | **connected** | 1 | `002104ed42f3` | 1,280 |  |
| A1 mined by A | observer | `002104ed42f3` | **connected** | 1 | `002104ed42f3` | 1,280 |  |
| A2 mined by A (Alice->Bob 20) | A | `003c14c73616` | **connected** | 2 | `003c14c73616` | 2,304 |  |
| A2 mined by A (Alice->Bob 20) | observer | `003c14c73616` | **connected** | 2 | `003c14c73616` | 2,304 |  |
| B2 mined by B (Alice->Carol 21) | B | `0022cd480b3d` | **connected** | 2 | `0022cd480b3d` | 2,304 |  |
| B2 mined by B (Alice->Carol 21) | observer | `0022cd480b3d` | **side-branch** | 2 | `003c14c73616` | 2,304 | valid header, chain work 2304 <= active 2304 |
| B2 relayed to A | A | `0022cd480b3d` | **side-branch** | 2 | `003c14c73616` | 2,304 | valid header, chain work 2304 <= active 2304 |
| A2 relayed to B | B | `003c14c73616` | **side-branch** | 2 | `0022cd480b3d` | 2,304 | valid header, chain work 2304 <= active 2304 |
| B3 mined by B | B | `0010ec69a1f5` | **connected** | 3 | `0010ec69a1f5` | 3,328 |  |
| B3 mined by B | observer | `0010ec69a1f5` | **reorg** | 3 | `0010ec69a1f5` | 3,328 | reorganised: 1 block(s) disconnected, 2 connected — returned to mempool: 0bc547b63908 |
| B3 mined by B | A | `0010ec69a1f5` | **reorg** | 3 | `0010ec69a1f5` | 3,328 | reorganised: 1 block(s) disconnected, 2 connected — returned to mempool: 0bc547b63908 |

* All three nodes converged on the same tip: **True** (`0010ec69a1f5ae0c…`, height 3).
* Active chain: 00b47233c9c4 → 002104ed42f3 → 0022cd480b3d → 0010ec69a1f5
* UTXO-set hash after the reorg `ac286cfcaa1a8c23a5c911e8…` equals a fresh node that only saw the winning branch `ac286cfcaa1a8c23a5c911e8…`: **True**
* Stale transaction Alice→Bob 20 (`0bc547b63908`) still valid after the reorg: **False** (its input is now spent by `39196243eeef`).
* Final balances: alice 0, bob 85, carol 71, minerA 52, minerB 102.

## 3. Acceptance checks
| check | verdict | node response |
|---|---|---|
| Longer low-work branch (3 blocks @ 8 bits) vs shorter high-work branch (2 blocks @ 12 bits) | PASS | low branch active: height 3, work 1024; after high branch: height 2, work 8448; submits -> reorg, connected |
| Invalid proof of work (nonce changed) | PASS | rejected: bad-pow: header hash 3ef0e882a1d0fcb6… is above the target |
| Incorrect Merkle root (header re-mined with a wrong root) | PASS | rejected: bad-merkle-root: merkle root in header does not match the transactions |
| Excess coinbase value (51 > subsidy 50 + fees 0) | PASS | rejected: bad-coinbase-value: coinbase pays 51 > subsidy 50 + fees 0 (in block 00b675a2666a51bd…); active chain unchanged |
| Block containing an invalid transaction (Bob spends Alice's output) | PASS | rejected: wrong-key: input 0: public key does not match the p2pkh lock (in block 00ab5c8f73aa4ce1…); active chain unchanged |
| Reorg to a branch whose 2nd block is invalid (coinbase 999) | PASS | rejected: bad-coinbase-value: coinbase pays 999 > subsidy 50 + fees 0 (in block 00b0492f167e1a76…); active chain unchanged |

For every rejection the active tip and the UTXO-set hash were compared before and after: unchanged.

## 4. Hash rate and expected vs observed attempts
Raw SHA256d header hashing speed (pure Python + hashlib): **390,666 hashes/s**.
Expected attempts for target `T` = `2^256 / (T+1)` = `2^zero_bits`.

| zero bits | target | trials | expected attempts | observed mean | observed median | observed/expected | s per block | hashes/s |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 8 | `00ffffffffffffffffff…` | 200 | 256 | 241.4 | 143.0 | 0.943 | 0.0006 | 409,163 |
| 12 | `000fffffffffffffffff…` | 60 | 4,096 | 3,739.6 | 2,707.5 | 0.913 | 0.0131 | 286,234 |
| 16 | `0000ffffffffffffffff…` | 15 | 65,536 | 64,112.5 | 45,001 | 0.978 | 0.4908 | 130,640 |

Observed means are close to the expectation (the number of attempts is geometrically distributed,
so the median is ≈ 0.69 × the mean and individual blocks vary a lot). Each extra zero bit doubles
the expected work; 16 bits already takes tens of thousands of hashes, which is why toy targets are
kept low for a laptop demonstration.
