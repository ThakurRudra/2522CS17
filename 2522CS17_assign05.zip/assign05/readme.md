# Assignment 5 — Blocks, Proof of Work, Forks, and Reorganisation (`chain`)

**Student:** Rudra Pratap Singh · **Roll:** 2522CS17 · **Course:** Blockchain (Dr. Mayank Agarwal), IIT Patna

The Assignment 4 UTXO validator becomes a chain: block headers, toy Proof of Work, full block
validation, most-cumulative-work chain selection, reorganisation with undo data, and a two-miner
fork simulation. Merkle roots use the Assignment 2 rules (MT-1) over transaction ids.

## How to run
```bash
cd assign05
pip install -e .                 # installs the `chain` command
pip install -r requirements.txt
pytest -v                        # 22 tests
chain mine --blocks 3 --bits 12  # miner command
chain forksim                    # two miners, competing blocks, reorg
chain checks                     # acceptance checks
chain bench                      # hashes/s, expected vs observed attempts (8, 12, 16 zero bits)
chain report                     # docs/fork_report.md + docs/fork_diagram.png
```
Colab: `notebook/Assignment05_chain_Colab.ipynb` → Run all.

## Design
| Item | Rule |
|---|---|
| Header (116 B) | `version u32 ‖ prev_hash 32 ‖ merkle_root 32 ‖ timestamp u64 ‖ target 32 ‖ nonce u64` |
| Block hash | `SHA256(SHA256(header))`; valid PoW iff `int(hash) ≤ target` |
| Toy difficulty | `target = 2^(256−bits) − 1`; any block may choose `bits ≥ 4` (`POW_LIMIT`) — this is what makes "fewer but harder blocks" possible |
| Work | `work = ⌊2^256 / (target+1)⌋`; chain work = sum over the branch |
| Coinbase | first transaction, commits to `height`, pays ≤ subsidy 50 + fees |
| Merkle root | MT-1 over `[coinbase txid, tx txids…]` |
| Block checks | version, target ≤ limit, PoW, no duplicate txids, Merkle root, known parent (else orphan pool), parent not invalid, timestamp ≥ parent and ≤ now+2 h, coinbase height, every tx (A4 validator), coinbase value |
| Chain selection | most cumulative work; ties keep the first-seen tip |
| Reorg | disconnect to the fork point with undo data (restore spent outputs, delete created ones), connect the new branch block by block; if any block fails, mark it (and descendants) invalid and restore the old chain |

## Deliverables
* Chain manager `src/toychain/chain.py`, block/header `block.py`, miner `pow.py`, fork simulation `forksim.py`, report `report.py`
* Reused from A4: `tx.py`, `ledger.py` (+ `clone`), `wallet.py`, `keys.py`, `address.py`
* Reorganisation tests: `tests/test_blockchain.py`
* Report with block-header hex dump, branch diagram, acceptance checks and the PoW table: `docs/fork_report.md`, `docs/fork_diagram.png`

Video demo: *(add the unlisted YouTube link here)*
