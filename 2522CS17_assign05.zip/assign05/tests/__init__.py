"""Tests for toychain."""
