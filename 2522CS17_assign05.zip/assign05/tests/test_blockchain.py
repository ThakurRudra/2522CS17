"""Tests for blocks, PoW, chain selection and reorganisation (Assignment 5)."""
from dataclasses import replace

import pytest

from toychain.block import (HEADER_LEN, POW_LIMIT, Block, BlockHeader, Coinbase, merkle_root, target_from_bits,
                            work_from_target)
from toychain.forksim import T0, World, acceptance_checks, remine, two_miner_fork
from toychain.pow import difficulty_experiment, mine_block, solve
from toychain.tx import Transaction, TxIn, TxOut


@pytest.fixture
def w():
    return World(bits=8)


def extend(node, w, n, bits=8, parent=None, tag="m", txs=(), t=100):
    blocks = []
    for i in range(n):
        b, _, _ = mine_block(node, list(txs) if i == 0 else [], w.minerA.pkh, bits, tag, parent_hash=parent,
                             timestamp=T0 + t + i)
        r = node.submit_block(b)
        blocks.append((b, r))
        parent = b.hash
    return blocks


# ---------------------------------------------------------------- header and PoW
def test_header_is_116_bytes_and_roundtrips(w):
    h = w.genesis.header
    assert HEADER_LEN == 116 and len(h.serialize()) == 116
    assert BlockHeader.from_dict(h.to_dict()) == h


def test_pow_hash_below_target(w):
    node = w.node()
    b, attempts, _ = mine_block(node, [], w.minerA.pkh, 12, "x", timestamp=T0 + 1)
    assert int(b.hash, 16) <= target_from_bits(12) and b.hash.startswith("000")
    assert attempts == b.header.nonce + 1


def test_work_formula():
    assert work_from_target(target_from_bits(8)) == 256
    assert work_from_target(target_from_bits(16)) == 65536


def test_solve_respects_max_attempts():
    h = BlockHeader(1, "00" * 32, "11" * 32, 0, target_from_bits(40), 0)
    with pytest.raises(RuntimeError):
        solve(h, max_attempts=100)


def test_observed_attempts_close_to_expected():
    rows = difficulty_experiment((6, 8), (300, 150))
    for r in rows:
        assert 0.7 < r["ratio_observed_expected"] < 1.35


# ---------------------------------------------------------------- block validation
def test_connect_block_with_payment(w):
    node = w.node()
    pay = w.alice.build_payment(node.ledger, w.bob.pkh, 85, 2)
    (b, r), = extend(node, w, 1, txs=[pay])
    assert r.status == "connected" and node.height == 1
    assert node.ledger.balance(w.bob.pkh) == 85 and node.ledger.balance(w.minerA.pkh) == 52


def test_invalid_pow_rejected(w):
    node = w.node()
    b, _, _ = mine_block(node, [], w.minerA.pkh, 12, "x", timestamp=T0 + 1)
    bad = replace(b, header=replace(b.header, nonce=b.header.nonce + 1))
    while bad.header.pow_ok():
        bad = replace(bad, header=replace(bad.header, nonce=bad.header.nonce + 1))
    tip = node.tip.block.hash
    assert node.submit_block(bad).status == "rejected" and node.tip.block.hash == tip


def test_target_above_pow_limit_rejected(w):
    node = w.node()
    b, _, _ = mine_block(node, [], w.minerA.pkh, 8, "x", timestamp=T0 + 1)
    easy = remine(node, b, target=POW_LIMIT * 2 + 1)
    r = node.submit_block(easy)
    assert r.status == "rejected" and "bad-target" in r.reason


def test_wrong_merkle_root_rejected(w):
    node = w.node()
    b, _, _ = mine_block(node, [], w.minerA.pkh, 8, "x", timestamp=T0 + 1)
    r = node.submit_block(remine(node, b, merkle_root="cd" * 32))
    assert r.status == "rejected" and "bad-merkle-root" in r.reason and node.height == 0


def test_tx_swapped_out_after_mining_breaks_merkle_root(w):
    node = w.node()
    pay = w.alice.build_payment(node.ledger, w.bob.pkh, 85, 2)
    b, _, _ = mine_block(node, [pay], w.minerA.pkh, 8, "x", timestamp=T0 + 1)
    other = w.alice.build_payment(node.ledger, w.carol.pkh, 85, 2)
    r = node.submit_block(replace(b, txs=(other,)))
    assert "bad-merkle-root" in r.reason


def test_excess_coinbase_rejected(w):
    node = w.node()
    cb = Coinbase(1, (TxOut(51, w.minerA.pkh),), "greedy")
    blk = Block(BlockHeader(1, w.genesis.hash, merkle_root([cb.txid]), T0 + 5, target_from_bits(8), 0), cb, ())
    r = node.submit_block(remine(node, blk))
    assert r.status == "rejected" and "bad-coinbase-value" in r.reason and node.height == 0


def test_coinbase_may_claim_fees(w):
    node = w.node()
    pay = w.alice.build_payment(node.ledger, w.bob.pkh, 85, 2)
    b, _, _ = mine_block(node, [pay], w.minerA.pkh, 8, "x", timestamp=T0 + 1)
    assert b.coinbase.total() == 52 and node.submit_block(b).status == "connected"


def test_block_with_invalid_tx_rejected_entirely(w):
    node = w.node()
    good = w.alice.build_payment(node.ledger, w.bob.pkh, 85, 2)
    steal = w.bob.sign(Transaction(1, (TxIn(good.inputs[0].prev),), (TxOut(70, w.bob.pkh),), 0))
    cb = Coinbase(1, (TxOut(52, w.minerA.pkh),), "x")
    blk = Block(BlockHeader(1, w.genesis.hash, merkle_root([cb.txid, good.txid, steal.txid]), T0 + 5,
                            target_from_bits(8), 0), cb, (good, steal))
    before = node.ledger.state_hash()
    r = node.submit_block(remine(node, blk))
    assert r.status == "rejected" and node.height == 0 and node.ledger.state_hash() == before
    assert node.ledger.balance(w.bob.pkh) == 0  # the valid tx in the same block was NOT applied


def test_wrong_coinbase_height_rejected(w):
    node = w.node()
    cb = Coinbase(7, (TxOut(50, w.minerA.pkh),), "x")
    blk = Block(BlockHeader(1, w.genesis.hash, merkle_root([cb.txid]), T0 + 5, target_from_bits(8), 0), cb, ())
    assert "bad-coinbase-height" in node.submit_block(remine(node, blk)).reason


def test_timestamp_before_parent_rejected(w):
    node = w.node()
    b, _, _ = mine_block(node, [], w.minerA.pkh, 8, "x", timestamp=T0 + 5)
    assert "bad-timestamp" in node.submit_block(remine(node, b, timestamp=T0 - 100)).reason


def test_duplicate_and_orphan(w):
    node = w.node()
    b1, _, _ = mine_block(node, [], w.minerA.pkh, 8, "x", timestamp=T0 + 5)
    helper = w.node(); helper.submit_block(b1)
    b2, _, _ = mine_block(helper, [], w.minerA.pkh, 8, "x", timestamp=T0 + 6)
    assert node.submit_block(b2).status == "orphan"
    r = node.submit_block(b1)
    assert node.height == 2 and b2.hash in r.connected  # orphan adopted when the parent arrived
    assert node.submit_block(b1).status == "duplicate"


# ---------------------------------------------------------------- chain selection and reorg
def test_most_work_beats_most_blocks(w):
    node = w.node()
    low = extend(node, w, 3, bits=8, tag="low")
    assert node.height == 3
    high = extend(node, w, 2, bits=12, parent=w.genesis.hash, tag="high", t=200)
    assert node.tip.block.hash == high[-1][0].hash and node.height == 2
    assert high[0][1].status == "reorg"


def test_equal_work_keeps_first_seen(w):
    node = w.node()
    (a, _), = extend(node, w, 1, tag="A")
    (b, r), = extend(node, w, 1, parent=w.genesis.hash, tag="B", t=300)
    assert r.status == "side-branch" and node.tip.block.hash == a.hash


def test_reorg_restores_spent_outputs_and_final_utxo_correct(w):
    node = w.node()
    pay = w.alice.build_payment(node.ledger, w.bob.pkh, 85, 2)
    extend(node, w, 1, tag="A", txs=[pay])
    assert node.ledger.balance(w.bob.pkh) == 85
    branch = extend(node, w, 2, parent=w.genesis.hash, tag="B", t=400)  # without Alice's payment
    assert branch[-1][1].status == "reorg"
    assert node.ledger.balance(w.alice.pkh) == 110 and node.ledger.balance(w.bob.pkh) == 0
    assert pay.txid in [t.txid for t in branch[-1][1].returned_txs]
    fresh = w.node()
    for b, _ in branch:
        fresh.submit_block(b)
    assert fresh.ledger.state_hash() == node.ledger.state_hash()


def test_two_miner_fork_converges():
    s = two_miner_fork()
    assert s["converged"] and s["final_height"] == 3
    assert s["utxo_hash_observer"] == s["utxo_hash_fresh_replay"]
    assert s["t_bob_still_valid"] is False
    assert s["final_balances"]["carol"] == 71 and s["final_balances"]["bob"] == 85


def test_failed_reorg_leaves_active_chain_unchanged(w):
    node = w.node()
    extend(node, w, 1, tag="A")
    tip, uh = node.tip.block.hash, node.ledger.state_hash()
    (s1, _), = extend(node, w, 1, parent=w.genesis.hash, tag="B", t=500)
    cb = Coinbase(2, (TxOut(999, w.minerB.pkh),), "B")
    s2 = remine(node, Block(BlockHeader(1, s1.hash, merkle_root([cb.txid]), T0 + 600, target_from_bits(8), 0), cb, ()))
    r = node.submit_block(s2)
    assert r.status == "rejected" and node.tip.block.hash == tip and node.ledger.state_hash() == uh
    (s3, r3), = extend(node, w, 1, parent=s2.hash, tag="B", t=700)
    assert r3.status == "rejected" and "bad-ancestry" in r3.reason  # descendants of invalid blocks are invalid


def test_acceptance_check_suite():
    assert all(c["pass"] for c in acceptance_checks())
