"""Two-miner fork simulation and the acceptance-check scenarios."""
from __future__ import annotations

from dataclasses import replace

from .block import Block, BlockHeader, Coinbase, merkle_root
from .chain import ChainManager, make_genesis
from .pow import mine_block, solve
from .tx import Transaction, TxIn, TxOut
from .wallet import Wallet

T0 = 1_767_225_600  # 2026-01-01 00:00:00 UTC, fixed timestamps keep the run reproducible in shape


class World:
    def __init__(self, bits: int = 8):
        self.alice, self.bob, self.carol = (Wallet.generate(n) for n in ("alice", "bob", "carol"))
        self.minerA, self.minerB = Wallet.generate("minerA"), Wallet.generate("minerB")
        self.names = {w.pkh: w.name for w in (self.alice, self.bob, self.carol, self.minerA, self.minerB)}
        self.genesis = make_genesis([TxOut(40, self.alice.pkh), TxOut(70, self.alice.pkh), TxOut(50, self.carol.pkh)],
                                    bits=bits, timestamp=T0)
        self.bits = bits

    def node(self) -> ChainManager:
        return ChainManager(self.genesis, clock=lambda: T0 + 10**6)

    def balances(self, node: ChainManager) -> dict:
        return {n: node.ledger.balance(p) for p, n in self.names.items()}


def two_miner_fork(bits: int = 10) -> dict:
    """Miner A and miner B extend the same tip with conflicting spends; B's branch gets one more block."""
    w = World(bits=8)
    nodeA, nodeB, observer = w.node(), w.node(), w.node()
    log = []

    def broadcast(block, to, label):
        for name, n in to:
            r = n.submit_block(block)
            log.append({"event": label, "node": name, "block": block.hash[:12], "status": r.status,
                        "height": n.height, "tip": n.tip.block.hash[:12], "work": n.chain_work(), "reason": r.reason,
                        "returned": [t.txid[:12] for t in r.returned_txs]})
        return r

    # height 1: miner A confirms Alice -> Bob 85 (fee 2); everybody agrees
    pay = w.alice.build_payment(nodeA.ledger, w.bob.pkh, 85, 2)
    A1, _, _ = mine_block(nodeA, [pay], w.minerA.pkh, bits, "minerA", timestamp=T0 + 60)
    broadcast(A1, [("A", nodeA), ("B", nodeB), ("observer", observer)], "A1 mined by A")

    # height 2: Alice double-spends her 23-unit change: one tx to Bob, one to Carol
    change = [op for op, o in nodeA.ledger.utxos_for(w.alice.pkh)][0]
    t_bob = w.alice.sign(Transaction(1, (TxIn(change),), (TxOut(20, w.bob.pkh),), 3))
    t_carol = w.alice.sign(Transaction(1, (TxIn(change),), (TxOut(21, w.carol.pkh),), 2))
    A2, _, _ = mine_block(nodeA, [t_bob], w.minerA.pkh, bits, "minerA", timestamp=T0 + 120)
    B2, _, _ = mine_block(nodeB, [t_carol], w.minerB.pkh, bits, "minerB", timestamp=T0 + 121)
    broadcast(A2, [("A", nodeA), ("observer", observer)], "A2 mined by A (Alice->Bob 20)")
    broadcast(B2, [("B", nodeB), ("observer", observer)], "B2 mined by B (Alice->Carol 21)")
    snap_fork = {"observer_tip": observer.tip.block.hash[:12], "balances": w.balances(observer)}
    broadcast(B2, [("A", nodeA)], "B2 relayed to A")
    broadcast(A2, [("B", nodeB)], "A2 relayed to B")

    # height 3: miner B extends its own branch -> more cumulative work -> everyone reorgs
    B3, _, _ = mine_block(nodeB, [], w.minerB.pkh, bits, "minerB", timestamp=T0 + 180)
    broadcast(B3, [("B", nodeB), ("observer", observer), ("A", nodeA)], "B3 mined by B")

    # independent check: a fresh node that only ever sees the winning branch
    fresh = w.node()
    for b in (A1, B2, B3):
        fresh.submit_block(b)
    tips = {n: c.tip.block.hash for n, c in (("A", nodeA), ("B", nodeB), ("observer", observer))}
    return {
        "world": w, "blocks": {"G": w.genesis, "A1": A1, "A2": A2, "B2": B2, "B3": B3},
        "log": log, "at_fork": snap_fork,
        "converged": len(set(tips.values())) == 1,
        "final_tip": observer.tip.block.hash, "final_height": observer.height,
        "final_balances": w.balances(observer),
        "utxo_hash_observer": observer.ledger.state_hash(),
        "utxo_hash_fresh_replay": fresh.ledger.state_hash(),
        "t_bob_still_valid": _still_valid(observer, t_bob), "t_bob": t_bob.txid, "t_carol": t_carol.txid,
        "active_chain": [h[:12] for h in observer.active],
        "work": {k: observer.index[b.hash].chain_work for k, b in (("A2", A2), ("B2", B2), ("B3", B3))},
    }


def _still_valid(node, tx) -> bool:
    try:
        node.ledger.clone().validate(tx)
        return True
    except Exception:
        return False


def remine(chain, block: Block, **header_changes) -> Block:
    """Rebuild a block with modified header fields and a fresh valid nonce (to isolate one rule)."""
    h = replace(block.header, **header_changes, nonce=0)
    nonce, _ = solve(h)
    return replace(block, header=replace(h, nonce=nonce))


def acceptance_checks() -> list[dict]:
    rows = []
    w = World(bits=8)

    # (a) longer but lower-work branch loses to shorter higher-work branch
    n = w.node()
    low = []
    parent = None
    for i in range(3):
        b, _, _ = mine_block(n, [], w.minerA.pkh, 8, "low-work", parent_hash=parent, timestamp=T0 + 10 + i)
        n.submit_block(b)
        low.append(b)
        parent = b.hash
    before = (n.height, n.chain_work())
    parent = w.genesis.hash
    high, statuses = [], []
    for i in range(2):
        b, _, _ = mine_block(n, [], w.minerB.pkh, 12, "high-work", parent_hash=parent, timestamp=T0 + 20 + i)
        statuses.append(n.submit_block(b).status)
        high.append(b)
        parent = b.hash
    rows.append({"check": "Longer low-work branch (3 blocks @ 8 bits) vs shorter high-work branch (2 blocks @ 12 bits)",
                 "result": f"low branch active: height {before[0]}, work {before[1]}; after high branch: height {n.height}, "
                           f"work {n.chain_work()}; submits -> {', '.join(statuses)}",
                 "pass": n.tip.block.hash == high[-1].hash and n.height == 2})

    # base chain for the rejection checks
    n = w.node()
    pay = w.alice.build_payment(n.ledger, w.bob.pkh, 85, 2)
    b1, _, _ = mine_block(n, [pay], w.minerA.pkh, 8, "A", timestamp=T0 + 60)
    n.submit_block(b1)

    def expect_reject(label, block, code):
        tip, uh = n.tip.block.hash, n.ledger.state_hash()
        r = n.submit_block(block)
        rows.append({"check": label, "result": f"{r.status}: {r.reason}",
                     "pass": r.status == "rejected" and code in r.reason and tip == n.tip.block.hash
                     and uh == n.ledger.state_hash()})

    good2, _, _ = mine_block(n, [], w.minerA.pkh, 8, "A", timestamp=T0 + 120)
    bad_pow = replace(good2, header=replace(good2.header, nonce=good2.header.nonce + 1))
    while bad_pow.header.pow_ok():
        bad_pow = replace(bad_pow, header=replace(bad_pow.header, nonce=bad_pow.header.nonce + 1))
    expect_reject("Invalid proof of work (nonce changed)", bad_pow, "bad-pow")
    expect_reject("Incorrect Merkle root (header re-mined with a wrong root)",
                  remine(n, good2, merkle_root="ab" * 32), "bad-merkle-root")
    greedy_cb = Coinbase(2, (TxOut(51, w.minerA.pkh),), "greedy")
    greedy = Block(good2.header, greedy_cb, ())
    greedy = remine(n, greedy, merkle_root=merkle_root([greedy_cb.txid]))
    expect_reject("Excess coinbase value (51 > subsidy 50 + fees 0)", greedy, "bad-coinbase-value")
    change = [op for op, o in n.ledger.utxos_for(w.alice.pkh)][0]
    steal = w.bob.sign(Transaction(1, (TxIn(change),), (TxOut(23, w.bob.pkh),), 0))
    bad_tx_cb = Coinbase(2, (TxOut(50, w.minerA.pkh),), "A")
    bad_tx_block = Block(good2.header, bad_tx_cb, (steal,))
    bad_tx_block = remine(n, bad_tx_block, merkle_root=merkle_root([bad_tx_cb.txid, steal.txid]))
    expect_reject("Block containing an invalid transaction (Bob spends Alice's output)", bad_tx_block, "wrong-key")

    # (f) reorg whose second block is invalid: aborted, old chain restored
    tip, uh = n.tip.block.hash, n.ledger.state_hash()
    side1, _, _ = mine_block(n, [], w.minerB.pkh, 8, "B", parent_hash=w.genesis.hash, timestamp=T0 + 70)
    n.submit_block(side1)
    bad_cb = Coinbase(2, (TxOut(999, w.minerB.pkh),), "B")
    side2 = Block(BlockHeader(1, side1.hash, merkle_root([bad_cb.txid]), T0 + 130, side1.header.target, 0), bad_cb, ())
    side2 = remine(n, side2)
    r = n.submit_block(side2)
    rows.append({"check": "Reorg to a branch whose 2nd block is invalid (coinbase 999)",
                 "result": f"{r.status}: {r.reason}",
                 "pass": r.status == "rejected" and tip == n.tip.block.hash and uh == n.ledger.state_hash()})
    return rows
