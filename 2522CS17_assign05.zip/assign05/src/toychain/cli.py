"""`chain` CLI - miner command, fork simulation, PoW benchmark, report.

  chain mine --blocks 5 --bits 12        mine N blocks on a fresh local chain and print them
  chain forksim                          two miners, competing blocks, reorganisation
  chain checks                           acceptance checks (low vs high work, invalid blocks)
  chain bench --bits 8 12 16             hashes/s and expected vs observed attempts
  chain report [--quick]                 writes docs/fork_report.md + docs/fork_diagram.png
"""
from __future__ import annotations

import argparse
import sys

from .block import SUBSIDY
from .chain import make_genesis
from .forksim import T0, World, acceptance_checks, two_miner_fork
from .pow import difficulty_experiment, hashrate, mine_block
from .tx import TxOut


def cmd_mine(a):
    w = World(bits=8)
    node = w.node()
    print(f"genesis {w.genesis.hash}  (premine alice 40+70, carol 50)")
    txs = [w.alice.build_payment(node.ledger, w.bob.pkh, 85, 2)]
    for i in range(a.blocks):
        b, attempts, dt = mine_block(node, txs if i == 0 else [], w.minerA.pkh, a.bits, "miner", timestamp=T0 + 60 * (i + 1))
        r = node.submit_block(b)
        print(f"height {node.height}: {b.hash}  nonce={b.header.nonce:<8} attempts={attempts:<8} "
              f"{attempts / dt if dt else 0:,.0f} H/s  txs={len(b.txs)}  {r.status}")
    print(f"tip work {node.chain_work():,}; miner balance {node.ledger.balance(w.minerA.pkh)} "
          f"(= {a.blocks} x {SUBSIDY} + fees 2)")
    print("\nheader of the tip:\n" + node.tip.block.header.hexdump())
    return 0


def cmd_forksim(a):
    s = two_miner_fork()
    for e in s["log"]:
        extra = f"  returned={e['returned']}" if e["returned"] else ""
        print(f"{e['event']:32s} -> {e['node']:8s} {e['status']:11s} height={e['height']} tip={e['tip']} "
              f"work={e['work']:,}{extra}")
    print(f"\nconverged={s['converged']} final height={s['final_height']} balances={s['final_balances']}")
    print(f"UTXO hash after reorg == fresh replay: {s['utxo_hash_observer'] == s['utxo_hash_fresh_replay']}")
    print(f"stale Alice->Bob tx still valid: {s['t_bob_still_valid']}")
    return 0


def cmd_checks(a):
    ok = True
    for c in acceptance_checks():
        ok &= c["pass"]
        print(f"[{'PASS' if c['pass'] else 'FAIL'}] {c['check']}\n        {c['result']}")
    return 0 if ok else 1


def cmd_bench(a):
    print(f"raw hash rate: {hashrate(1.0):,.0f} SHA256d/s")
    print(f"{'bits':>4} {'expected':>9} {'obs mean':>10} {'ratio':>6} {'s/block':>8} {'H/s':>10}")
    for r in difficulty_experiment(tuple(a.bits), tuple(a.trials)):
        print(f"{r['zero_bits']:>4} {r['expected_attempts']:>9,} {r['observed_mean_attempts']:>10,} "
              f"{r['ratio_observed_expected']:>6} {r['mean_seconds_per_block']:>8} {r['hashes_per_second']:>10,}")
    return 0


def cmd_report(a):
    from .report import build
    r = build(a.outdir, a.quick)
    print(f"wrote {a.outdir}/fork_report.md and fork_diagram.png; checks passed: "
          f"{sum(c['pass'] for c in r['checks'])}/{len(r['checks'])}")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="chain", description="Toy PoW blockchain with forks and reorgs")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("mine"); s.add_argument("--blocks", type=int, default=3); s.add_argument("--bits", type=int, default=12)
    s.set_defaults(func=cmd_mine)
    sub.add_parser("forksim").set_defaults(func=cmd_forksim)
    sub.add_parser("checks").set_defaults(func=cmd_checks)
    s = sub.add_parser("bench"); s.add_argument("--bits", type=int, nargs="+", default=[8, 12, 16])
    s.add_argument("--trials", type=int, nargs="+", default=[200, 60, 15]); s.set_defaults(func=cmd_bench)
    s = sub.add_parser("report"); s.add_argument("--outdir", default="docs"); s.add_argument("--quick", action="store_true")
    s.set_defaults(func=cmd_report)
    a = p.parse_args(argv)
    return a.func(a)


if __name__ == "__main__":
    sys.exit(main())
