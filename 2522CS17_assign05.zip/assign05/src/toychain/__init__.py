"""toychain - blocks, proof of work, forks and reorganisation (Assignment 5)."""
__version__ = "1.0.0"
