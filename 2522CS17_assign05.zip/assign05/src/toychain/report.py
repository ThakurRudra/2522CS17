"""Builds docs/fork_report.md: header hex dump, branch diagram, fork trace, acceptance checks, PoW table."""
from __future__ import annotations

import json
import os
import platform

from .forksim import acceptance_checks, two_miner_fork
from .pow import difficulty_experiment, hashrate


def draw_branches(sim: dict, path: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch

    b = sim["blocks"]
    pos = {"G": (0, 0), "A1": (1, 0), "A2": (2, 0.9), "B2": (2, -0.9), "B3": (3, -0.9)}
    active = {"G", "A1", "B2", "B3"}
    info = {"G": "genesis\npremine", "A1": "miner A\nAlice→Bob 85", "A2": "miner A\nAlice→Bob 20\n(STALE)",
            "B2": "miner B\nAlice→Carol 21", "B3": "miner B\n(empty)"}
    fig, ax = plt.subplots(figsize=(11, 4.2))
    for k, (x, y) in pos.items():
        col = "#c9ead3" if k in active else "#f4cccc"
        edge = "#38761d" if k in active else "#990000"
        ax.add_patch(FancyBboxPatch((x - 0.38, y - 0.42), 0.76, 0.84, boxstyle="round,pad=0.02", fc=col, ec=edge, lw=2))
        ax.text(x, y + 0.24, f"{k}  h={0 if k == 'G' else int(k[1])}", ha="center", fontsize=10, weight="bold")
        ax.text(x, y - 0.02, b[k].hash[:10] + "…", ha="center", fontsize=8, family="monospace")
        ax.text(x, y - 0.25, info[k], ha="center", va="center", fontsize=7.5)
    for child, parent in (("A1", "G"), ("A2", "A1"), ("B2", "A1"), ("B3", "B2")):
        (x0, y0), (x1, y1) = pos[child], pos[parent]
        ax.annotate("", xy=(x1 + 0.38, y1), xytext=(x0 - 0.38, y0),
                    arrowprops=dict(arrowstyle="->", lw=1.6, color="#38761d" if child in active else "#990000"))
    w = sim["work"]
    ax.text(2.6, 1.45, f"branch A work {w['A2']:,}", color="#990000", fontsize=9)
    ax.text(3.0, -1.55, f"branch B work {w['B3']:,}  ← most work, active", color="#38761d", fontsize=9, ha="center")
    ax.set_xlim(-0.6, 3.8); ax.set_ylim(-1.8, 1.7); ax.axis("off")
    ax.set_title("Competing branches after the fork at height 2 (arrows point to the parent block)")
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def build(outdir: str = "docs", quick: bool = False) -> dict:
    os.makedirs(outdir, exist_ok=True)
    sim = two_miner_fork()
    checks = acceptance_checks()
    hps = hashrate(0.5 if quick else 1.5)
    trials = (60, 20, 5) if quick else (200, 60, 15)
    pow_rows = difficulty_experiment((8, 12, 16), trials)
    try:
        draw_branches(sim, os.path.join(outdir, "fork_diagram.png"))
    except ImportError:
        pass
    b = sim["blocks"]
    hdr = b["B3"].header
    log_rows = "\n".join(
        f"| {e['event']} | {e['node']} | `{e['block']}` | **{e['status']}** | {e['height']} | `{e['tip']}` | {e['work']:,} | "
        f"{e['reason'] or ''}{' — returned to mempool: ' + ', '.join(e['returned']) if e['returned'] else ''} |"
        for e in sim["log"])
    chk_rows = "\n".join(f"| {c['check']} | {'PASS' if c['pass'] else 'FAIL'} | {c['result']} |" for c in checks)
    pow_tab = "\n".join(
        f"| {r['zero_bits']} | `{r['target'][:20]}…` | {r['trials']} | {r['expected_attempts']:,} | "
        f"{r['observed_mean_attempts']:,} | {r['observed_median_attempts']:,} | {r['ratio_observed_expected']} | "
        f"{r['mean_seconds_per_block']} | {r['hashes_per_second']:,} |" for r in pow_rows)
    md = f"""# Fork report — blocks, proof of work, forks and reorganisation

Student: Rudra Pratap Singh (2522CS17) · Assignment 5 · machine: {platform.system()} {platform.machine()}, Python {platform.python_version()}

## 1. Block header hex dump (block B3, the winning tip)
Header layout: `version u32 | prev_hash 32 | merkle_root 32 | timestamp u64 | target 32 | nonce u64` = 116 bytes, big-endian.
PoW rule: `int(SHA256d(header)) ≤ target`.
```
{hdr.hexdump()}
```
Header JSON:
```json
{json.dumps(hdr.to_dict(), indent=2)}
```

## 2. Two miners, competing blocks, fork resolution
Alice's 23-unit change is double-spent: miner A includes *Alice→Bob 20* in **A2**, miner B includes
*Alice→Carol 21* in **B2**, both on top of **A1**. With equal work every node keeps the block it saw first.
Miner B then finds **B3**; branch B now has more cumulative work, so every node disconnects A2 (restoring
Alice's spent output), connects B2 and B3, and the conflicting Alice→Bob transaction is returned but is
no longer valid.

![branches](fork_diagram.png)

```mermaid
graph RL
  A1[A1 h=1 {b['A1'].hash[:8]}] --> G[G h=0 {b['G'].hash[:8]}]
  A2[A2 h=2 {b['A2'].hash[:8]} STALE] --> A1
  B2[B2 h=2 {b['B2'].hash[:8]}] --> A1
  B3[B3 h=3 {b['B3'].hash[:8]} TIP] --> B2
  style A2 fill:#f4cccc,stroke:#990000
  style B2 fill:#c9ead3,stroke:#38761d
  style B3 fill:#c9ead3,stroke:#38761d
```

| event | node | block | status | height | tip | chain work | details |
|---|---|---|---|---:|---|---:|---|
{log_rows}

* All three nodes converged on the same tip: **{sim['converged']}** (`{sim['final_tip'][:16]}…`, height {sim['final_height']}).
* Active chain: {' → '.join(sim['active_chain'])}
* UTXO-set hash after the reorg `{sim['utxo_hash_observer'][:24]}…` equals a fresh node that only saw the winning branch `{sim['utxo_hash_fresh_replay'][:24]}…`: **{sim['utxo_hash_observer'] == sim['utxo_hash_fresh_replay']}**
* Stale transaction Alice→Bob 20 (`{sim['t_bob'][:12]}`) still valid after the reorg: **{sim['t_bob_still_valid']}** (its input is now spent by `{sim['t_carol'][:12]}`).
* Final balances: {', '.join(f'{k} {v}' for k, v in sim['final_balances'].items())}.

## 3. Acceptance checks
| check | verdict | node response |
|---|---|---|
{chk_rows}

For every rejection the active tip and the UTXO-set hash were compared before and after: unchanged.

## 4. Hash rate and expected vs observed attempts
Raw SHA256d header hashing speed (pure Python + hashlib): **{hps:,.0f} hashes/s**.
Expected attempts for target `T` = `2^256 / (T+1)` = `2^zero_bits`.

| zero bits | target | trials | expected attempts | observed mean | observed median | observed/expected | s per block | hashes/s |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
{pow_tab}

Observed means are close to the expectation (the number of attempts is geometrically distributed,
so the median is ≈ 0.69 × the mean and individual blocks vary a lot). Each extra zero bit doubles
the expected work; 16 bits already takes tens of thousands of hashes, which is why toy targets are
kept low for a laptop demonstration.
"""
    with open(os.path.join(outdir, "fork_report.md"), "w") as fh:
        fh.write(md)
    with open(os.path.join(outdir, "pow_experiment.json"), "w") as fh:
        json.dump({"hashes_per_second": hps, "rows": pow_rows}, fh, indent=2)
    return {"sim": sim, "checks": checks, "pow": pow_rows, "hps": hps}
