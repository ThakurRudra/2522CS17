"""Tests for hashlab (Assignment 1). Run: pytest -v"""
import hashlib
import json
import os
import shutil
import subprocess
import sys

import pytest

from hashlab import core
from hashlab.cli import main

SRC = os.path.join(os.path.dirname(__file__), "..", "src")


def run_cli(*args, stdin=None):
    env = dict(os.environ, PYTHONPATH=os.path.abspath(SRC))
    return subprocess.run([sys.executable, "-m", "hashlab", *args], capture_output=True,
                          text=True, input=stdin, env=env)


# ---------------------------------------------------------------- known vectors (FIPS 180-4)
@pytest.mark.parametrize("msg,expected", [
    (b"", "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"),
    (b"abc", "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"),
    (b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
     "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"),
])
def test_known_vectors(msg, expected):
    assert core.sha256_bytes(msg).hex == expected


def test_base64_matches_hex():
    d = core.sha256_bytes(b"abc")
    import base64
    assert base64.b64decode(d.b64) == bytes.fromhex(d.hex)
    assert len(d.b64) == 44


def test_text_mode_example_byte_count():
    d = core.sha256_bytes(core.text_to_bytes("Alice pays Bob 10"))
    assert d.length == 17
    # the assignment example shows 18 bytes: that is the same text plus a trailing LF
    assert core.sha256_bytes(b"Alice pays Bob 10\n").length == 18


def test_trailing_newline_distinguished():
    a = core.sha256_bytes(b"Alice pays Bob 10")
    b = core.sha256_bytes(b"Alice pays Bob 10\n")
    assert a.hex != b.hex


def test_utf8_multibyte_length():
    assert core.sha256_bytes(core.text_to_bytes("₹10")).length == 5  # '₹' is 3 bytes


# ---------------------------------------------------------------- hex parsing
@pytest.mark.parametrize("good,expected", [("", b""), ("00", b"\x00"), ("0xDEADbeef", b"\xde\xad\xbe\xef")])
def test_hex_accepts(good, expected):
    assert core.parse_hex(good) == expected


@pytest.mark.parametrize("bad", ["abc", "zz", "12 34", "0x1", "0xg0", "12\n", "+12", "１２"])
def test_hex_rejects_malformed(bad):
    with pytest.raises(core.HashlabError):
        core.parse_hex(bad)


def test_cli_rejects_malformed_hex_exit_code():
    r = run_cli("hex", "abc")
    assert r.returncode == 2 and "malformed hex" in r.stderr


# ---------------------------------------------------------------- files vs independent utility
def test_file_matches_hashlib_and_sha256sum(tmp_path):
    p = tmp_path / "sample.bin"
    p.write_bytes(os.urandom(3 * 1024 * 1024 + 17))  # crosses chunk boundaries
    d = core.sha256_file(str(p))
    assert d.hex == hashlib.sha256(p.read_bytes()).hexdigest()
    tool = shutil.which("sha256sum") or shutil.which("shasum")
    if tool:
        cmd = [tool] if tool.endswith("sha256sum") else [tool, "-a", "256"]
        out = subprocess.run(cmd + [str(p)], capture_output=True, text=True).stdout.split()[0]
        assert out == d.hex


def test_empty_file(tmp_path):
    p = tmp_path / "empty"
    p.write_bytes(b"")
    assert core.sha256_file(str(p)).hex == hashlib.sha256(b"").hexdigest()


@pytest.mark.parametrize("chunk", [1, 7, 64, 4096])
def test_chunk_size_does_not_change_digest(tmp_path, chunk):
    p = tmp_path / "c.bin"
    p.write_bytes(b"blockchain" * 1000)
    assert core.sha256_file(str(p), chunk).hex == hashlib.sha256(b"blockchain" * 1000).hexdigest()


def test_missing_file_cli():
    r = run_cli("file", "/no/such/file.bin")
    assert r.returncode == 2


# ---------------------------------------------------------------- avalanche
def test_flip_bit_msb_first():
    assert core.flip_bit(b"\x00", 0) == b"\x80"
    assert core.flip_bit(b"\x00", 7) == b"\x01"
    assert core.flip_bit(b"\x00\x00", 8) == b"\x00\x80"


def test_flip_twice_restores():
    data = b"Alice pays Bob 10"
    assert core.flip_bit(core.flip_bit(data, 7), 7) == data


@pytest.mark.parametrize("bit", [-1, 136])
def test_flip_bit_out_of_range(bit):
    with pytest.raises(core.HashlabError):
        core.flip_bit(b"Alice pays Bob 10", bit)


def test_avalanche_range_and_example():
    res = core.avalanche(b"Alice pays Bob 10", 7)
    assert 0 < res["changed_bits_in_digest"] <= 256
    assert res["sha256_original"] != res["sha256_flipped"]


def test_avalanche_mean_close_to_half():
    stats = core.avalanche_all_bits(b"Alice pays Bob 10")
    assert stats["input_bits"] == 136
    assert 118 <= stats["mean"] <= 138  # binomial(256, 0.5): mean 128, sd 8 -> sd of mean ~0.7


def test_hamming_distance():
    assert core.hamming_distance(b"\x00\xff", b"\xff\xff") == 8


def test_cli_avalanche_output():
    r = run_cli("avalanche", "--text", "Alice pays Bob 10", "--bit", "7")
    assert r.returncode == 0
    line = [l for l in r.stdout.splitlines() if l.startswith("changed_bits_in_digest")][0]
    assert 0 <= int(line.split(":")[1]) <= 256


# ---------------------------------------------------------------- canonical JSON
def test_canonical_key_order_and_whitespace():
    a = core.canonical_json('{"b": 2, "a": {"y": 1, "x": [3, 2, 1]}}')
    b = core.canonical_json('{\n  "a":{"x":[3,2,1],"y":1},\n  "b":2\n}')
    assert a["canonical"] == '{"a":{"x":[3,2,1],"y":1},"b":2}'
    assert a["sha256"] == b["sha256"]


def test_canonical_keeps_int_vs_string_distinct():
    assert core.canonical_json('{"amount":10}')["sha256"] != core.canonical_json('{"amount":"10"}')["sha256"]


def test_canonical_utf8_not_escaped():
    res = core.canonical_json('{"name":"caf\\u00e9"}')
    assert res["canonical"] == '{"name":"café"}' and res["bytes"] == 16  # é is 2 bytes in UTF-8


@pytest.mark.parametrize("bad", ['{"a":1.5}', '{"a":1e3}', '{"a":NaN}', '{"a":1,"a":2}',
                                 '[1,2]', '"x"', '{"a":', '{"a":Infinity}'])
def test_canonical_rejects(bad):
    with pytest.raises(core.HashlabError):
        core.canonical_json(bad)


def test_canonical_cli_from_stdin():
    r = run_cli("canonical-json", "-", stdin='{"to":"bob","from":"alice"}')
    assert r.returncode == 0
    assert 'canonical: {"from":"alice","to":"bob"}' in r.stdout


# ---------------------------------------------------------------- look-alike demonstration
def test_lookalikes_all_differ_except_canonical():
    rows = core.lookalike_pairs()
    assert all(not r["same_hash"] for r in rows[:-1])
    assert rows[-1]["same_hash"] is True


def test_main_returns_zero_for_text(capsys):
    assert main(["text", "Alice pays Bob 10", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["bytes"] == 17
