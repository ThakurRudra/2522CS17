"""Acceptance check: hash a 100 MB file without memory growing by ~100 MB."""
import hashlib
import os
import resource
import subprocess
import sys
import tracemalloc

import pytest

from hashlab import core

SIZE = 100 * 1024 * 1024
SRC = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src"))


@pytest.fixture(scope="module")
def big_file(tmp_path_factory):
    p = tmp_path_factory.mktemp("big") / "100MB.bin"
    block = os.urandom(1024 * 1024)
    with open(p, "wb") as fh:
        for _ in range(100):
            fh.write(block)
    return str(p)


def test_100mb_streaming_peak_allocation(big_file):
    tracemalloc.start()
    d = core.sha256_file(big_file)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    assert d.length == SIZE
    assert peak < 8 * 1024 * 1024, f"peak Python allocation {peak} bytes"


def test_100mb_rss_growth_in_fresh_process(big_file):
    """Measure max RSS of a separate process: baseline vs hashing 100 MB."""
    code = ("import resource,sys; sys.path.insert(0, %r); from hashlab import core; "
            "b=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss; d=core.sha256_file(%r); "
            "a=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss; print(d.hex, b, a)") % (SRC, big_file)
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True).stdout.split()
    digest, before_kb, after_kb = out[0], int(out[1]), int(out[2])
    growth_mb = (after_kb - before_kb) / 1024
    assert growth_mb < 20, f"RSS grew by {growth_mb:.1f} MB"
    h = hashlib.sha256()
    with open(big_file, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    assert digest == h.hexdigest()
