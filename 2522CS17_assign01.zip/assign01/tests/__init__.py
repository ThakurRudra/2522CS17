"""Test package for hashlab."""
