"""hashlab core: byte handling, SHA-256 diagnostics, avalanche, canonical JSON.

SHA-256 itself comes from Python's standard library (hashlib, backed by OpenSSL).
This module only deals with *which bytes* get hashed and how results are reported.

Author: Rudra Pratap Singh (2522CS17) - Blockchain course, IIT Patna, Jul-Dec 2026
"""
from __future__ import annotations

import base64
import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass
from typing import Any, BinaryIO, Iterable

CHUNK_SIZE = 1024 * 1024  # 1 MiB: streaming buffer for files
DIGEST_BITS = 256

_HEX_RE = re.compile(r"\A(?:[0-9a-fA-F]{2})*\Z")


class HashlabError(ValueError):
    """Raised for any invalid user input (malformed hex, bad JSON, bad bit index...)."""


@dataclass(frozen=True)
class Digest:
    length: int          # number of input bytes
    raw: bytes           # 32-byte SHA-256 digest

    @property
    def hex(self) -> str:
        return self.raw.hex()

    @property
    def b64(self) -> str:
        return base64.b64encode(self.raw).decode("ascii")

    def as_dict(self) -> dict:
        return {"bytes": self.length, "sha256": self.hex, "base64": self.b64}


# --------------------------------------------------------------------------- inputs
def text_to_bytes(text: str, encoding: str = "utf-8") -> bytes:
    """Encode text exactly as given. No normalisation, no newline is added or removed."""
    return text.encode(encoding)


def parse_hex(hex_string: str) -> bytes:
    """Strict hex parser.

    Accepted: an even number of hex digits, optionally prefixed with 0x/0X.
    Rejected: odd length, any non-hex character, embedded whitespace, empty prefix-only '0x'
    followed by junk. An empty string is accepted and means zero bytes.
    """
    s = hex_string
    if s[:2] in ("0x", "0X"):
        s = s[2:]
    if not _HEX_RE.match(s):
        if len(s) % 2:
            raise HashlabError(f"malformed hex: odd number of digits ({len(s)})")
        bad = next((c for c in s if c not in "0123456789abcdefABCDEF"), "?")
        raise HashlabError(f"malformed hex: invalid character {bad!r}")
    return bytes.fromhex(s)


# --------------------------------------------------------------------------- hashing
def sha256_bytes(data: bytes) -> Digest:
    return Digest(len(data), hashlib.sha256(data).digest())


def sha256_stream(stream: BinaryIO, chunk_size: int = CHUNK_SIZE) -> Digest:
    """Hash a binary stream incrementally; memory use is O(chunk_size), not O(file)."""
    h = hashlib.sha256()
    total = 0
    buf = bytearray(chunk_size)
    view = memoryview(buf)
    while True:
        n = stream.readinto(buf)
        if not n:
            break
        h.update(view[:n])
        total += n
    return Digest(total, h.digest())


def sha256_file(path: str, chunk_size: int = CHUNK_SIZE) -> Digest:
    with open(path, "rb") as fh:
        return sha256_stream(fh, chunk_size)


# --------------------------------------------------------------------------- avalanche
def flip_bit(data: bytes, bit: int) -> bytes:
    """Flip one bit. Bit numbering is MSB-first: bit 0 is the most significant bit of
    byte 0, bit 7 is the least significant bit of byte 0, bit 8 is the MSB of byte 1."""
    nbits = len(data) * 8
    if not 0 <= bit < nbits:
        raise HashlabError(f"bit index {bit} out of range 0..{nbits - 1}")
    out = bytearray(data)
    out[bit // 8] ^= 0x80 >> (bit % 8)
    return bytes(out)


def hamming_distance(a: bytes, b: bytes) -> int:
    if len(a) != len(b):
        raise HashlabError("hamming distance needs equal-length inputs")
    return sum((x ^ y).bit_count() for x, y in zip(a, b))


def avalanche(data: bytes, bit: int) -> dict:
    flipped = flip_bit(data, bit)
    d1, d2 = sha256_bytes(data), sha256_bytes(flipped)
    dist = hamming_distance(d1.raw, d2.raw)
    return {
        "bit": bit,
        "byte_index": bit // 8,
        "original_input_hex": data.hex(),
        "flipped_input_hex": flipped.hex(),
        "sha256_original": d1.hex,
        "sha256_flipped": d2.hex,
        "changed_bits_in_digest": dist,
        "changed_fraction": round(dist / DIGEST_BITS, 4),
    }


def avalanche_all_bits(data: bytes) -> dict:
    """Flip every input bit once and summarise the digest Hamming distances."""
    if not data:
        raise HashlabError("avalanche needs at least one input byte")
    base = sha256_bytes(data).raw
    dists = [hamming_distance(base, sha256_bytes(flip_bit(data, i)).raw)
             for i in range(len(data) * 8)]
    mean = sum(dists) / len(dists)
    return {"input_bits": len(dists), "min": min(dists), "max": max(dists),
            "mean": round(mean, 2), "expected_mean": DIGEST_BITS / 2, "distances": dists}


# --------------------------------------------------------------------------- canonical JSON
CANONICAL_RULES = """\
hashlab canonical JSON (HCJ-1) rules
 1. Input must be one JSON object (top level '{...}').
 2. Duplicate keys at any depth are rejected (ambiguous meaning).
 3. Numbers must be integers; floats, exponents, NaN and Infinity are rejected
    (binary floating point has several textual spellings for one value).
 4. Object keys are sorted by Unicode code point, recursively. Array order is kept.
 5. No insignificant whitespace: separators are ',' and ':' exactly.
 6. Strings are written as UTF-8 (non-ASCII is NOT escaped); only the escapes JSON
    requires are produced (\\" \\\\ and control characters).
 7. Strings are NOT Unicode-normalised: NFC and NFD spellings stay different bytes.
 8. The output has no trailing newline. The hash is SHA-256 over these UTF-8 bytes.
"""


def _reject_duplicates(pairs: Iterable[tuple[str, Any]]) -> dict:
    out: dict = {}
    for k, v in pairs:
        if k in out:
            raise HashlabError(f"duplicate key {k!r} in JSON object")
        out[k] = v
    return out


def _reject_float(s: str):
    raise HashlabError(f"non-integer number {s!r} not allowed in canonical JSON")


def _reject_constant(s: str):
    raise HashlabError(f"JSON constant {s} not allowed in canonical JSON")


def parse_json_strict(text: str) -> dict:
    try:
        obj = json.loads(text, object_pairs_hook=_reject_duplicates,
                         parse_float=_reject_float, parse_constant=_reject_constant)
    except json.JSONDecodeError as exc:
        raise HashlabError(f"invalid JSON: {exc}") from None
    if not isinstance(obj, dict):
        raise HashlabError("canonical-json input must be a JSON object at top level")
    return obj


def canonical_json_bytes(obj: Any) -> bytes:
    text = json.dumps(obj, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)
    return text.encode("utf-8")


def canonical_json(text: str) -> dict:
    obj = parse_json_strict(text)
    data = canonical_json_bytes(obj)
    d = sha256_bytes(data)
    return {"canonical": data.decode("utf-8"), **d.as_dict()}


# --------------------------------------------------------------------------- look-alike demo
def lookalike_pairs() -> list[dict]:
    """Inputs that look the same to a human but are different bytes."""
    cafe_nfc = unicodedata.normalize("NFC", "café")
    cafe_nfd = unicodedata.normalize("NFD", "café")
    pairs = [
        ("trailing newline", b"Alice pays Bob 10", b"Alice pays Bob 10\n"),
        ("LF vs CRLF line ending", b"Alice pays Bob 10\n", b"Alice pays Bob 10\r\n"),
        ("Unicode NFC vs NFD ('cafe' with accent)", cafe_nfc.encode(), cafe_nfd.encode()),
        ("integer vs string in JSON", b'{"amount":10}', b'{"amount":"10"}'),
        ("JSON key order (raw bytes)", b'{"from":"alice","to":"bob"}',
         b'{"to":"bob","from":"alice"}'),
    ]
    rows = []
    for label, a, b in pairs:
        rows.append({"case": label, "a_hex": a.hex(), "b_hex": b.hex(),
                     "a_len": len(a), "b_len": len(b),
                     "a_sha256": sha256_bytes(a).hex, "b_sha256": sha256_bytes(b).hex,
                     "same_hash": sha256_bytes(a).raw == sha256_bytes(b).raw})
    # canonicalisation repairs key order (but deliberately not int-vs-string)
    ca = canonical_json_bytes(parse_json_strict('{"from":"alice","to":"bob"}'))
    cb = canonical_json_bytes(parse_json_strict('{ "to" : "bob",\n "from":"alice" }'))
    rows.append({"case": "JSON key order + whitespace AFTER canonical-json",
                 "a_hex": ca.hex(), "b_hex": cb.hex(), "a_len": len(ca), "b_len": len(cb),
                 "a_sha256": sha256_bytes(ca).hex, "b_sha256": sha256_bytes(cb).hex,
                 "same_hash": ca == cb})
    return rows
