"""hashlab command-line interface.

    hashlab text "Alice pays Bob 10"
    hashlab hex 416c696365
    hashlab file big.bin [--stats]
    hashlab avalanche --text "Alice pays Bob 10" --bit 7   (or --hex / --all)
    hashlab canonical-json tx.json        (or --json '{...}', or '-' for stdin)
    hashlab lookalikes
    hashlab rules
"""
from __future__ import annotations

import argparse
import json
import sys
import time

from . import core


def _print_digest(d: core.Digest, as_json: bool) -> None:
    if as_json:
        print(json.dumps(d.as_dict()))
    else:
        print(f"bytes: {d.length}")
        print(f"sha256: {d.hex}")
        print(f"base64: {d.b64}")


def _input_bytes(args) -> bytes:
    if getattr(args, "text", None) is not None:
        return core.text_to_bytes(args.text)
    if getattr(args, "hex", None) is not None:
        return core.parse_hex(args.hex)
    raise core.HashlabError("give --text or --hex")


def cmd_text(args) -> int:
    data = core.text_to_bytes(args.value + ("\n" if args.newline else ""))
    _print_digest(core.sha256_bytes(data), args.json)
    return 0


def cmd_hex(args) -> int:
    _print_digest(core.sha256_bytes(core.parse_hex(args.value)), args.json)
    return 0


def cmd_file(args) -> int:
    import tracemalloc
    rss_before = _max_rss_kb()
    if args.stats:
        tracemalloc.start()
    t0 = time.perf_counter()
    d = core.sha256_file(args.path, args.chunk_size)
    dt = time.perf_counter() - t0
    _print_digest(d, args.json)
    if args.stats:
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        mb = d.length / 1e6
        print(f"elapsed_s: {dt:.3f}")
        print(f"throughput_MBps: {mb / dt if dt else 0:.1f}")
        print(f"python_peak_alloc_bytes: {peak}")
        rss_after = _max_rss_kb()
        if rss_before is not None:
            print(f"max_rss_growth_kb: {rss_after - rss_before}")
    return 0


def _max_rss_kb():
    try:
        import resource
        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    except ImportError:  # Windows
        return None


def cmd_avalanche(args) -> int:
    data = _input_bytes(args)
    if args.all:
        res = core.avalanche_all_bits(data)
        if not args.json:
            res = {k: v for k, v in res.items() if k != "distances"}
        print(json.dumps(res, indent=None if args.json else 2))
        return 0
    if args.bit is None:
        raise core.HashlabError("give --bit N or --all")
    res = core.avalanche(data, args.bit)
    if args.json:
        print(json.dumps(res))
    else:
        print(f"input_bytes: {len(data)}  flipped_bit: {res['bit']} (byte {res['byte_index']}, MSB-first)")
        print(f"sha256_original: {res['sha256_original']}")
        print(f"sha256_flipped:  {res['sha256_flipped']}")
        print(f"changed_bits_in_digest: {res['changed_bits_in_digest']}")
    return 0


def cmd_canonical(args) -> int:
    if args.json_text is not None:
        text = args.json_text
    elif args.path == "-":
        text = sys.stdin.read()
    elif args.path:
        with open(args.path, encoding="utf-8") as fh:
            text = fh.read()
    else:
        raise core.HashlabError("give a file path, '-' or --json")
    res = core.canonical_json(text)
    if args.json:
        print(json.dumps(res, ensure_ascii=False))
    else:
        print(f"canonical: {res['canonical']}")
        print(f"bytes: {res['bytes']}")
        print(f"sha256: {res['sha256']}")
        print(f"base64: {res['base64']}")
    return 0


def cmd_lookalikes(args) -> int:
    rows = core.lookalike_pairs()
    if args.json:
        print(json.dumps(rows, indent=2))
        return 0
    for r in rows:
        print(f"== {r['case']}")
        print(f"   A ({r['a_len']:>2} B) {r['a_hex']}")
        print(f"   B ({r['b_len']:>2} B) {r['b_hex']}")
        print(f"   sha256 A {r['a_sha256'][:24]}...  B {r['b_sha256'][:24]}...  same={r['same_hash']}")
    return 0


def cmd_rules(args) -> int:
    print(core.CANONICAL_RULES)
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="hashlab", description="SHA-256 diagnostics for blockchain bytes")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("text", help="hash UTF-8 text exactly as given")
    s.add_argument("value")
    s.add_argument("--newline", action="store_true", help="append one LF (to show the difference)")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_text)

    s = sub.add_parser("hex", help="hash a strict hexadecimal byte string")
    s.add_argument("value")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_hex)

    s = sub.add_parser("file", help="hash a file as a stream (1 MiB chunks)")
    s.add_argument("path")
    s.add_argument("--chunk-size", type=int, default=core.CHUNK_SIZE)
    s.add_argument("--stats", action="store_true", help="print time and memory statistics")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_file)

    s = sub.add_parser("avalanche", help="flip one input bit, report digest Hamming distance")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--text")
    g.add_argument("--hex")
    s.add_argument("--bit", type=int)
    s.add_argument("--all", action="store_true", help="flip every bit and summarise")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_avalanche)

    s = sub.add_parser("canonical-json", help="canonicalise a JSON object and hash it")
    s.add_argument("path", nargs="?", help="JSON file, or '-' for stdin")
    s.add_argument("--json-text", "--json-string", dest="json_text", help="JSON given inline")
    s.add_argument("--json", action="store_true", help="machine-readable output")
    s.set_defaults(func=cmd_canonical)

    s = sub.add_parser("lookalikes", help="visually similar inputs with different bytes")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_lookalikes)

    s = sub.add_parser("rules", help="print the canonical JSON rules")
    s.set_defaults(func=cmd_rules)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except (core.HashlabError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
