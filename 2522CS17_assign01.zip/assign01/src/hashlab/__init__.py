"""hashlab - bytes, hashes and reproducible data (Assignment 1)."""
__version__ = "1.0.0"
