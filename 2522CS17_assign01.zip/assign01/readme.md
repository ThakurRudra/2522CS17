# Assignment 1 — Bytes, Hashes, and Reproducible Data (`hashlab`)

**Student:** Rudra Pratap Singh · **Roll:** 2522CS17 · **Course:** Blockchain (Dr. Mayank Agarwal), IIT Patna, Jul–Dec 2026

`hashlab` is a command-line tool that takes text, a hexadecimal byte string or a file and prints
SHA-256 diagnostics. SHA-256 itself comes from Python's standard library (`hashlib`); the tool's
job is to make sure the *right bytes* are hashed and that results are reproducible.

## How to run

```bash
cd assign01
pip install -e .            # installs the `hashlab` command (Python 3.10+, no runtime deps)
pip install -r requirements.txt
pytest -v                   # 50 tests, including the 100 MB streaming check
```
Without installing: `PYTHONPATH=src python -m hashlab ...`.
On Google Colab, open `notebook/Assignment01_hashlab_Colab.ipynb` and run all cells.

## Commands

| Command | What it does |
|---|---|
| `hashlab text "Alice pays Bob 10"` | UTF-8 bytes of the text exactly as typed → byte length, SHA-256 hex, SHA-256 Base64 |
| `hashlab text "..." --newline` | same text plus one LF (shows why `echo` output hashes differently) |
| `hashlab hex 0xdeadbeef` | strict hex parsing (even length, hex digits only, optional `0x`) |
| `hashlab file big.bin --stats` | streams the file in 1 MiB chunks; `--stats` prints time and peak memory |
| `hashlab avalanche --text "Alice pays Bob 10" --bit 7` | flips one input bit, prints `changed_bits_in_digest` |
| `hashlab avalanche --text "..." --all` | flips every input bit once; prints min / max / mean distance |
| `hashlab canonical-json tx.json` | canonicalises a JSON object (rules below) and hashes the UTF-8 bytes |
| `hashlab lookalikes` | newline, CRLF, Unicode NFC/NFD, int-vs-string and key-order cases |
| `hashlab rules` | prints the canonical JSON rules |

Every command accepts `--json` for machine-readable output. Errors go to stderr with exit code 2.

## Design decisions

* **Bit numbering (avalanche):** MSB-first. Bit 0 is the most significant bit of byte 0, bit 7 the
  least significant bit of byte 0, bit 8 the MSB of byte 1.
* **Hex:** malformed input (odd length, non-hex characters, whitespace, full-width digits) is
  rejected, never "fixed".
* **Streaming:** `sha256_stream` reuses one 1 MiB buffer with `readinto`, so memory is O(chunk).
  The 100 MB test checks both Python peak allocation (< 8 MB) and process RSS growth (< 20 MB).

### Canonical JSON rules (HCJ-1)
1. Input is exactly one JSON object.
2. Duplicate keys at any depth are rejected.
3. Only integers; floats, exponents, `NaN`, `Infinity` are rejected.
4. Keys sorted by Unicode code point, recursively; array order preserved.
5. Separators are exactly `,` and `:` (no whitespace).
6. UTF-8 output, non-ASCII not escaped; only mandatory JSON escapes.
7. No Unicode normalisation (NFC and NFD remain different bytes, on purpose).
8. No trailing newline. Hash = SHA-256 over the UTF-8 bytes.

## Layout
```
assign01/
├── readme.md            this file
├── pyproject.toml       package + `hashlab` entry point
├── requirements.txt     test dependency (pytest)
├── src/hashlab/         source: core.py (logic), cli.py (argparse), __main__.py
├── tests/               test_hashlab.py, test_stream_100mb.py
├── docs/                generated outputs (demo_output.txt)
└── notebook/            Colab notebook
```
Video demo: *(add the unlisted YouTube link here)*
