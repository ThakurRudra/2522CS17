"""Regenerate test_vectors/*.json from the specification (run from assign02/)."""
import json
import sys

sys.path.insert(0, "src")
from merkletool.merkle import MerkleTree, merkle_root, leaf_hash  # noqa: E402

vectors = []
for n in [0, 1, 2, 3, 4, 5, 7, 8]:
    leaves = [f"leaf-{i}".encode() for i in range(n)]
    vectors.append({"tree_size": n, "leaves_utf8": [l.decode() for l in leaves],
                    "leaf_hashes": [leaf_hash(l).hex() for l in leaves],
                    "root": merkle_root(leaves).hex()})
with open("test_vectors/test_vectors.json", "w") as fh:
    json.dump({"spec": "MT-1: Hleaf=SHA256(0x00||d), Hnode=SHA256(0x01||l||r), odd node promoted, empty=SHA256('')",
               "vectors": vectors}, fh, indent=2)

tx = open("test_vectors/tx_5.txt", "rb").read().split(b"\n")[:-1]
tree = MerkleTree(tx)
out = {"tree_size": 5, "root": tree.root.hex(), "proofs": [tree.prove(i).to_dict() for i in range(5)]}
with open("test_vectors/tx_5_proofs.json", "w") as fh:
    json.dump(out, fh, indent=2)
with open("test_vectors/tx_5_index2_proof.json", "w") as fh:
    fh.write(tree.prove(2).to_json() + "\n")
print("root(tx_5) =", tree.root.hex())
