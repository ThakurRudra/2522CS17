"""Generate docs/performance_report.md, docs/proof_diagram.md and the benchmark plot.

Run from assign02/:  python scripts/make_reports.py [--sizes 8 1024 100000 1000000]
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from merkletool.benchmark import run, to_markdown  # noqa: E402
from merkletool.diagram import draw_png, proof_path_markdown  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--sizes", type=int, nargs="+", default=[8, 1024, 100_000, 1_000_000])
args = ap.parse_args()
os.makedirs("docs", exist_ok=True)

rep = run(tuple(args.sizes), repeats=3)
with open("docs/benchmark.json", "w") as fh:
    json.dump(rep, fh, indent=2)

big = rep["results"][-1]
report = f"""# Performance report — Merkle tree (MT-1)

Student: Rudra Pratap Singh (2522CS17)
Machine: {rep['machine']}
Method: leaves are short synthetic transactions (`tx-00000001|alice->bob|..`, ~25 bytes).
Build time is the median of 3 full constructions (all levels stored). Proof size and
prove/verify time are measured over ~200 evenly spaced leaf indexes, including the last
(promoted) leaf.

{to_markdown(rep)}

## Observations
* Construction is O(n): about {big['leaves_per_s']:,} leaves per second, i.e. dominated by the
  ~2n SHA-256 calls (n leaf hashes + n−1 node hashes).
* Proof size is O(log n): ⌈log2 n⌉ siblings at most — {big['proof_siblings_max']} hashes
  ({big['proof_raw_bytes_max']} raw bytes) for {big['leaves']:,} leaves, against
  {big['leaves'] * 32 / 1e6:.1f} MB of leaf hashes. JSON (hex + keys) is ~3× the raw size.
* Verification needs only leaf + proof + root and costs one leaf hash plus one node hash
  per sibling (microseconds), independent of how the tree was built.
* With the "promote the odd node" rule, a leaf that is promoted at some levels gets a
  shorter proof (`proof_siblings_min` < max), and no duplicated leaf can create two trees
  with the same root.

![benchmark](benchmark.png)
"""
with open("docs/performance_report.md", "w") as fh:
    fh.write(report)

tx = open("test_vectors/tx_5.txt", "rb").read().split(b"\n")[:-1]
with open("docs/proof_diagram.md", "w") as fh:
    fh.write(proof_path_markdown(tx, 2) + "\n")

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    ns = [r["leaves"] for r in rep["results"]]
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].loglog(ns, [r["build_ms_median"] for r in rep["results"]], "o-")
    ax[0].set_xlabel("leaves"); ax[0].set_ylabel("build time (ms)"); ax[0].set_title("Construction time (O(n))")
    ax[1].semilogx(ns, [r["proof_siblings_max"] for r in rep["results"]], "s-", color="darkorange")
    ax[1].set_xlabel("leaves"); ax[1].set_ylabel("max siblings in proof"); ax[1].set_title("Proof size (O(log n))")
    for a in ax:
        a.grid(alpha=.3)
    fig.tight_layout()
    fig.savefig("docs/benchmark.png", dpi=120)
    draw_png(tx, 2, "docs/proof_diagram.png")
except ImportError:
    print("matplotlib not installed: skipped plots")
print(to_markdown(rep))
print("wrote docs/performance_report.md, docs/proof_diagram.md, docs/benchmark.json")
