"""Tests for merkletool."""
