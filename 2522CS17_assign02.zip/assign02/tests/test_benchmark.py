"""Benchmark sanity (small sizes so the suite stays fast; the notebook runs 100,000+)."""
from merkletool.benchmark import bench_size, run, to_markdown


def test_bench_small_sizes():
    rep = run(sizes=(8, 1024), repeats=1)
    r8, r1k = rep["results"]
    assert r8["proof_siblings_max"] == 3
    assert r1k["proof_siblings_max"] == 10
    assert r1k["proof_raw_bytes_max"] == 320
    assert "| 1,024 |" in to_markdown(rep)


def test_bench_odd_size_proof_bounds():
    r = bench_size(1000, repeats=1, proof_samples=50)
    assert r["proof_siblings_max"] == 10 and r["proof_siblings_min"] >= 1
