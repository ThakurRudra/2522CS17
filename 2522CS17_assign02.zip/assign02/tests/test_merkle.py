"""Tests for the Merkle library and CLI (Assignment 2)."""
import copy
import hashlib
import json
import os
import subprocess
import sys

import pytest

from merkletool.merkle import (EMPTY_ROOT, MerkleError, MerkleTree, Proof, expected_path,
                               leaf_hash, merkle_root, node_hash, parse_root, verify)

HERE = os.path.dirname(__file__)
ROOT_DIR = os.path.abspath(os.path.join(HERE, ".."))
VEC = os.path.join(ROOT_DIR, "test_vectors")


def H(b):
    return hashlib.sha256(b).digest()


def leaves(n):
    return [f"leaf-{i}".encode() for i in range(n)]


# ------------------------------------------------------------- hashing rules
def test_domain_separation():
    assert leaf_hash(b"x") == H(b"\x00x")
    assert node_hash(b"a" * 32, b"b" * 32) == H(b"\x01" + b"a" * 32 + b"b" * 32)
    assert leaf_hash(b"a" * 32 + b"b" * 32) != node_hash(b"a" * 32, b"b" * 32)


def test_zero_leaves():
    assert merkle_root([]) == EMPTY_ROOT == H(b"")
    assert MerkleTree([]).root == EMPTY_ROOT


def test_one_leaf():
    assert merkle_root([b"only"]) == leaf_hash(b"only")


def test_two_leaves_even():
    assert merkle_root([b"a", b"b"]) == node_hash(leaf_hash(b"a"), leaf_hash(b"b"))


def test_three_leaves_odd_promotes_last():
    a, b, c = (leaf_hash(x) for x in (b"a", b"b", b"c"))
    assert merkle_root([b"a", b"b", b"c"]) == node_hash(node_hash(a, b), c)


def test_odd_is_not_duplicate_ambiguity():
    # Bitcoin-style duplication would make [a,b,c] and [a,b,c,c] share a root; MT-1 must not.
    assert merkle_root([b"a", b"b", b"c"]) != merkle_root([b"a", b"b", b"c", b"c"])


def test_five_leaves_manual():
    l = [leaf_hash(f"t{i}".encode()) for i in range(5)]
    expected = node_hash(node_hash(node_hash(l[0], l[1]), node_hash(l[2], l[3])), l[4])
    assert merkle_root([f"t{i}".encode() for i in range(5)]) == expected


@pytest.mark.parametrize("n", [1, 2, 3, 4, 5, 6, 7, 8, 9, 16, 17, 33, 100])
def test_tree_and_streaming_root_agree(n):
    assert MerkleTree(leaves(n)).root == merkle_root(leaves(n))


def test_order_matters():
    assert merkle_root([b"a", b"b"]) != merkle_root([b"b", b"a"])


def test_published_test_vectors():
    with open(os.path.join(VEC, "test_vectors.json")) as fh:
        data = json.load(fh)
    for v in data["vectors"]:
        lv = [s.encode() for s in v["leaves_utf8"]]
        assert merkle_root(lv).hex() == v["root"]


# ------------------------------------------------------------- proofs: round trip
@pytest.mark.parametrize("n", [1, 2, 3, 5, 8, 13, 64, 100])
def test_every_leaf_proves_and_verifies(n):
    t = MerkleTree(leaves(n))
    for i in range(n):
        p = Proof.from_json(t.prove(i).to_json())
        assert verify(leaves(n)[i], p, t.root)
        assert [s for s, _ in p.siblings] == expected_path(i, n)


def test_proof_format_matches_spec():
    p = MerkleTree(leaves(5)).prove(2).to_dict()
    assert set(p) == {"leaf_index", "tree_size", "siblings"}
    assert p["leaf_index"] == 2 and p["tree_size"] == 5
    assert all(set(s) == {"side", "hash"} for s in p["siblings"])


def test_single_leaf_proof_is_empty():
    t = MerkleTree([b"x"])
    p = t.prove(0)
    assert p.siblings == [] and verify(b"x", p, t.root)


def test_proof_length_logarithmic():
    t = MerkleTree(leaves(1024))
    assert all(len(t.prove(i).siblings) == 10 for i in (0, 511, 1023))


def test_five_tx_vector_file():
    with open(os.path.join(VEC, "tx_5_proofs.json")) as fh:
        d = json.load(fh)
    tx = open(os.path.join(VEC, "tx_5.txt"), "rb").read().split(b"\n")[:-1]
    for i, pd in enumerate(d["proofs"]):
        assert verify(tx[i], Proof.from_dict(pd), bytes.fromhex(d["root"]))


# ------------------------------------------------------------- rejection cases
@pytest.fixture
def five():
    t = MerkleTree(leaves(5))
    return t, t.prove(2).to_dict()


def test_wrong_leaf_returns_false(five):
    t, p = five
    assert verify(b"not-in-tree", Proof.from_dict(p), t.root) is False


def test_wrong_root_returns_false(five):
    t, p = five
    assert verify(leaves(5)[2], Proof.from_dict(p), H(b"other")) is False


def test_tampered_sibling_hash_fails(five):
    t, p = five
    p["siblings"][0]["hash"] = "00" * 32
    assert verify(leaves(5)[2], Proof.from_dict(p), t.root) is False


@pytest.mark.parametrize("bad_hash", ["abc", "zz" * 32, "AB" * 32, "00" * 31, 123, None, "00" * 33])
def test_malformed_hash_rejected(five, bad_hash):
    _, p = five
    p["siblings"][0]["hash"] = bad_hash
    with pytest.raises(MerkleError, match="malformed hash"):
        Proof.from_dict(p)


@pytest.mark.parametrize("side", ["up", "LEFT", "", None, 0])
def test_invalid_direction_value_rejected(five, side):
    _, p = five
    p["siblings"][1]["side"] = side
    with pytest.raises(MerkleError, match="invalid direction"):
        Proof.from_dict(p)


def test_swapped_direction_rejected(five):
    t, p = five
    p["siblings"][0]["side"] = "left"
    with pytest.raises(MerkleError, match="invalid direction at level 0"):
        verify(leaves(5)[2], Proof.from_dict(p), t.root)


def test_wrong_index_rejected(five):
    t, p = five
    p["leaf_index"] = 3  # proof belongs to index 2
    with pytest.raises(MerkleError, match="invalid direction"):
        verify(leaves(5)[2], Proof.from_dict(p), t.root)


@pytest.mark.parametrize("idx,size", [(5, 5), (-1, 5), (0, 0)])
def test_index_out_of_range_rejected(five, idx, size):
    _, p = five
    p["leaf_index"], p["tree_size"] = idx, size
    with pytest.raises(MerkleError):
        Proof.from_dict(p)


def test_unnecessarily_long_proof_rejected(five):
    t, p = five
    p["siblings"].append({"side": "right", "hash": "11" * 32})
    with pytest.raises(MerkleError, match="too long"):
        verify(leaves(5)[2], Proof.from_dict(p), t.root)


def test_short_proof_rejected(five):
    t, p = five
    p["siblings"].pop()
    with pytest.raises(MerkleError, match="too short"):
        verify(leaves(5)[2], Proof.from_dict(p), t.root)


def test_promoted_leaf_cannot_carry_extra_level():
    t = MerkleTree(leaves(5))
    p = t.prove(4).to_dict()  # leaf 4 is promoted twice: only 1 sibling
    assert len(p["siblings"]) == 1
    p["siblings"].insert(0, {"side": "left", "hash": t.levels[0][3].hex()})
    with pytest.raises(MerkleError, match="too long"):
        verify(leaves(5)[4], Proof.from_dict(p), t.root)


@pytest.mark.parametrize("mutate", [
    lambda p: p.pop("siblings"),
    lambda p: p.update(extra=1),
    lambda p: p.update(leaf_index="2"),
    lambda p: p.update(leaf_index=True),
    lambda p: p.update(siblings={}),
    lambda p: p["siblings"][0].update(extra="x"),
])
def test_schema_violations_rejected(five, mutate):
    _, p = five
    p = copy.deepcopy(p)
    mutate(p)
    with pytest.raises(MerkleError):
        Proof.from_dict(p)


def test_non_json_rejected():
    with pytest.raises(MerkleError):
        Proof.from_json("{not json")


def test_parse_root_rejects_bad():
    with pytest.raises(MerkleError):
        parse_root("12")


def test_prove_bad_index():
    with pytest.raises(MerkleError):
        MerkleTree(leaves(3)).prove(3)


# ------------------------------------------------------------- CLI
def cli(*args):
    env = dict(os.environ, PYTHONPATH=os.path.join(ROOT_DIR, "src"))
    return subprocess.run([sys.executable, "-m", "merkletool", *args], capture_output=True,
                          text=True, env=env, cwd=ROOT_DIR)


def test_cli_root_prove_verify(tmp_path):
    tx = os.path.join(VEC, "tx_5.txt")
    root = cli("root", "--file", tx).stdout.strip()
    proof = tmp_path / "p.json"
    assert cli("prove", "--file", tx, "--index", "2", "--out", str(proof)).returncode == 0
    ok = cli("verify", "--leaf", "tx2: carol pays dave 7", "--proof", str(proof), "--root", root)
    assert ok.returncode == 0 and "VALID" in ok.stdout
    bad = cli("verify", "--leaf", "tx2: carol pays dave 700", "--proof", str(proof), "--root", root)
    assert bad.returncode == 1


def test_cli_rejects_malformed_proof(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text('{"leaf_index":0,"tree_size":1,"siblings":[{"side":"up","hash":"00"}]}')
    r = cli("verify", "--leaf", "x", "--proof", str(p), "--root", "00" * 32)
    assert r.returncode == 2 and "error" in r.stderr
