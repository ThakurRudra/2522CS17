"""Merkle tree library with domain separation and strict inclusion proofs.

Specification (MT-1)
--------------------
* Hash function H = SHA-256.
* Leaf hash:      Hleaf(d)    = H(0x00 || d)
* Internal node:  Hnode(l, r) = H(0x01 || l || r)
  The different prefixes make it impossible to pass an internal node off as a leaf
  (second-preimage attack on naive Merkle trees).
* Empty tree:     root = H("")  (SHA-256 of zero bytes, as in RFC 6962).
* One leaf:       root = Hleaf(d0).
* Odd level width: nodes are paired left to right; the LAST node of an odd-width level
  has no partner and is PROMOTED unchanged to the next level. It is never duplicated,
  so the Bitcoin CVE-2012-2459 duplicate-leaf ambiguity cannot occur.
* Proof: list of sibling hashes from the leaf level upwards. side="right" means the
  sibling is concatenated on the right (current hash is the left child); side="left" the
  opposite. Levels where the node is promoted contribute no sibling.
* Because (leaf_index, tree_size) fully determine the path shape, the verifier recomputes
  the expected sides and length and rejects any proof that differs (wrong index, invalid
  direction, too long or too short).

Author: Rudra Pratap Singh (2522CS17)
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Sequence

LEAF_PREFIX = b"\x00"
NODE_PREFIX = b"\x01"
HASH_LEN = 32
_HASH_RE = re.compile(r"\A[0-9a-f]{64}\Z")
PROOF_KEYS = {"leaf_index", "tree_size", "siblings"}


class MerkleError(ValueError):
    """Malformed proof, bad index, or invalid input."""


def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def leaf_hash(data: bytes) -> bytes:
    return sha256(LEAF_PREFIX + data)


def node_hash(left: bytes, right: bytes) -> bytes:
    return sha256(NODE_PREFIX + left + right)


EMPTY_ROOT = sha256(b"")


# ------------------------------------------------------------------ tree
class MerkleTree:
    """Stores every level so that proofs are O(log n) lookups."""

    def __init__(self, leaves: Sequence[bytes]):
        self.size = len(leaves)
        level = [leaf_hash(d) for d in leaves]
        self.levels: list[list[bytes]] = [level]
        while len(level) > 1:
            nxt = [node_hash(level[i], level[i + 1]) for i in range(0, len(level) - 1, 2)]
            if len(level) % 2:
                nxt.append(level[-1])  # promote the unpaired last node
            self.levels.append(nxt)
            level = nxt

    @property
    def root(self) -> bytes:
        return EMPTY_ROOT if self.size == 0 else self.levels[-1][0]

    def prove(self, index: int) -> "Proof":
        if not isinstance(index, int) or isinstance(index, bool) or not 0 <= index < self.size:
            raise MerkleError(f"leaf index {index} out of range for tree of size {self.size}")
        siblings = []
        idx = index
        for level in self.levels[:-1]:
            if idx % 2 == 1:
                siblings.append(("left", level[idx - 1]))
            elif idx + 1 < len(level):
                siblings.append(("right", level[idx + 1]))
            # else: promoted, no sibling at this level
            idx //= 2
        return Proof(index, self.size, siblings)


def merkle_root(leaves: Sequence[bytes]) -> bytes:
    """Root without storing levels (O(n) time, O(n) memory for one level)."""
    if not leaves:
        return EMPTY_ROOT
    level = [leaf_hash(d) for d in leaves]
    while len(level) > 1:
        nxt = [node_hash(level[i], level[i + 1]) for i in range(0, len(level) - 1, 2)]
        if len(level) % 2:
            nxt.append(level[-1])
        level = nxt
    return level[0]


def expected_path(index: int, size: int) -> list[str]:
    """Sides of the siblings a correct proof must contain, derived from (index, size)."""
    sides = []
    idx, width = index, size
    while width > 1:
        if idx % 2 == 1:
            sides.append("left")
        elif idx + 1 < width:
            sides.append("right")
        idx //= 2
        width = (width + 1) // 2
    return sides


# ------------------------------------------------------------------ proofs
@dataclass(frozen=True)
class Proof:
    leaf_index: int
    tree_size: int
    siblings: list  # list[tuple[str, bytes]]

    def to_dict(self) -> dict:
        return {"leaf_index": self.leaf_index, "tree_size": self.tree_size,
                "siblings": [{"side": s, "hash": h.hex()} for s, h in self.siblings]}

    def to_json(self, indent: int | None = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @staticmethod
    def from_dict(obj) -> "Proof":
        if not isinstance(obj, dict):
            raise MerkleError("proof must be a JSON object")
        keys = set(obj)
        if keys != PROOF_KEYS:
            missing, extra = PROOF_KEYS - keys, keys - PROOF_KEYS
            raise MerkleError(f"proof keys wrong (missing={sorted(missing)}, unexpected={sorted(extra)})")
        idx, size, sibs = obj["leaf_index"], obj["tree_size"], obj["siblings"]
        for name, v in (("leaf_index", idx), ("tree_size", size)):
            if not isinstance(v, int) or isinstance(v, bool):
                raise MerkleError(f"{name} must be an integer")
        if size < 1:
            raise MerkleError("tree_size must be >= 1")
        if not 0 <= idx < size:
            raise MerkleError(f"leaf_index {idx} out of range for tree_size {size}")
        if not isinstance(sibs, list):
            raise MerkleError("siblings must be a list")
        parsed = []
        for i, s in enumerate(sibs):
            if not isinstance(s, dict) or set(s) != {"side", "hash"}:
                raise MerkleError(f"sibling {i} must have exactly 'side' and 'hash'")
            if s["side"] not in ("left", "right"):
                raise MerkleError(f"sibling {i}: invalid direction {s['side']!r}")
            if not isinstance(s["hash"], str) or not _HASH_RE.match(s["hash"]):
                raise MerkleError(f"sibling {i}: malformed hash (need 64 lowercase hex chars)")
            parsed.append((s["side"], bytes.fromhex(s["hash"])))
        return Proof(idx, size, parsed)

    @staticmethod
    def from_json(text: str) -> "Proof":
        try:
            return Proof.from_dict(json.loads(text))
        except json.JSONDecodeError as exc:
            raise MerkleError(f"proof is not valid JSON: {exc}") from None


def verify(leaf_data: bytes, proof: Proof, expected_root: bytes) -> bool:
    """Verify using only the leaf, the proof and the expected root.

    Raises MerkleError with a precise reason for structurally wrong proofs; returns
    False if the structure is right but the hashes do not lead to expected_root."""
    if len(expected_root) != HASH_LEN:
        raise MerkleError("expected root must be 32 bytes")
    want = expected_path(proof.leaf_index, proof.tree_size)
    got = [s for s, _ in proof.siblings]
    if len(got) > len(want):
        raise MerkleError(f"proof too long: {len(got)} siblings, expected {len(want)} "
                          f"for index {proof.leaf_index} in tree of {proof.tree_size}")
    if len(got) < len(want):
        raise MerkleError(f"proof too short: {len(got)} siblings, expected {len(want)}")
    for level, (g, w) in enumerate(zip(got, want)):
        if g != w:
            raise MerkleError(f"invalid direction at level {level}: got {g}, expected {w} "
                              f"(wrong leaf_index or tampered proof)")
    h = leaf_hash(leaf_data)
    for side, sib in proof.siblings:
        h = node_hash(sib, h) if side == "left" else node_hash(h, sib)
    return h == expected_root


def parse_root(hex_root: str) -> bytes:
    if not isinstance(hex_root, str) or not _HASH_RE.match(hex_root.lower()):
        raise MerkleError("root must be 64 hex characters")
    return bytes.fromhex(hex_root)
