"""merkletool - Merkle trees and proofs of inclusion (Assignment 2)."""
from .merkle import MerkleTree, Proof, merkle_root, verify, leaf_hash, node_hash, MerkleError

__all__ = ["MerkleTree", "Proof", "merkle_root", "verify", "leaf_hash", "node_hash", "MerkleError"]
__version__ = "1.0.0"
