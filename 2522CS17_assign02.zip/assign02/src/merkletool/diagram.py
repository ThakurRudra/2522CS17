"""Render the exact proof path for a small tree (used for the 5-transaction diagram)."""
from __future__ import annotations

from .merkle import MerkleTree


def short(h: bytes, n: int = 8) -> str:
    return h.hex()[:n]


def proof_path_markdown(leaves: list[bytes], index: int) -> str:
    tree = MerkleTree(leaves)
    proof = tree.prove(index)
    # walk the path to know which node ids are on it / are siblings
    on_path, sib_nodes = set(), set()
    idx = index
    for lvl, level in enumerate(tree.levels):
        on_path.add((lvl, idx))
        if lvl < len(tree.levels) - 1:
            if idx % 2 == 1:
                sib_nodes.add((lvl, idx - 1))
            elif idx + 1 < len(level):
                sib_nodes.add((lvl, idx + 1))
        idx //= 2

    lines = ["```mermaid", "graph BT"]
    for lvl, level in enumerate(tree.levels):
        for i, h in enumerate(level):
            nid = f"L{lvl}_{i}"
            if lvl == 0:
                label = f"Hleaf(tx{i}) {short(h)}"
            elif lvl == len(tree.levels) - 1:
                label = f"ROOT {short(h)}"
            else:
                label = f"N{lvl}.{i} {short(h)}"
            lines.append(f'    {nid}["{label}"]')
    for lvl in range(len(tree.levels) - 1):
        width = len(tree.levels[lvl])
        for i in range(width):
            lines.append(f"    L{lvl}_{i} --> L{lvl + 1}_{i // 2}")
    for lvl, i in sorted(on_path):
        lines.append(f"    style L{lvl}_{i} fill:#ffd966,stroke:#b8860b,stroke-width:2px")
    for lvl, i in sorted(sib_nodes):
        lines.append(f"    style L{lvl}_{i} fill:#9fc5e8,stroke:#1c4587,stroke-width:2px")
    lines.append("```")

    data_lines = [f"| {i} | `{d.decode('utf-8', 'replace')}` | `{short(h, 16)}…` |"
                  for i, (d, h) in enumerate(zip(leaves, tree.levels[0]))]
    steps = []
    from .merkle import leaf_hash, node_hash
    h = leaf_hash(leaves[index])
    steps.append(f"0. start: `Hleaf(tx{index}) = H(0x00 || tx{index}) = {short(h, 16)}…`")
    for k, (side, sib) in enumerate(proof.siblings, 1):
        new = node_hash(sib, h) if side == "left" else node_hash(h, sib)
        expr = (f"H(0x01 || {short(sib)} || {short(h)})" if side == "left"
                else f"H(0x01 || {short(h)} || {short(sib)})")
        steps.append(f"{k}. sibling on the **{side}** `{short(sib, 16)}…` → `{expr} = {short(new, 16)}…`")
        h = new
    steps.append(f"{len(proof.siblings) + 1}. result `{h.hex()}` == root → **valid**")

    ascii_tree = ascii_render(tree, on_path, sib_nodes)
    return "\n".join([
        f"# Proof path for transaction {index} in a 5-transaction Merkle tree",
        "",
        "Rules: `Hleaf = SHA256(0x00 || tx)`, `Hnode = SHA256(0x01 || left || right)`; the unpaired",
        "last node of an odd level is promoted unchanged (never duplicated).",
        "Yellow = nodes recomputed by the verifier (the path); blue = sibling hashes carried in the proof.",
        "",
        "| index | transaction | leaf hash |", "|---|---|---|", *data_lines, "",
        *lines, "",
        "ASCII view (`*` path node, `[S]` sibling supplied by the proof, `^` promoted):",
        "```", ascii_tree, "```", "",
        "## Proof JSON", "```json", proof.to_json(), "```", "",
        "## Verification steps", *steps, "",
        f"Root: `{tree.root.hex()}`", "",
        "![proof path](proof_diagram.png)",
    ])


def ascii_render(tree: MerkleTree, on_path: set, sib_nodes: set) -> str:
    out = []
    for lvl in range(len(tree.levels) - 1, -1, -1):
        level = tree.levels[lvl]
        cells = []
        for i, h in enumerate(level):
            tag = "*" if (lvl, i) in on_path else ("[S]" if (lvl, i) in sib_nodes else "")
            promoted = (lvl > 0 and len(tree.levels[lvl - 1]) % 2 == 1 and i == len(level) - 1)
            name = "ROOT" if lvl == len(tree.levels) - 1 else (f"tx{i}" if lvl == 0 else f"N{lvl}.{i}")
            cells.append(f"{tag}{name}:{short(h, 6)}{'^' if promoted else ''}")
        out.append(f"level {lvl}: " + "   ".join(cells))
    return "\n".join(out)


def draw_png(leaves: list[bytes], index: int, path: str) -> None:
    """Draw the tree with the proof path highlighted (needs matplotlib)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    tree = MerkleTree(leaves)
    proof_nodes, sib_nodes = set(), set()
    idx = index
    for lvl, level in enumerate(tree.levels):
        proof_nodes.add((lvl, idx))
        if lvl < len(tree.levels) - 1:
            if idx % 2:
                sib_nodes.add((lvl, idx - 1))
            elif idx + 1 < len(level):
                sib_nodes.add((lvl, idx + 1))
        idx //= 2
    pos = {(0, i): (i * 2.2, 0) for i in range(len(leaves))}
    for lvl in range(1, len(tree.levels)):
        for i in range(len(tree.levels[lvl])):
            kids = [k for k in (2 * i, 2 * i + 1) if (lvl - 1, k) in pos]
            pos[(lvl, i)] = (sum(pos[(lvl - 1, k)][0] for k in kids) / len(kids), lvl * 1.6)
    fig, ax = plt.subplots(figsize=(11, 5.5))
    for lvl in range(1, len(tree.levels)):
        for i in range(len(tree.levels[lvl])):
            for k in (2 * i, 2 * i + 1):
                if (lvl - 1, k) in pos:
                    (x0, y0), (x1, y1) = pos[(lvl - 1, k)], pos[(lvl, i)]
                    on = (lvl - 1, k) in proof_nodes and (lvl, i) in proof_nodes
                    ax.plot([x0, x1], [y0, y1], color="#b8860b" if on else "#999", lw=2.5 if on else 1, zorder=1)
    for (lvl, i), (x, y) in pos.items():
        h = tree.levels[lvl][i]
        if (lvl, i) in proof_nodes:
            fc, ec = "#ffd966", "#b8860b"
        elif (lvl, i) in sib_nodes:
            fc, ec = "#9fc5e8", "#1c4587"
        else:
            fc, ec = "#f3f3f3", "#888"
        name = ("ROOT" if lvl == len(tree.levels) - 1 else (f"tx{i}" if lvl == 0 else f"N{lvl}.{i}"))
        promoted = lvl > 0 and len(tree.levels[lvl - 1]) % 2 == 1 and i == len(tree.levels[lvl]) - 1
        label = f"{name}{' (promoted)' if promoted else ''}\n{h.hex()[:10]}"
        ax.text(x, y, label, ha="center", va="center", fontsize=8.5, family="monospace", zorder=2,
                bbox=dict(boxstyle="round,pad=0.4", fc=fc, ec=ec, lw=1.5))
    ax.set_title(f"Merkle proof path for tx{index} (yellow = recomputed path, blue = siblings in proof)")
    ax.axis("off")
    ax.set_xlim(-1.4, (len(leaves) - 1) * 2.2 + 1.4)
    ax.set_ylim(-0.8, (len(tree.levels) - 1) * 1.6 + 0.8)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
