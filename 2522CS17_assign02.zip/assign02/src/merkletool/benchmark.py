"""Performance measurement: construction time and proof size for several tree sizes."""
from __future__ import annotations

import json
import platform
import statistics
import time

from .merkle import MerkleTree, verify


def make_leaves(n: int) -> list[bytes]:
    return [f"tx-{i:08d}|alice->bob|{i % 997}".encode() for i in range(n)]


def bench_size(n: int, repeats: int = 3, proof_samples: int = 200) -> dict:
    leaves = make_leaves(n)
    build_times = []
    tree = None
    for _ in range(repeats):
        t0 = time.perf_counter()
        tree = MerkleTree(leaves)
        build_times.append(time.perf_counter() - t0)
    step = max(1, n // proof_samples)
    indexes = list(range(0, n, step))[:proof_samples] + [n - 1]
    sib_counts, json_sizes, prove_t, verify_t = [], [], [], []
    for i in indexes:
        t0 = time.perf_counter()
        p = tree.prove(i)
        prove_t.append(time.perf_counter() - t0)
        sib_counts.append(len(p.siblings))
        json_sizes.append(len(p.to_json(indent=None).encode()))
        t0 = time.perf_counter()
        ok = verify(leaves[i], p, tree.root)
        verify_t.append(time.perf_counter() - t0)
        assert ok
    build = statistics.median(build_times)
    return {
        "leaves": n,
        "build_ms_median": round(build * 1e3, 3),
        "leaves_per_s": round(n / build) if build else None,
        "proof_siblings_max": max(sib_counts),
        "proof_siblings_min": min(sib_counts),
        "proof_raw_bytes_max": 32 * max(sib_counts),
        "proof_json_bytes_max": max(json_sizes),
        "prove_us_median": round(statistics.median(prove_t) * 1e6, 2),
        "verify_us_median": round(statistics.median(verify_t) * 1e6, 2),
        "root": tree.root.hex(),
    }


def run(sizes=(8, 1024, 100_000), repeats: int = 3) -> dict:
    return {
        "machine": f"{platform.system()} {platform.machine()}, Python {platform.python_version()}",
        "results": [bench_size(n, repeats) for n in sizes],
    }


def to_markdown(report: dict) -> str:
    rows = ["| leaves | build time (ms, median) | leaves/s | max proof siblings | max proof size (raw bytes) "
            "| max proof JSON bytes | prove (µs) | verify (µs) |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in report["results"]:
        rows.append(f"| {r['leaves']:,} | {r['build_ms_median']:,} | {r['leaves_per_s']:,} | "
                    f"{r['proof_siblings_max']} | {r['proof_raw_bytes_max']} | {r['proof_json_bytes_max']} | "
                    f"{r['prove_us_median']} | {r['verify_us_median']} |")
    return "\n".join(rows)


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
