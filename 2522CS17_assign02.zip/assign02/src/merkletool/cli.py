"""merkletool CLI: root, prove, verify (+ diagram, bench).

Leaf input (choose one):
  --file tx.txt        one leaf per line; a leaf is the UTF-8 bytes of the line without its LF
  --hex-file tx.hex    one hex-encoded leaf per line
  --leaf A --leaf B    leaves given on the command line (UTF-8)

Examples:
  merkletool root   --file test_vectors/tx_5.txt
  merkletool prove  --file test_vectors/tx_5.txt --index 2 --out proof.json
  merkletool verify --leaf "tx2: carol pays dave 7" --proof proof.json --root <hex>
"""
from __future__ import annotations

import argparse
import json
import sys

from . import merkle
from .benchmark import run as run_bench, to_markdown
from .diagram import proof_path_markdown


def read_leaves(args) -> list[bytes]:
    if args.leaf:
        return [s.encode("utf-8") for s in args.leaf]
    path = args.file or args.hex_file
    if not path:
        raise merkle.MerkleError("give --file, --hex-file or --leaf")
    with open(path, "rb") as fh:
        raw = fh.read()
    if raw == b"":
        return []
    lines = raw.split(b"\n")
    if lines[-1] == b"":
        lines.pop()  # file ends with LF
    if args.hex_file:
        out = []
        for n, ln in enumerate(lines, 1):
            try:
                out.append(bytes.fromhex(ln.decode("ascii").strip()))
            except ValueError:
                raise merkle.MerkleError(f"line {n}: malformed hex leaf") from None
        return out
    return lines


def add_leaf_args(p):
    g = p.add_mutually_exclusive_group()
    g.add_argument("--file")
    g.add_argument("--hex-file")
    g.add_argument("--leaf", action="append")


def cmd_root(args):
    leaves = read_leaves(args)
    print(json.dumps({"tree_size": len(leaves), "root": merkle.merkle_root(leaves).hex()})
          if args.json else merkle.merkle_root(leaves).hex())
    return 0


def cmd_prove(args):
    leaves = read_leaves(args)
    tree = merkle.MerkleTree(leaves)
    text = tree.prove(args.index).to_json()
    if args.out:
        with open(args.out, "w") as fh:
            fh.write(text + "\n")
        print(f"proof for leaf {args.index} written to {args.out}; root {tree.root.hex()}")
    else:
        print(text)
    return 0


def cmd_verify(args):
    if args.leaf_hex is not None:
        leaf = bytes.fromhex(args.leaf_hex)
    else:
        leaf = args.leaf_text.encode("utf-8")
    with open(args.proof) as fh:
        proof = merkle.Proof.from_json(fh.read())
    ok = merkle.verify(leaf, proof, merkle.parse_root(args.root))
    print("VALID: leaf is included under the given root" if ok else "INVALID: root mismatch")
    return 0 if ok else 1


def cmd_diagram(args):
    leaves = read_leaves(args)
    md = proof_path_markdown(leaves, args.index)
    if args.out:
        with open(args.out, "w") as fh:
            fh.write(md + "\n")
        print(f"diagram written to {args.out}")
    else:
        print(md)
    return 0


def cmd_bench(args):
    rep = run_bench(tuple(args.sizes), args.repeats)
    if args.json_out:
        with open(args.json_out, "w") as fh:
            json.dump(rep, fh, indent=2)
    print(rep["machine"])
    print(to_markdown(rep))
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="merkletool", description="Merkle trees and inclusion proofs")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("root", help="compute the Merkle root")
    add_leaf_args(s)
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_root)
    s = sub.add_parser("prove", help="inclusion proof for one leaf (JSON)")
    add_leaf_args(s)
    s.add_argument("--index", type=int, required=True)
    s.add_argument("--out")
    s.set_defaults(func=cmd_prove)
    s = sub.add_parser("verify", help="verify a proof using only leaf, proof and root")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--leaf", dest="leaf_text")
    g.add_argument("--leaf-hex")
    s.add_argument("--proof", required=True)
    s.add_argument("--root", required=True)
    s.set_defaults(func=cmd_verify)
    s = sub.add_parser("diagram", help="markdown/mermaid diagram of a proof path")
    add_leaf_args(s)
    s.add_argument("--index", type=int, required=True)
    s.add_argument("--out")
    s.set_defaults(func=cmd_diagram)
    s = sub.add_parser("bench", help="construction time and proof size")
    s.add_argument("--sizes", type=int, nargs="+", default=[8, 1024, 100_000])
    s.add_argument("--repeats", type=int, default=3)
    s.add_argument("--json-out")
    s.set_defaults(func=cmd_bench)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except (merkle.MerkleError, OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
