# Assignment 2 — Merkle Trees and Proofs of Inclusion (`merkletool`)

**Student:** Rudra Pratap Singh · **Roll:** 2522CS17 · **Course:** Blockchain (Dr. Mayank Agarwal), IIT Patna

A Merkle-tree library and CLI written from scratch (only `hashlib.sha256` is used).

## How to run
```bash
cd assign02
pip install -e .                 # installs the `merkletool` command
pip install -r requirements.txt  # pytest (+ matplotlib for plots)
pytest -v                        # 70 tests
python scripts/make_reports.py   # regenerates docs/performance_report.md, proof_diagram.md, PNGs
```
Colab: open `notebook/Assignment02_merkle_Colab.ipynb` → Run all.

## CLI
```bash
merkletool root   --file test_vectors/tx_5.txt
merkletool prove  --file test_vectors/tx_5.txt --index 2 --out proof.json
merkletool verify --leaf "tx2: carol pays dave 7" --proof proof.json --root <64-hex root>
merkletool diagram --file test_vectors/tx_5.txt --index 2      # markdown + mermaid proof path
merkletool bench  --sizes 8 1024 100000 1000000
```
A leaf file holds one leaf per line; the leaf is the raw UTF-8 bytes of the line without its LF.
`--hex-file` reads hex leaves, `--leaf X` (repeatable) gives leaves inline.
`verify` exits 0 = valid, 1 = hashes do not reach the root, 2 = malformed/structurally wrong proof.

## Specification (MT-1)
| Item | Rule |
|---|---|
| Hash | SHA-256 |
| Leaf | `Hleaf(d) = H(0x00 ‖ d)` |
| Internal node | `Hnode(l, r) = H(0x01 ‖ l ‖ r)` |
| 0 leaves | root = `H("")` = `e3b0c442…b855` |
| 1 leaf | root = `Hleaf(d0)` |
| Odd level | pair left→right; the last unpaired node is **promoted unchanged** (never duplicated) |
| Proof | siblings from leaf level upward; `side:"right"` → sibling is the right child (`H(0x01‖cur‖sib)`), `side:"left"` → `H(0x01‖sib‖cur)` |
| Strict checks | exact keys, 64 lowercase-hex hashes, side ∈ {left,right}, `0 ≤ leaf_index < tree_size`; the verifier derives the expected path from `(leaf_index, tree_size)` and rejects wrong directions, wrong index, too-long or too-short proofs |

Proof JSON (exactly the format in the assignment):
```json
{"leaf_index": 2, "tree_size": 5,
 "siblings": [{"side": "right", "hash": "a4771e93…"}, {"side": "left", "hash": "f550080f…"}, {"side": "right", "hash": "be9c4581…"}]}
```

## Deliverables
* Library: `src/merkletool/merkle.py`; CLI: `src/merkletool/cli.py`
* Test vectors: `test_vectors/test_vectors.json` (roots for 0,1,2,3,4,5,7,8 leaves), `tx_5.txt`, `tx_5_proofs.json`, `tx_5_index2_proof.json` (regenerate with `scripts/make_test_vectors.py`)
* Performance report: `docs/performance_report.md` (+ `benchmark.png`, `benchmark.json`)
* Five-transaction proof-path diagram: `docs/proof_diagram.md` (mermaid + ASCII) and `docs/proof_diagram.png`

Video demo: *(add the unlisted YouTube link here)*
