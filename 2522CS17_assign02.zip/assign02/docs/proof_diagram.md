# Proof path for transaction 2 in a 5-transaction Merkle tree

Rules: `Hleaf = SHA256(0x00 || tx)`, `Hnode = SHA256(0x01 || left || right)`; the unpaired
last node of an odd level is promoted unchanged (never duplicated).
Yellow = nodes recomputed by the verifier (the path); blue = sibling hashes carried in the proof.

| index | transaction | leaf hash |
|---|---|---|
| 0 | `tx0: alice pays bob 10` | `c173daa02c75cdcd…` |
| 1 | `tx1: bob pays carol 4` | `b112805222eb9cc1…` |
| 2 | `tx2: carol pays dave 7` | `1fef64430d0c7cf5…` |
| 3 | `tx3: dave pays erin 1` | `a4771e93108c8616…` |
| 4 | `tx4: erin pays alice 3` | `be9c4581518a0528…` |

```mermaid
graph BT
    L0_0["Hleaf(tx0) c173daa0"]
    L0_1["Hleaf(tx1) b1128052"]
    L0_2["Hleaf(tx2) 1fef6443"]
    L0_3["Hleaf(tx3) a4771e93"]
    L0_4["Hleaf(tx4) be9c4581"]
    L1_0["N1.0 f550080f"]
    L1_1["N1.1 a7947e2d"]
    L1_2["N1.2 be9c4581"]
    L2_0["N2.0 81f3297f"]
    L2_1["N2.1 be9c4581"]
    L3_0["ROOT eb5f2189"]
    L0_0 --> L1_0
    L0_1 --> L1_0
    L0_2 --> L1_1
    L0_3 --> L1_1
    L0_4 --> L1_2
    L1_0 --> L2_0
    L1_1 --> L2_0
    L1_2 --> L2_1
    L2_0 --> L3_0
    L2_1 --> L3_0
    style L0_2 fill:#ffd966,stroke:#b8860b,stroke-width:2px
    style L1_1 fill:#ffd966,stroke:#b8860b,stroke-width:2px
    style L2_0 fill:#ffd966,stroke:#b8860b,stroke-width:2px
    style L3_0 fill:#ffd966,stroke:#b8860b,stroke-width:2px
    style L0_3 fill:#9fc5e8,stroke:#1c4587,stroke-width:2px
    style L1_0 fill:#9fc5e8,stroke:#1c4587,stroke-width:2px
    style L2_1 fill:#9fc5e8,stroke:#1c4587,stroke-width:2px
```

ASCII view (`*` path node, `[S]` sibling supplied by the proof, `^` promoted):
```
level 3: *ROOT:eb5f21
level 2: *N2.0:81f329   [S]N2.1:be9c45^
level 1: [S]N1.0:f55008   *N1.1:a7947e   N1.2:be9c45^
level 0: tx0:c173da   tx1:b11280   *tx2:1fef64   [S]tx3:a4771e   tx4:be9c45
```

## Proof JSON
```json
{
  "leaf_index": 2,
  "tree_size": 5,
  "siblings": [
    {
      "side": "right",
      "hash": "a4771e93108c8616836a78955d4f9f871d298ce68c01c911724ec5b2097667f4"
    },
    {
      "side": "left",
      "hash": "f550080f47411a30d55dbdef9b9e83bade46d580baed92111c6fbb6c29c7b83b"
    },
    {
      "side": "right",
      "hash": "be9c4581518a052875356407bc05a58c05d7ff8f502d5f6f52b4c95df3642999"
    }
  ]
}
```

## Verification steps
0. start: `Hleaf(tx2) = H(0x00 || tx2) = 1fef64430d0c7cf5…`
1. sibling on the **right** `a4771e93108c8616…` → `H(0x01 || 1fef6443 || a4771e93) = a7947e2dd795f090…`
2. sibling on the **left** `f550080f47411a30…` → `H(0x01 || f550080f || a7947e2d) = 81f3297f863583f6…`
3. sibling on the **right** `be9c4581518a0528…` → `H(0x01 || 81f3297f || be9c4581) = eb5f21890e7deb94…`
4. result `eb5f21890e7deb9402e22c0cb0be8c17f9822537442acc6c118c347f6f007dd7` == root → **valid**

Root: `eb5f21890e7deb9402e22c0cb0be8c17f9822537442acc6c118c347f6f007dd7`

![proof path](proof_diagram.png)
