# Performance report — Merkle tree (MT-1)

Student: Rudra Pratap Singh (2522CS17)
Machine: Linux x86_64, Python 3.13.18
Method: leaves are short synthetic transactions (`tx-00000001|alice->bob|..`, ~25 bytes).
Build time is the median of 3 full constructions (all levels stored). Proof size and
prove/verify time are measured over ~200 evenly spaced leaf indexes, including the last
(promoted) leaf.

| leaves | build time (ms, median) | leaves/s | max proof siblings | max proof size (raw bytes) | max proof JSON bytes | prove (µs) | verify (µs) |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 8 | 0.021 | 381,752 | 3 | 96 | 332 | 2.71 | 8.34 |
| 1,024 | 2.375 | 431,167 | 10 | 320 | 1000 | 3.48 | 17.99 |
| 100,000 | 360.173 | 277,645 | 17 | 544 | 1667 | 7.24 | 29.22 |
| 1,000,000 | 2,609.14 | 383,268 | 20 | 640 | 1953 | 10.05 | 34.55 |

## Observations
* Construction is O(n): about 383,268 leaves per second, i.e. dominated by the
  ~2n SHA-256 calls (n leaf hashes + n−1 node hashes).
* Proof size is O(log n): ⌈log2 n⌉ siblings at most — 20 hashes
  (640 raw bytes) for 1,000,000 leaves, against
  32.0 MB of leaf hashes. JSON (hex + keys) is ~3× the raw size.
* Verification needs only leaf + proof + root and costs one leaf hash plus one node hash
  per sibling (microseconds), independent of how the tree was built.
* With the "promote the odd node" rule, a leaf that is promoted at some levels gets a
  shorter proof (`proof_siblings_min` < max), and no duplicated leaf can create two trees
  with the same root.

![benchmark](benchmark.png)
