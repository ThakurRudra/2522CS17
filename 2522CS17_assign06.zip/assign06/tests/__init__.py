"""Tests for p2pnet."""
