"""Tests for the wire protocol, the mempool and the five-node network (Assignment 6)."""
import asyncio
import time

import pytest

from p2pnet import wire
from p2pnet.chain import make_genesis
from p2pnet.ledger import Ledger
from p2pnet.mempool import Mempool
from p2pnet.node import Node, Params
from p2pnet.tx import Transaction, TxIn, TxOut
from p2pnet.wallet import Wallet


# ---------------------------------------------------------------- framing
def read(data):
    async def go():
        r = asyncio.StreamReader()   # created inside the running loop
        r.feed_data(data)
        r.feed_eof()
        return await wire.read_frame(r)
    return asyncio.run(go())


def test_roundtrip_and_header_layout():
    f = wire.encode("ping", {"nonce": 42})
    assert f[:4] == b"TCN6" and int.from_bytes(f[4:8], "big") == len(f) - 12
    assert wire.decode(read(f)) == ("ping", {"nonce": 42})


def test_oversize_length_is_fatal_and_not_read():
    with pytest.raises(wire.FrameError) as e:
        read(wire.raw_frame(b"x", length=wire.MAX_MESSAGE_SIZE + 1))
    assert e.value.code == "too-large" and e.value.fatal


def test_bad_magic_is_fatal():
    with pytest.raises(wire.FrameError) as e:
        read(wire.raw_frame(b"{}", magic=b"EVIL"))
    assert e.value.code == "bad-magic" and e.value.fatal


def test_bad_checksum_not_fatal():
    with pytest.raises(wire.FrameError) as e:
        read(wire.raw_frame(b'{"v":1}', checksum=b"\0\0\0\0"))
    assert e.value.code == "bad-checksum" and not e.value.fatal


def test_truncated_frame_raises_incomplete():
    with pytest.raises(asyncio.IncompleteReadError):
        read(wire.encode("ping", {"nonce": 1})[:-3])


@pytest.mark.parametrize("body,code", [
    (b"{oops", "bad-json"), (b'{"v":1,"type":"ping"}', "bad-envelope"),
    (b'{"v":2,"type":"ping","payload":{"nonce":1}}', "unsupported-version"),
    (b'{"v":1,"type":"launch","payload":{}}', "unknown-type"),
    (b'{"v":1,"type":"ping","payload":{"nonce":"1"}}', "bad-schema"),
    (b'{"v":1,"type":"inv","payload":{"items":[{"type":"tx","id":"xyz"}]}}', "bad-schema"),
    (b'{"v":1,"type":"version","payload":{"node_id":"a"}}', "bad-schema"),
])
def test_decode_rejects(body, code):
    with pytest.raises(wire.FrameError) as e:
        wire.decode(body)
    assert e.value.code == code


def test_all_required_message_types_exist():
    for t in ("version", "verack", "getaddr", "addr", "inv", "getdata", "tx", "block", "ping", "pong", "error"):
        assert t in wire.MESSAGE_TYPES


# ---------------------------------------------------------------- mempool
@pytest.fixture
def setup():
    a, b, c = Wallet.generate("a"), Wallet.generate("b"), Wallet.generate("c")
    L = Ledger()
    g = L.add_genesis([TxOut(40, a.pkh), TxOut(70, a.pkh), TxOut(50, c.pkh)])
    return L, a, b, c, g


def test_mempool_accept_and_duplicate(setup):
    L, a, b, c, g = setup
    mp = Mempool()
    tx = a.build_payment(L, b.pkh, 10, 1)
    assert mp.add(tx, L, 0)[0] == "accepted"
    assert mp.add(tx, L, 0)[0] == "duplicate"


def test_mempool_rejects_invalid(setup):
    L, a, b, c, g = setup
    mp = Mempool()
    steal = b.sign(Transaction(1, (TxIn(L.utxos_for(a.pkh)[0][0]),), (TxOut(40, b.pkh),), 0))
    st, why = mp.add(steal, L, 0)
    assert st == "rejected" and why.startswith("wrong-key")


def test_mempool_feerate_order(setup):
    L, a, b, c, g = setup
    mp = Mempool()
    low = c.build_payment(L, b.pkh, 10, 1)
    high = a.build_payment(L, b.pkh, 10, 9)
    mp.add(low, L, 0); mp.add(high, L, 1)
    assert [t.txid for t in mp.ordered()] == [high.txid, low.txid]


def test_mempool_expiry(setup):
    L, a, b, c, g = setup
    mp = Mempool(ttl=10)
    tx = a.build_payment(L, b.pkh, 10, 1)
    mp.add(tx, L, 100)
    assert mp.expire(105) == [] and mp.expire(111) == [tx.txid] and len(mp) == 0


def test_mempool_conflict_and_replace_by_fee(setup):
    L, a, b, c, g = setup
    mp = Mempool()
    first = a.build_payment(L, b.pkh, 60, 2)            # spends the 70 coin
    lower = a.build_payment(L, c.pkh, 61, 1)             # same input, lower fee rate
    better = a.build_payment(L, c.pkh, 50, 12)           # same input, higher fee rate
    assert mp.add(first, L, 0)[0] == "accepted"
    st, why = mp.add(lower, L, 0)
    assert st == "rejected" and why.startswith("conflict")
    assert mp.add(better, L, 0)[0] == "replaced"
    assert first.txid not in mp and better.txid in mp


def test_mempool_revalidate_after_block(setup):
    L, a, b, c, g = setup
    mp = Mempool()
    tx = a.build_payment(L, b.pkh, 60, 2)
    mp.add(tx, L, 0)
    conflicting = a.build_payment(L, c.pkh, 65, 1)
    L.apply(conflicting)                                 # a block confirms a conflicting spend
    assert mp.revalidate(L) == [tx.txid] and len(mp) == 0


# ---------------------------------------------------------------- live network
def test_handshake_relay_and_rate_limit():
    async def scenario():
        a = Wallet.generate("a")
        g = make_genesis([TxOut(100, a.pkh)])
        logs = []
        p = Params(handshake_timeout=1.0, rate=50, burst=60)
        n1, n2 = Node("n1", g, 19451, params=p, log=logs), Node("n2", g, 19452, params=p, log=logs)
        await n1.start(); await n2.start()
        try:
            await n2.connect("127.0.0.1", 19451)
            for _ in range(40):
                if n1.peers and n2.peers:
                    break
                await asyncio.sleep(0.05)
            assert "n2" in n1.peers and "n1" in n2.peers
            tx = a.build_payment(n1.chain.ledger, "33" * 20, 10, 1)
            n1.submit_tx(tx)
            for _ in range(40):
                if tx.txid in n2.mempool:
                    break
                await asyncio.sleep(0.05)
            assert tx.txid in n2.mempool                 # inv -> getdata -> tx
            n1.mine(8)
            for _ in range(40):
                if n2.chain.height == 1:
                    break
                await asyncio.sleep(0.05)
            assert n2.chain.tip.block.hash == n1.chain.tip.block.hash and len(n2.mempool) == 0
            # flood n1 from a raw socket
            r, w = await asyncio.open_connection("127.0.0.1", 19451)
            w.write(wire.encode("version", {"node_id": "flood", "listen_port": 1, "height": 0, "tip": g.hash,
                                            "chain_work": "1", "genesis": g.hash}) + wire.encode("verack"))
            w.write(wire.encode("ping", {"nonce": 1}) * 400)
            await w.drain()
            await asyncio.sleep(0.6)
            assert any(x["event"] == "ban" and x["peer_id"] == "flood" for x in logs)
            assert "n2" in n1.peers                      # honest peer unaffected
            # silent peer -> handshake timeout
            r2, w2 = await asyncio.open_connection("127.0.0.1", 19451)
            t0 = time.monotonic()
            await asyncio.wait_for(r2.read(), 3)
            assert time.monotonic() - t0 < 2.5
        finally:
            await n1.stop(); await n2.stop()
    asyncio.run(scenario())


def test_five_node_partition_experiment_converges():
    from p2pnet.simulation import run
    r = run(quick=True, outdir=None, base_port=19500)
    assert r["converged"] and r["final_height"] == 4
    assert len(set(r["diverged_tips"].values())) == 2            # two branches during the partition
    assert r["tx_c_confirmed_everywhere"] and r["tx_a_dropped_everywhere"]
    assert {x["result"] for x in r["reconsidered"]} == {"accepted", "rejected"}
    adv = r["adversary"]
    assert adv["spammer_banned"] and adv["disconnected_after_oversize"]
    assert "bad-checksum" in adv["misbehaviour_errors_received"]
    assert len(adv["honest_peers_still_connected"]) == 4
    logs = r["logs"]
    assert all({"ts", "node_id", "peer_id", "object_id", "event"} <= set(x) for x in logs)
