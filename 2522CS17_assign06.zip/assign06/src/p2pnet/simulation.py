"""Five-node localhost experiment: discovery, relay, latency, partition, reconnection, convergence,
mempool reconsideration, and an adversarial peer.

Timeline
  0. five nodes listen on 127.0.0.1:<base..base+4>, each with its own one-way link latency;
     node i only bootstraps to node i-1 -> getaddr/addr discovery builds the full mesh
  1. a transaction is relayed (inv -> getdata -> tx) to all mempools; one block confirms it
  2. partition {node0, node1} | {node2, node3, node4}
  3. side A mines one block (Alice->Bob 85 + Carol->Bob 20); side B mines one block with a
     conflicting Alice->Erin 100, then one additional block
  4. heal: nodes redial, sync with getblocks, side A reorganises to the most-work chain;
     Carol->Bob (still valid) returns to the mempool, Alice->Bob (now double-spent) is dropped
  5. one more block confirms the reconsidered transaction on every node
  6. adversarial peer: silent connection, garbage frames, oversize length, bad JSON, invalid tx,
     spam -> errors, scores, ban; honest ping RTT measured during the attack
"""
from __future__ import annotations

import asyncio
import json
import os
import random
import time

from . import wire
from .chain import make_genesis
from .node import Node, Params
from .tx import Transaction, TxIn, TxOut
from .wallet import Wallet


async def wait_until(pred, timeout: float, step: float = 0.05) -> float:
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        if pred():
            return time.monotonic() - t0
        await asyncio.sleep(step)
    raise TimeoutError("condition not reached")


def snapshot(nodes, phase: str) -> list[dict]:
    return [{"phase": phase, **n.status()} for n in nodes]


async def run_experiment(base_port: int = 19100, n_nodes: int = 5, bits: int = 8, quick: bool = False,
                         outdir: str | None = "docs", seed: int = 2522) -> dict:
    random.seed(seed)
    logs: list[dict] = []
    t_start = time.time()
    alice, bob, carol, dave, erin = (Wallet.generate(n) for n in ("alice", "bob", "carol", "dave", "erin"))
    miners = [Wallet.generate(f"miner{i}") for i in range(n_nodes)]
    names = {w.pkh: w.name for w in [alice, bob, carol, dave, erin, *miners]}
    genesis = make_genesis([TxOut(40, alice.pkh), TxOut(70, alice.pkh), TxOut(50, carol.pkh), TxOut(30, dave.pkh)])
    params = Params(ping_interval=1.0, ping_timeout=3.0, handshake_timeout=2.0, rate=100.0, burst=150.0)
    latencies = [0.010 + 0.015 * i for i in range(n_nodes)]   # 10, 25, 40, 55, 70 ms one-way
    nodes = [Node(f"node{i}", genesis, base_port + i, latency=latencies[i], jitter=0.005,
                  miner_pkh=miners[i].pkh, params=params, log=logs, seed=seed + i) for i in range(n_nodes)]
    timeline, phases = [], {}

    def mark(phase):
        phases[phase] = round(time.time() - t_start, 3)
        timeline.extend(snapshot(nodes, phase))
        for n in nodes:
            n.log("phase", obj=phase)

    def converged(group=None):
        g = group or nodes
        return len({n.chain.tip.block.hash for n in g}) == 1 and len({n.chain.ledger.state_hash() for n in g}) == 1

    try:
        for n in nodes:
            await n.start()
        for i in range(1, n_nodes):
            await nodes[i].connect("127.0.0.1", base_port + i - 1)
        t_mesh = await wait_until(lambda: all(len(n.peers) == n_nodes - 1 for n in nodes), 10)
        mark("0-mesh")

        # 1. relay a transaction and confirm it ---------------------------------------------
        t1 = dave.build_payment(nodes[4].chain.ledger, carol.pkh, 5, 1)
        nodes[4].submit_tx(t1)
        t_tx = await wait_until(lambda: all(t1.txid in n.mempool for n in nodes), 5)
        nodes[2].mine(bits)
        t_blk = await wait_until(lambda: converged() and all(n.chain.height == 1 for n in nodes), 5)
        mark("1-relay")

        # 2. partition ----------------------------------------------------------------------
        A, B = nodes[:2], nodes[2:]
        ida, idb = {n.node_id for n in A}, {n.node_id for n in B}
        for n in A:
            n.set_blocked(idb)
        for n in B:
            n.set_blocked(ida)
        await wait_until(lambda: all(len(n.peers) == len(A) - 1 for n in A) and all(len(n.peers) == len(B) - 1 for n in B), 5)
        mark("2-partitioned")

        # 3. both sides mine; side B mines one extra block ------------------------------------
        led = nodes[0].chain.ledger
        tx_a = alice.build_payment(led, bob.pkh, 85, 2)                   # spends 70 + 40
        tx_c = carol.build_payment(led, bob.pkh, 20, 1)                   # independent of Alice
        tx_b = alice.build_payment(nodes[3].chain.ledger, erin.pkh, 100, 3)  # conflicts with tx_a
        nodes[0].submit_tx(tx_a)
        nodes[1].submit_tx(tx_c)
        nodes[3].submit_tx(tx_b)
        await wait_until(lambda: all(tx_a.txid in n.mempool and tx_c.txid in n.mempool for n in A)
                         and all(tx_b.txid in n.mempool for n in B), 5)
        a_block = nodes[0].mine(bits)
        b_block1 = nodes[2].mine(bits)
        await wait_until(lambda: converged(A) and converged(B) and all(n.chain.height == 2 for n in nodes), 5)
        b_block2 = nodes[4].mine(bits)
        await wait_until(lambda: converged(B) and all(n.chain.height == 3 for n in B), 5)
        mark("3-diverged")
        diverged_tips = {n.node_id: n.chain.tip.block.hash[:12] for n in nodes}

        # 4. heal -------------------------------------------------------------------------
        phases["heal-start"] = round(time.time() - t_start, 3)
        for n in nodes:
            n.set_blocked(set())
        t_conv = await wait_until(lambda: converged() and all(len(n.peers) == n_nodes - 1 for n in nodes), 15)
        await wait_until(lambda: all(tx_c.txid in n.mempool for n in nodes), 5)
        mark("4-healed")
        reconsidered = [r for r in logs if r["event"] == "mempool-reconsider"]

        # 5. confirm the reconsidered transaction --------------------------------------------
        final_block = nodes[1].mine(bits)
        await wait_until(lambda: converged() and all(n.chain.height == 4 for n in nodes), 5)
        mark("5-final")
        tx_c_confirmed = all(tx_c.txid in n.chain.ledger.applied for n in nodes)
        tx_a_dropped = all(tx_a.txid not in n.mempool and tx_a.txid not in n.chain.ledger.applied for n in nodes)

        # 6. adversarial peer against node2 --------------------------------------------------
        adv = await adversary(nodes[2], nodes[3], genesis, alice, quick=quick)
        mark("6-adversary")
        balances = {nm: nodes[0].chain.ledger.balance(p) for p, nm in names.items()}
    finally:
        for n in nodes:
            await n.stop()

    stats = {n.node_id: dict(n.stats) for n in nodes}
    result = {
        "latencies_ms": [round(l * 1000) for l in latencies], "phases": phases, "timeline": timeline,
        "mesh_seconds": round(t_mesh, 3), "tx_relay_seconds": round(t_tx, 3), "block_relay_seconds": round(t_blk, 3),
        "convergence_after_heal_seconds": round(t_conv, 3),
        "diverged_tips": diverged_tips, "final_tip": nodes[0].chain.tip.block.hash, "final_height": nodes[0].chain.height,
        "blocks": {"side_A": a_block.hash[:12], "side_B_1": b_block1.hash[:12], "side_B_2": b_block2.hash[:12],
                   "after_heal": final_block.hash[:12]},
        "tx": {"dave_to_carol": t1.txid[:12], "alice_to_bob_sideA": tx_a.txid[:12], "carol_to_bob_sideA": tx_c.txid[:12],
               "alice_to_erin_sideB": tx_b.txid[:12]},
        "reconsidered": [{k: r.get(k) for k in ("node_id", "object_id", "result", "reason")} for r in reconsidered],
        "tx_c_confirmed_everywhere": tx_c_confirmed, "tx_a_dropped_everywhere": tx_a_dropped,
        "balances": balances, "adversary": adv, "stats": stats, "log_count": len(logs),
        "converged": converged(), "utxo_hash": nodes[0].chain.ledger.state_hash(),
    }
    if outdir:
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, "simulation_logs.jsonl"), "w") as fh:
            for r in logs:
                fh.write(json.dumps(r) + "\n")
        with open(os.path.join(outdir, "simulation_result.json"), "w") as fh:
            json.dump(result, fh, indent=2, default=str)
    result["logs"] = logs
    return result


async def _raw(port):
    r, w = await asyncio.open_connection("127.0.0.1", port)
    return r, w


async def _drain_errors(reader, timeout=0.4) -> list[str]:
    codes = []
    try:
        while True:
            body = await asyncio.wait_for(wire.read_frame(reader), timeout)
            t, p = wire.decode(body)
            if t == "error":
                codes.append(p["code"])
    except (asyncio.TimeoutError, asyncio.IncompleteReadError, ConnectionError, wire.FrameError):
        pass
    return codes


async def adversary(target: Node, witness: Node, genesis, alice: Wallet, quick: bool = False) -> dict:
    port = target.port
    out = {}

    # a) connect and stay silent -> handshake timeout
    r, w = await _raw(port)
    t0 = time.monotonic()
    try:
        await asyncio.wait_for(r.read(), target.params.handshake_timeout + 3)
    except asyncio.TimeoutError:
        pass
    out["silent_peer_disconnected_after_s"] = round(time.monotonic() - t0, 2)
    w.close()

    # b) handshake properly, then misbehave
    r, w = await _raw(port)
    hello = {"node_id": "mallory", "listen_port": 1, "height": 0, "tip": genesis.hash, "chain_work": "1",
             "genesis": genesis.hash}
    w.write(wire.encode("version", hello) + wire.encode("verack"))
    await w.drain()
    await asyncio.sleep(0.3)
    bad_tx = alice.sign(Transaction(1, (TxIn(target.chain.ledger.utxos_for(alice.pkh)[0][0]
                                             if target.chain.ledger.utxos_for(alice.pkh) else
                                             list(target.chain.ledger.utxos)[0]),), (TxOut(10**6, alice.pkh),), 0))
    attacks = [
        ("bad checksum", wire.raw_frame(b'{"v":1,"type":"ping","payload":{"nonce":1}}', checksum=b"\0\0\0\0")),
        ("invalid JSON", wire.raw_frame(b"{not json")),
        ("unknown message type", wire.raw_frame(b'{"v":1,"type":"selfdestruct","payload":{}}')),
        ("wrong protocol version", wire.raw_frame(b'{"v":9,"type":"ping","payload":{"nonce":1}}')),
        ("schema violation", wire.encode("inv", {"items": [{"type": "car", "id": "zz"}]})),
        ("invalid tx (value creation)", wire.encode("tx", {"tx": bad_tx.to_dict()})),
        ("malformed block object", wire.encode("block", {"block": {"header": 5}})),
        ("duplicate inv of known block", wire.encode("inv", {"items": [{"type": "block", "id": target.chain.tip.block.hash}]})),
    ]
    for _, frame in attacks:
        w.write(frame)
    await w.drain()
    errors = await _drain_errors(r)
    peer = target.peers.get("mallory")
    out["misbehaviour_errors_received"] = errors
    out["score_after_malformed"] = peer.score if peer else "disconnected"
    # oversize length: fatal for the connection
    w.write(wire.raw_frame(b"x", length=wire.MAX_MESSAGE_SIZE + 1))
    await w.drain()
    errs2 = await _drain_errors(r, 0.6)
    out["oversize_frame_errors"] = errs2
    out["disconnected_after_oversize"] = "mallory" not in target.peers
    w.close()

    # c) spam: thousands of pings while an honest peer measures RTT
    await asyncio.sleep(0.2)
    target.banned.clear()
    r, w = await _raw(port)
    hello["node_id"] = "spammer"
    w.write(wire.encode("version", hello) + wire.encode("verack"))
    await w.drain()
    await asyncio.sleep(0.3)
    honest_rtts = []
    spam = wire.encode("ping", {"nonce": 7}) * (600 if quick else 1500)
    w.write(spam)
    try:
        await w.drain()
    except ConnectionError:
        pass
    for _ in range(6):
        q = witness.peers.get(target.node_id)
        if q:
            q.ping_nonce, q.ping_sent = 99, time.monotonic()
            q.send("ping", {"nonce": 99})
        await asyncio.sleep(0.25)
        if q and q.rtt_ms is not None:
            honest_rtts.append(q.rtt_ms)
    out["spammer_banned"] = any(r_["event"] == "ban" and r_["peer_id"] == "spammer" for r_ in target.logsink)
    out["rate_limited_messages"] = target.stats["rate-limited"]
    out["honest_rtt_ms_during_spam"] = honest_rtts
    out["honest_peers_still_connected"] = sorted(target.peers)
    w.close()
    # banned peer cannot reconnect immediately
    r, w = await _raw(port)
    w.write(wire.encode("version", hello) + wire.encode("verack"))
    await w.drain()
    errs3 = await _drain_errors(r, 0.6)
    out["reconnect_while_banned"] = errs3 or ["closed"]
    w.close()
    return out


def run(quick: bool = False, outdir: str | None = "docs", base_port: int = 19100) -> dict:
    return asyncio.run(run_experiment(base_port=base_port, quick=quick, outdir=outdir))
