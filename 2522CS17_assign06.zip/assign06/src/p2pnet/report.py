"""docs/network_report.md + docs/convergence.png from a simulation result."""
from __future__ import annotations

import os
from collections import Counter

from .wire import MAX_MESSAGE_SIZE, MESSAGE_TYPES


def plot(result: dict, path: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    logs = result["logs"]
    t0 = min(r["ts"] for r in logs)
    ph = result["phases"]
    t_end = ph.get("5-final", 3) + 0.3
    fig, ax = plt.subplots(figsize=(10, 3.8))
    nodes = sorted({r["node_id"] for r in logs})
    for k, n in enumerate(nodes):
        pts = [(0.0, 0)] + [(r["ts"] - t0, r["height"]) for r in logs if r["node_id"] == n and "height" in r
                            and r["event"] in ("block-connected", "block-reorg") and r["ts"] - t0 <= t_end]
        pts.append((t_end, pts[-1][1]))
        xs, ys = zip(*pts)
        ax.step(xs, [y + 0.05 * k for y in ys], where="post", label=n, lw=1.8)
        for r in logs:
            if r["node_id"] == n and r["event"] == "block-reorg":
                ax.plot(r["ts"] - t0, r["height"] + 0.05 * k, "kx", ms=9)
    for name, label in (("2-partitioned", "partition"), ("heal-start", "heal"), ("5-final", "all converged")):
        if name in ph:
            ax.axvline(ph[name], color="grey", ls="--", lw=1)
            ax.text(ph[name] + 0.01, 0.2, label, rotation=90, fontsize=8, color="dimgrey")
    ax.set_xlabel("seconds since start"); ax.set_ylabel("active chain height")
    ax.set_title("Tip height per node (x = reorganisation onto the most-work chain)")
    ax.set_xlim(0, t_end)
    ax.legend(ncol=5, fontsize=8, loc="upper left"); ax.grid(alpha=.3)
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def build(result: dict, outdir: str = "docs") -> str:
    os.makedirs(outdir, exist_ok=True)
    try:
        plot(result, os.path.join(outdir, "convergence.png"))
    except ImportError:
        pass
    tl = result["timeline"]
    phases = []
    for ph in sorted({r["phase"] for r in tl}):
        rows = [r for r in tl if r["phase"] == ph]
        phases.append(f"| {ph} | " + " | ".join(f"h{r['height']} `{r['tip'][:8]}` ({len(r['peers'])} peers, mp {r['mempool']})"
                                               for r in rows) + " |")
    ev = Counter(r["event"] for r in result["logs"])
    sent = Counter()
    for s in result["stats"].values():
        for k, v in s.items():
            if k.startswith("sent:"):
                sent[k[5:]] += v
    dup = sum(s.get("inv-duplicate", 0) + s.get("block-duplicate", 0) + s.get("tx-duplicate", 0)
              for s in result["stats"].values())
    adv = result["adversary"]
    sample = [r for r in result["logs"] if r["event"] in ("tx-accepted", "getdata", "block-reorg", "mempool-reconsider",
                                                          "penalty", "ban")][:8]
    import json
    md = f"""# Network report — peer-to-peer mempool and block relay (Assignment 6)

Student: Rudra Pratap Singh (2522CS17). Five instances of the Assignment 5 node (own chain manager,
own mempool, own TCP listener on 127.0.0.1) communicate **only** through TCP sockets.

## Protocol P2P-1
Frame = `magic "TCN6" (4) | length u32 BE (4) | SHA256(payload)[0:4] (4) | payload`; maximum payload
{MAX_MESSAGE_SIZE:,} bytes, checked before the payload is read. Payload = JSON envelope `{{"v": 1, "type", "payload"}}`.

| type | purpose |
|---|---|
""" + "\n".join(f"| `{k}` | {v} |" for k, v in MESSAGE_TYPES.items()) + f"""

Peer policy: handshake (`version`/`verack`) must finish within the timeout; ping every interval, pong
timeout disconnects; token-bucket rate limit per peer (excess messages dropped, +1 point each);
penalty points for malformed frames/messages and invalid objects; at 100 points the peer is
disconnected and banned temporarily. Relay is inventory-first (`inv` → `getdata` → object) with
per-peer known-inventory sets, a global seen set and in-flight request tracking, so duplicates are
suppressed.

Mempool: validated against the UTXO set; duplicates ignored; ordered by fee rate (fee / bytes);
entries expire after a TTL; a conflicting spend replaces the existing one only with a strictly higher
fee rate; after every block/reorg the pool is revalidated and transactions from disconnected blocks
are reconsidered.

## Experiment
One-way link latencies (ms) per node: {result['latencies_ms']}.
Partition: {{node0, node1}} | {{node2, node3, node4}}.

| phase | node0 | node1 | node2 | node3 | node4 |
|---|---|---|---|---|---|
{chr(10).join(phases)}

![convergence](convergence.png)

* Full mesh by discovery (each node bootstrapped to one neighbour): {result['mesh_seconds']} s.
* Transaction relay to all 5 mempools: {result['tx_relay_seconds']} s; block relay to all: {result['block_relay_seconds']} s.
* During the partition side A mined `{result['blocks']['side_A']}` (Alice→Bob 85, Carol→Bob 20);
  side B mined `{result['blocks']['side_B_1']}` (conflicting Alice→Erin 100) and then `{result['blocks']['side_B_2']}`.
* After healing, every honest node converged on the most-work chain in **{result['convergence_after_heal_seconds']} s**;
  all honest nodes share tip `{result['final_tip'][:16]}…` (height {result['final_height']}) and UTXO hash `{result['utxo_hash'][:16]}…`: **{result['converged']}**.
* Stale-block transactions reconsidered for the mempool:
""" + "\n".join(f"  * {r['node_id']}: `{r['object_id']}` → **{r['result']}** ({r['reason']})" for r in result["reconsidered"]) + f"""
* Carol→Bob was confirmed on every node after the next block: **{result['tx_c_confirmed_everywhere']}**;
  Alice→Bob (double-spent by Alice→Erin on the winning chain) dropped everywhere: **{result['tx_a_dropped_everywhere']}**.
* Final balances: {', '.join(f'{k} {v}' for k, v in result['balances'].items())}.

## Robustness against a misbehaving peer (attacking node2)
| attack | node behaviour |
|---|---|
| connect and send nothing | disconnected by handshake timeout after {adv['silent_peer_disconnected_after_s']} s |
| bad checksum, invalid JSON, unknown type, wrong protocol version, schema violation | `error` replies {adv['misbehaviour_errors_received']}, message discarded, connection kept |
| invalid transaction, malformed block object | rejected, penalty points (score after all malformed input: {adv['score_after_malformed']}) |
| duplicate `inv` of a known block | ignored, no `getdata` (duplicate suppression) |
| frame declaring length > 1 MiB | `error` {adv['oversize_frame_errors']} and disconnect: {adv['disconnected_after_oversize']} |
| flood of pings | {adv['rate_limited_messages']} messages dropped by the rate limiter, spammer banned: {adv['spammer_banned']} |
| banned peer reconnects | {adv['reconnect_while_banned']} |

Honest node3 → node2 ping RTT during the flood (ms): {adv['honest_rtt_ms_during_spam']} — node2 stayed responsive
(the RTT ≈ sum of the two one-way link latencies); honest peers still connected: {adv['honest_peers_still_connected']}.

## Traffic
Messages sent by all nodes: {', '.join(f'{k} {v}' for k, v in sent.most_common())}.
Duplicate announcements/objects suppressed: {dup}. Log events: {', '.join(f'{k} {v}' for k, v in ev.most_common(14))}.

## Structured logs
`docs/simulation_logs.jsonl` holds {result['log_count']} JSON lines with `ts`, `node_id`, `peer_id`, `object_id`, `event` (+ details). Examples:
```
""" + "\n".join(json.dumps(r) for r in sample) + "\n```\n"
    with open(os.path.join(outdir, "network_report.md"), "w") as fh:
        fh.write(md)
    return md
