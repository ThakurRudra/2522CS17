"""(Reused from Assignment 5.) Node-local chain manager: block validation, most-work chain selection, reorganisation.

* Every received block gets context-free checks (version, target <= POW_LIMIT, PoW,
  Merkle root, coinbase height) and contextual header checks (known parent, timestamp).
* Valid headers are stored in a block index with their cumulative chain work.
* The active chain is the valid chain with the MOST CUMULATIVE WORK (not the most blocks);
  on a tie the first-seen tip is kept.
* Switching chains = disconnect active blocks back to the fork point using undo data
  (restores spent outputs, removes created ones), then connect the new branch block by block,
  validating every state transition (coinbase value, every transaction).
* If any block of the new branch is invalid, it and its descendants are marked invalid, the
  partial branch is disconnected again and the old branch reconnected: the active chain and
  UTXO set end up exactly as before.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from .block import (POW_LIMIT, SUBSIDY, ZERO_HASH, Block, BlockHeader, Coinbase, coinbase_ok,
                    merkle_root, target_from_bits)
from .ledger import Ledger, Rejected
from .tx import OutPoint, Transaction

MAX_FUTURE_SECONDS = 2 * 60 * 60


@dataclass
class BlockIndex:
    block: Block
    height: int
    chain_work: int
    parent: str | None
    invalid: bool = False
    seen_order: int = 0


@dataclass
class Undo:
    spent: list = field(default_factory=list)    # [(OutPoint, TxOut)]
    created: list = field(default_factory=list)  # [OutPoint]
    txids: list = field(default_factory=list)


@dataclass
class SubmitResult:
    status: str        # connected | reorg | side-branch | duplicate | orphan | rejected
    block_hash: str
    reason: str = ""
    disconnected: list = field(default_factory=list)   # hashes removed from the active chain
    connected: list = field(default_factory=list)      # hashes added to the active chain
    returned_txs: list = field(default_factory=list)   # txs from disconnected blocks (for the mempool)


class ChainManager:
    def __init__(self, genesis: Block, clock=time.time):
        self.clock = clock
        self.index: dict[str, BlockIndex] = {}
        self.undo: dict[str, Undo] = {}
        self.orphans: dict[str, list[Block]] = {}
        self.ledger = Ledger()
        self._counter = 0
        if not genesis.header.pow_ok() or genesis.header.merkle_root != genesis.computed_merkle_root():
            raise ValueError("invalid genesis block")
        self.index[genesis.hash] = BlockIndex(genesis, 0, genesis.header.work, None)
        self.ledger, self.undo[genesis.hash] = self._connect(self.ledger, genesis, 0, genesis_block=True)
        self.active: list[str] = [genesis.hash]
        self.genesis_hash = genesis.hash

    # ------------------------------------------------------------------ queries
    @property
    def tip(self) -> BlockIndex:
        return self.index[self.active[-1]]

    @property
    def height(self) -> int:
        return len(self.active) - 1

    def chain_work(self) -> int:
        return self.tip.chain_work

    def get(self, h: str) -> Block | None:
        bi = self.index.get(h)
        return bi.block if bi else None

    def locator(self) -> list[str]:
        return list(reversed(self.active))

    # ------------------------------------------------------------------ checks
    def check_block_standalone(self, b: Block) -> None:
        h = b.header
        if h.version != 1:
            raise Rejected("bad-version", f"header version {h.version} != 1")
        if not 0 < h.target <= POW_LIMIT:
            raise Rejected("bad-target", "target above the proof-of-work limit")
        if not h.pow_ok():
            raise Rejected("bad-pow", f"header hash {b.hash[:16]}… is above the target")
        ids = b.txids()
        if len(set(ids)) != len(ids):
            raise Rejected("duplicate-tx-in-block", "block contains the same transaction twice")
        if h.merkle_root != merkle_root(ids):
            raise Rejected("bad-merkle-root", "merkle root in header does not match the transactions")

    def submit_block(self, b: Block) -> SubmitResult:
        bh = b.hash
        if bh in self.index:
            st = "rejected" if self.index[bh].invalid else "duplicate"
            return SubmitResult(st, bh, "already known" + (" (invalid)" if st == "rejected" else ""))
        try:
            self.check_block_standalone(b)
        except Rejected as r:
            return SubmitResult("rejected", bh, f"{r.code}: {r.message}")
        parent = self.index.get(b.header.prev_hash)
        if parent is None:
            self.orphans.setdefault(b.header.prev_hash, []).append(b)
            return SubmitResult("orphan", bh, "parent unknown; stored until it arrives")
        if parent.invalid:
            self.index[bh] = BlockIndex(b, parent.height + 1, 0, parent.block.hash, invalid=True)
            return SubmitResult("rejected", bh, "bad-ancestry: parent block is invalid")
        if b.header.timestamp < parent.block.header.timestamp:
            return SubmitResult("rejected", bh, "bad-timestamp: earlier than parent")
        if b.header.timestamp > self.clock() + MAX_FUTURE_SECONDS:
            return SubmitResult("rejected", bh, "bad-timestamp: too far in the future")
        if b.coinbase.height != parent.height + 1:
            return SubmitResult("rejected", bh, f"bad-coinbase-height: {b.coinbase.height} != {parent.height + 1}")
        self._counter += 1
        self.index[bh] = BlockIndex(b, parent.height + 1, parent.chain_work + b.header.work, parent.block.hash,
                                    seen_order=self._counter)
        res = self._activate_best_chain(bh)
        # adopt any orphans waiting for this block
        for child in self.orphans.pop(bh, []):
            r2 = self.submit_block(child)
            if r2.status in ("connected", "reorg"):
                res.connected += r2.connected
                res.disconnected += r2.disconnected
                res.returned_txs += r2.returned_txs
        return res

    # ------------------------------------------------------------------ chain selection
    def _ancestors(self, h: str) -> list[str]:
        out = []
        while h is not None:
            out.append(h)
            h = self.index[h].parent
        return list(reversed(out))

    def _activate_best_chain(self, new_hash: str) -> SubmitResult:
        new = self.index[new_hash]
        if new.chain_work <= self.tip.chain_work:
            return SubmitResult("side-branch", new_hash,
                                f"valid header, chain work {new.chain_work} <= active {self.tip.chain_work}")
        new_path = self._ancestors(new_hash)
        fork = 0
        while fork < min(len(new_path), len(self.active)) and new_path[fork] == self.active[fork]:
            fork += 1
        to_disconnect = self.active[fork:]
        to_connect = new_path[fork:]
        old_active, old_ledger = list(self.active), self.ledger

        ledger = self.ledger
        returned = []
        for h in reversed(to_disconnect):
            ledger = self._disconnect(ledger, self.index[h].block, self.undo[h])
            returned.extend(self.index[h].block.txs)
        connected = []
        for h in to_connect:
            bi = self.index[h]
            try:
                ledger, undo = self._connect(ledger, bi.block, bi.height)
            except Rejected as r:
                self._mark_invalid(h)
                # restore the previous best chain exactly as it was
                self.active, self.ledger = old_active, old_ledger
                return SubmitResult("rejected", new_hash, f"{r.code}: {r.message} (in block {h[:16]}…); "
                                                          f"active chain unchanged")
            self.undo[h] = undo
            connected.append(h)
        self.active = new_path
        self.ledger = ledger
        confirmed = {t for h in to_connect for t in self.index[h].block.txids()}
        returned = [t for t in returned if t.txid not in confirmed]
        status = "reorg" if to_disconnect else "connected"
        return SubmitResult(status, new_hash, "" if status == "connected" else
                            f"reorganised: {len(to_disconnect)} block(s) disconnected, {len(to_connect)} connected",
                            disconnected=to_disconnect, connected=connected, returned_txs=returned)

    def _mark_invalid(self, h: str) -> None:
        self.index[h].invalid = True
        for k, bi in self.index.items():
            if not bi.invalid and h in self._ancestors(k):
                bi.invalid = True

    # ------------------------------------------------------------------ state transitions
    def _connect(self, ledger: Ledger, b: Block, height: int, genesis_block: bool = False):
        L = ledger.clone()
        undo = Undo()
        fees = 0
        for tx in b.txs:
            spent = [(i.prev, L.utxos.get(i.prev)) for i in tx.inputs]
            rc = L.apply(tx)  # raises Rejected with a precise reason
            fees += rc.fee
            undo.spent += spent
            undo.created += [OutPoint(rc.txid, k) for k in range(len(tx.outputs))]
            undo.txids.append(rc.txid)
        cb = b.coinbase
        if not genesis_block:
            if cb.height != height:
                raise Rejected("bad-coinbase-height", f"coinbase height {cb.height} != {height}")
            if not coinbase_ok(cb, fees):
                raise Rejected("bad-coinbase-value", f"coinbase pays {cb.total()} > subsidy {SUBSIDY} + fees {fees}")
        if cb.txid in L.applied:
            raise Rejected("duplicate-coinbase", "coinbase txid already exists")
        for k, o in enumerate(cb.outputs):
            L.utxos[OutPoint(cb.txid, k)] = o
            undo.created.append(OutPoint(cb.txid, k))
        L.applied.add(cb.txid)
        undo.txids.append(cb.txid)
        return L, undo

    @staticmethod
    def _disconnect(ledger: Ledger, b: Block, undo: Undo) -> Ledger:
        L = ledger.clone()
        for op in undo.created:
            L.utxos.pop(op, None)
        for op, out in undo.spent:
            L.utxos[op] = out
            L.spent_by.pop(op, None)
        for t in undo.txids:
            L.applied.discard(t)
        return L


# ---------------------------------------------------------------------- genesis
def make_genesis(allocations, bits: int = 8, timestamp: int = 1_767_225_600) -> Block:
    """Genesis = premine of the initial allocations (2026-01-01 00:00 UTC)."""
    from .pow import solve
    cb = Coinbase(0, tuple(allocations), "genesis 2522CS17")
    hdr = BlockHeader(1, ZERO_HASH, merkle_root([cb.txid]), timestamp, target_from_bits(bits), 0)
    nonce, _ = solve(hdr)
    return Block(BlockHeader(1, ZERO_HASH, hdr.merkle_root, timestamp, hdr.target, nonce), cb, ())
