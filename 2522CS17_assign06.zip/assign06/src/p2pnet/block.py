"""(Reused from Assignment 5.) Block header, coinbase, block body, Merkle root and Proof-of-Work helpers.

Header (116 bytes, big-endian):
  version u32 | prev_hash 32 | merkle_root 32 | timestamp u64 | target 32 (full 256-bit) | nonce u64
block_hash = SHA256(SHA256(header)), interpreted as a big-endian unsigned integer for PoW:
  valid PoW  <=>  int(block_hash) <= target
work(target) = floor(2^256 / (target + 1))   (expected number of hashes to find the block)
"""
from __future__ import annotations

import hashlib
import struct
from dataclasses import dataclass, field

from .tx import MAX_VALUE, Transaction, TxOut

HEADER_FMT = ">I32s32sQ32sQ"
HEADER_LEN = struct.calcsize(HEADER_FMT)  # 116
ZERO_HASH = "00" * 32


def sha256d(b: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(b).digest()).digest()


def target_from_bits(zero_bits: int) -> int:
    """Toy difficulty: a target with `zero_bits` leading zero bits (expected 2^zero_bits attempts)."""
    return (1 << (256 - zero_bits)) - 1


def work_from_target(target: int) -> int:
    return (1 << 256) // (target + 1)


# ------------------------------------------------------------------ Merkle (MT-1 from Assignment 2)
def _leaf(d: bytes) -> bytes:
    return hashlib.sha256(b"\x00" + d).digest()


def _node(l: bytes, r: bytes) -> bytes:
    return hashlib.sha256(b"\x01" + l + r).digest()


def merkle_root(txids: list[str]) -> str:
    if not txids:
        return hashlib.sha256(b"").hexdigest()
    level = [_leaf(bytes.fromhex(t)) for t in txids]
    while len(level) > 1:
        nxt = [_node(level[i], level[i + 1]) for i in range(0, len(level) - 1, 2)]
        if len(level) % 2:
            nxt.append(level[-1])
        level = nxt
    return level[0].hex()


# ------------------------------------------------------------------ header
@dataclass(frozen=True)
class BlockHeader:
    version: int
    prev_hash: str
    merkle_root: str
    timestamp: int
    target: int
    nonce: int

    def serialize(self) -> bytes:
        return struct.pack(HEADER_FMT, self.version, bytes.fromhex(self.prev_hash), bytes.fromhex(self.merkle_root),
                           self.timestamp, self.target.to_bytes(32, "big"), self.nonce)

    def prefix(self) -> bytes:
        """Everything except the nonce - lets the miner hash prefix + nonce quickly."""
        return self.serialize()[:-8]

    @property
    def hash(self) -> str:
        return sha256d(self.serialize()).hex()

    def pow_ok(self) -> bool:
        return int(self.hash, 16) <= self.target

    @property
    def work(self) -> int:
        return work_from_target(self.target)

    def to_dict(self) -> dict:
        return {"version": self.version, "prev_hash": self.prev_hash, "merkle_root": self.merkle_root,
                "timestamp": self.timestamp, "target": f"{self.target:064x}", "nonce": self.nonce}

    @staticmethod
    def from_dict(d: dict) -> "BlockHeader":
        return BlockHeader(d["version"], d["prev_hash"], d["merkle_root"], d["timestamp"], int(d["target"], 16), d["nonce"])

    def hexdump(self) -> str:
        raw = self.serialize()
        fields = [("version", 0, 4), ("prev_hash", 4, 32), ("merkle_root", 36, 32), ("timestamp", 68, 8),
                  ("target", 76, 32), ("nonce", 108, 8)]
        lines = [f"{'offset':>6} {'size':>4}  {'field':12s} bytes (hex)"]
        for name, off, size in fields:
            lines.append(f"{off:6d} {size:4d}  {name:12s} {raw[off:off + size].hex()}")
        lines.append("")
        for off in range(0, len(raw), 16):
            chunk = raw[off:off + 16]
            lines.append(f"{off:08x}  {' '.join(f'{b:02x}' for b in chunk):47s}")
        lines.append(f"block_hash = SHA256d(header) = {self.hash}")
        return "\n".join(lines)


# ------------------------------------------------------------------ coinbase and block
@dataclass(frozen=True)
class Coinbase:
    height: int
    outputs: tuple  # tuple[TxOut]
    tag: str = ""   # free text (miner name); makes coinbases of competing miners differ

    @property
    def txid(self) -> str:
        body = b"COINBASE" + struct.pack(">I", self.height) + self.tag.encode()[:64].ljust(64, b"\x00")
        for o in self.outputs:
            body += struct.pack(">Q", max(o.value, 0) & 0xFFFFFFFFFFFFFFFF) + bytes.fromhex(o.pkh)
        return hashlib.sha256(body).hexdigest()

    def total(self) -> int:
        return sum(o.value for o in self.outputs)

    def to_dict(self):
        return {"height": self.height, "tag": self.tag, "outputs": [o.to_dict() for o in self.outputs]}


@dataclass(frozen=True)
class Block:
    header: BlockHeader
    coinbase: Coinbase
    txs: tuple = field(default=())  # tuple[Transaction]

    @property
    def hash(self) -> str:
        return self.header.hash

    def txids(self) -> list[str]:
        return [self.coinbase.txid] + [t.txid for t in self.txs]

    def computed_merkle_root(self) -> str:
        return merkle_root(self.txids())

    def to_dict(self) -> dict:
        return {"hash": self.hash, "header": self.header.to_dict(), "coinbase": self.coinbase.to_dict(),
                "txs": [t.to_dict() for t in self.txs]}


SUBSIDY = 50
POW_LIMIT = target_from_bits(4)   # easiest target any block may use (toy)


def coinbase_ok(cb: Coinbase, fees: int) -> bool:
    return all(0 < o.value <= MAX_VALUE for o in cb.outputs) and cb.total() <= SUBSIDY + fees


# ------------------------------------------------------------------ wire (de)serialisation (added in A6)
def block_from_dict(d: dict) -> Block:
    """Parse a block received from a peer. Raises ValueError/KeyError/TypeError on malformed input."""
    if not isinstance(d, dict) or set(d) - {"hash", "header", "coinbase", "txs"}:
        raise ValueError("block must have header, coinbase, txs")
    h = d["header"]
    if not isinstance(h, dict) or set(h) != {"version", "prev_hash", "merkle_root", "timestamp", "target", "nonce"}:
        raise ValueError("bad header fields")
    for k in ("version", "timestamp", "nonce"):
        if not isinstance(h[k], int) or isinstance(h[k], bool) or h[k] < 0:
            raise ValueError(f"header {k} must be a non-negative integer")
    for k in ("prev_hash", "merkle_root", "target"):
        if not isinstance(h[k], str) or len(h[k]) != 64:
            raise ValueError(f"header {k} must be 64 hex characters")
        bytes.fromhex(h[k])
    header = BlockHeader.from_dict(h)
    c = d["coinbase"]
    if not isinstance(c, dict) or set(c) != {"height", "tag", "outputs"}:
        raise ValueError("bad coinbase fields")
    if not isinstance(c["height"], int) or not isinstance(c["tag"], str) or not isinstance(c["outputs"], list):
        raise ValueError("bad coinbase types")
    outs = []
    for o in c["outputs"]:
        if not isinstance(o, dict) or not isinstance(o.get("value"), int) or not isinstance(o.get("lock"), dict):
            raise ValueError("bad coinbase output")
        pkh = o["lock"].get("pkh")
        if not isinstance(pkh, str) or len(pkh) != 40:
            raise ValueError("bad coinbase pkh")
        bytes.fromhex(pkh)
        outs.append(TxOut(o["value"], pkh))
    if not isinstance(d["txs"], list):
        raise ValueError("txs must be a list")
    txs = tuple(Transaction.from_dict(t) for t in d["txs"])
    return Block(header, Coinbase(c["height"], tuple(outs), c["tag"]), txs)
