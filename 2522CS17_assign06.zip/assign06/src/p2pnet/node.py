"""A P2P full node: the Assignment 5 chain manager + mempool, connected to peers over localhost TCP.

Per peer: handshake state machine with timeout, ordered send queue with simulated latency,
token-bucket rate limiting, ping/pong liveness with timeout, inventory tracking and a misbehaviour
score (disconnect + temporary ban at BAN_SCORE). Relay is inventory-first: a node announces ids
with `inv`, and peers send `getdata` only for objects they do not have.
"""
from __future__ import annotations

import asyncio
import random
import time
from collections import Counter

from . import wire
from .block import block_from_dict
from .chain import ChainManager
from .ledger import Rejected
from .mempool import Mempool
from .pow import mine_block
from .tx import Transaction, TxFormatError

BAN_SCORE = 100
PENALTY = {"bad-checksum": 10, "bad-json": 10, "bad-envelope": 10, "unsupported-version": 5, "unknown-type": 10,
           "bad-schema": 10, "bad-magic": 100, "too-large": 100, "invalid-tx": 10, "invalid-block": 20,
           "malformed-object": 20, "no-handshake": 20, "rate-limit": 1, "unsolicited": 2}
PUNISHABLE_TX = {"bad-signature", "wrong-key", "bad-pubkey", "bad-value", "overflow", "value-creation",
                 "incorrect-change", "duplicate-input", "no-inputs", "no-outputs", "bad-format"}


class Params:
    def __init__(self, **kw):
        self.handshake_timeout = kw.get("handshake_timeout", 3.0)
        self.ping_interval = kw.get("ping_interval", 2.0)
        self.ping_timeout = kw.get("ping_timeout", 4.0)
        self.rate = kw.get("rate", 200.0)          # messages per second refill
        self.burst = kw.get("burst", 400.0)        # bucket size
        self.ban_seconds = kw.get("ban_seconds", 30.0)
        self.max_outbound = kw.get("max_outbound", 8)
        self.mempool_ttl = kw.get("mempool_ttl", 120.0)
        self.request_timeout = kw.get("request_timeout", 2.0)


class Peer:
    def __init__(self, node: "Node", reader, writer, outbound: bool, addr: tuple[str, int]):
        self.node, self.reader, self.writer, self.outbound, self.addr = node, reader, writer, outbound, addr
        self.id: str | None = None
        self.listen_port: int | None = None
        self.got_version = self.got_verack = False
        self.remote_work = 0
        self.score = 0
        self.known: set[str] = set()
        self.tokens = node.params.burst
        self.last_refill = time.monotonic()
        self.connected_at = time.monotonic()
        self.ping_nonce: int | None = None
        self.ping_sent = 0.0
        self.last_ping = time.monotonic()
        self.rtt_ms: float | None = None
        self.q: asyncio.Queue = asyncio.Queue()
        self.closed = False
        self.tasks: list[asyncio.Task] = []

    @property
    def established(self) -> bool:
        return self.got_version and self.got_verack and not self.closed

    @property
    def label(self) -> str:
        return self.id or f"{self.addr[0]}:{self.addr[1]}"

    def send(self, msg_type: str, payload: dict | None = None) -> None:
        if self.closed:
            return
        self.node.stats[f"sent:{msg_type}"] += 1
        self.q.put_nowait((time.monotonic() + self.node.link_delay(), wire.encode(msg_type, payload)))

    async def writer_loop(self):
        try:
            while True:
                due, data = await self.q.get()
                delay = due - time.monotonic()
                if delay > 0:
                    await asyncio.sleep(delay)  # simulated one-way latency, FIFO per link
                self.writer.write(data)
                await self.writer.drain()
        except (ConnectionError, asyncio.CancelledError, RuntimeError):
            pass

    def allow(self) -> bool:
        now = time.monotonic()
        p = self.node.params
        self.tokens = min(p.burst, self.tokens + (now - self.last_refill) * p.rate)
        self.last_refill = now
        if self.tokens >= 1:
            self.tokens -= 1
            return True
        return False


class Node:
    def __init__(self, name: str, genesis, port: int, host: str = "127.0.0.1", latency: float = 0.0,
                 jitter: float = 0.0, miner_pkh: str = "00" * 20, params: Params | None = None, log=None,
                 honest: bool = True, seed: int = 0):
        self.node_id, self.host, self.port = name, host, port
        self.chain = ChainManager(genesis)
        self.params = params or Params()
        self.mempool = Mempool(self.params.mempool_ttl)
        self.latency, self.jitter = latency, jitter
        self.miner_pkh = miner_pkh
        self.peers: dict[str, Peer] = {}          # established, by remote node id
        self.pending: set[Peer] = set()            # handshaking
        self.known_addrs: dict[tuple[str, int], str | None] = {}
        self.blocked: set[str] = set()             # simulated partition
        self.banned: dict[str, float] = {}         # peer label -> unban time
        self.seen: set[str] = set()
        self.requested: dict[str, float] = {}
        self.stats: Counter = Counter()
        self.logsink = log if log is not None else []
        self.rng = random.Random(seed)
        self.server = None
        self._tasks: list[asyncio.Task] = []
        self.honest = honest
        self.t0 = time.time()

    # ------------------------------------------------------------------ utilities
    def link_delay(self) -> float:
        return max(0.0, self.latency + self.rng.uniform(-self.jitter, self.jitter))

    def log(self, event: str, peer=None, obj: str | None = None, **details):
        rec = {"ts": round(time.time(), 4), "node_id": self.node_id,
               "peer_id": peer.label if isinstance(peer, Peer) else peer, "object_id": obj, "event": event}
        rec.update(details)
        self.logsink.append(rec)
        self.stats[f"event:{event}"] += 1

    def status(self) -> dict:
        return {"node": self.node_id, "height": self.chain.height, "tip": self.chain.tip.block.hash[:12],
                "work": self.chain.chain_work(), "peers": sorted(self.peers), "mempool": len(self.mempool),
                "utxo_hash": self.chain.ledger.state_hash()[:12]}

    # ------------------------------------------------------------------ lifecycle
    async def start(self):
        self.server = await asyncio.start_server(self._inbound, self.host, self.port)
        self._tasks.append(asyncio.create_task(self._maintenance()))
        self.log("listen", obj=f"{self.host}:{self.port}")

    async def stop(self):
        for t in self._tasks:
            t.cancel()
        for p in list(self.peers.values()) + list(self.pending):
            self._close(p, "shutdown", log=False)
        if self.server:
            self.server.close()
            try:
                await asyncio.wait_for(self.server.wait_closed(), 1.0)
            except asyncio.TimeoutError:
                pass

    def add_known(self, host: str, port: int, node_id: str | None = None):
        if (host, port) != (self.host, self.port):
            if node_id or (host, port) not in self.known_addrs:
                self.known_addrs[(host, port)] = node_id

    async def connect(self, host: str, port: int) -> Peer | None:
        self.add_known(host, port)
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port), 2.0)
        except (OSError, asyncio.TimeoutError):
            self.stats["connect-failed"] += 1
            return None
        p = Peer(self, reader, writer, True, (host, port))
        self._attach(p)
        return p

    async def _inbound(self, reader, writer):
        addr = writer.get_extra_info("peername")[:2]
        p = Peer(self, reader, writer, False, addr)
        if self.banned.get(f"{addr[0]}:{addr[1]}", 0) > time.time():
            writer.close()
            return
        self._attach(p)

    def _attach(self, p: Peer):
        self.pending.add(p)
        p.tasks = [asyncio.create_task(p.writer_loop()), asyncio.create_task(self._reader(p))]
        c = self.chain
        p.send("version", {"node_id": self.node_id, "listen_port": self.port, "height": c.height,
                           "tip": c.tip.block.hash, "chain_work": f"{c.chain_work():x}", "genesis": c.genesis_hash,
                           "user_agent": "2522CS17-toynode/1.0"})
        self.log("connect", p, direction="outbound" if p.outbound else "inbound")

    def _close(self, p: Peer, reason: str, log: bool = True):
        if p.closed:
            return
        p.closed = True
        self.pending.discard(p)
        if p.id and self.peers.get(p.id) is p:
            del self.peers[p.id]
        try:
            p.writer.close()
        except RuntimeError:
            pass
        for t in p.tasks:
            if t is not asyncio.current_task():
                t.cancel()
        if log:
            self.log("disconnect", p, reason=reason)

    def penalise(self, p: Peer, code: str, detail: str = ""):
        pts = PENALTY.get(code, 10)
        p.score += pts
        self.log("penalty", p, code=code, points=pts, score=p.score, detail=detail[:120])
        if p.score >= BAN_SCORE:
            self.banned[p.label] = time.time() + self.params.ban_seconds
            self.banned[f"{p.addr[0]}:{p.addr[1]}"] = time.time() + self.params.ban_seconds
            self.log("ban", p, score=p.score, seconds=self.params.ban_seconds)
            self._close(p, "banned")

    # ------------------------------------------------------------------ reading
    async def _reader(self, p: Peer):
        try:
            while not p.closed:
                try:
                    body = await wire.read_frame(p.reader)
                except wire.FrameError as fe:
                    self.log("malformed", p, code=fe.code, detail=fe.message)
                    p.send("error", {"code": fe.code, "message": fe.message})
                    if fe.fatal:  # stream cannot be re-synchronised: report, punish, disconnect
                        await asyncio.sleep(self.latency + self.jitter + 0.1)  # let the error frame go out
                        self.penalise(p, fe.code, fe.message)
                        self._close(p, f"fatal frame error {fe.code}")
                        return
                    self.penalise(p, fe.code, fe.message)
                    continue
                if not p.allow():
                    # over the per-peer budget: drop the message unread, +1 misbehaviour point each
                    self.stats["rate-limited"] += 1
                    p.dropped = getattr(p, "dropped", 0) + 1
                    if p.dropped % 50 == 1:
                        self.log("rate-limited", p, dropped=p.dropped, score=p.score)
                    p.score += PENALTY["rate-limit"]
                    if p.score >= BAN_SCORE:
                        self.penalise(p, "rate-limit", f"{p.dropped} messages dropped")
                        return
                    continue
                try:
                    t, payload = wire.decode(body)
                except wire.FrameError as fe:
                    self.log("malformed", p, code=fe.code, detail=fe.message)
                    p.send("error", {"code": fe.code, "message": fe.message})
                    self.penalise(p, fe.code, fe.message)
                    continue
                self.stats[f"recv:{t}"] += 1
                await self._dispatch(p, t, payload)
        except (asyncio.IncompleteReadError, ConnectionError):
            self._close(p, "connection closed by peer")
        except asyncio.CancelledError:
            pass

    async def _dispatch(self, p: Peer, t: str, m: dict):
        if not p.got_version and t != "version":
            self.penalise(p, "no-handshake", f"{t} before version")
            p.send("error", {"code": "no-handshake", "message": "send version first"})
            return
        handler = getattr(self, f"on_{t}")
        await handler(p, m)

    # ------------------------------------------------------------------ handshake + discovery
    async def on_version(self, p: Peer, m: dict):
        if p.got_version:
            self.penalise(p, "unsolicited", "duplicate version")
            return
        rid = m["node_id"]
        if m["genesis"] != self.chain.genesis_hash:
            p.send("error", {"code": "wrong-genesis", "message": "different chain"})
            self._close(p, "wrong genesis")
            return
        if rid == self.node_id or rid in self.blocked or self.banned.get(rid, 0) > time.time():
            p.send("error", {"code": "refused", "message": "partitioned, banned or self"})
            self._close(p, "refused (partition/ban/self)")
            return
        if rid in self.peers:
            self._close(p, "duplicate connection")
            return
        p.id, p.listen_port, p.got_version = rid, m["listen_port"], True
        p.remote_work = int(m["chain_work"], 16)
        self.add_known(p.addr[0], m["listen_port"], rid)
        p.send("verack")
        await self._maybe_established(p)

    async def on_verack(self, p: Peer, m: dict):
        p.got_verack = True
        await self._maybe_established(p)

    async def _maybe_established(self, p: Peer):
        if not p.established or p.id in self.peers:
            return
        self.pending.discard(p)
        self.peers[p.id] = p
        self.log("handshake", p, remote_work=p.remote_work)
        p.send("getaddr")
        if p.listen_port:  # addr relay: tell the other peers about the new node
            for q in self.peers.values():
                if q is not p:
                    q.send("addr", {"addrs": [{"node_id": p.id, "host": p.addr[0], "port": p.listen_port}]})
        if p.remote_work > self.chain.chain_work():
            p.send("getblocks", {"locator": self.chain.locator()[:200]})
        for tx in self.mempool.ordered()[:200]:           # share our mempool inventory
            p.known.add(tx.txid)
        if len(self.mempool):
            p.send("inv", {"items": [{"type": "tx", "id": t.txid} for t in self.mempool.ordered()[:500]]})

    async def on_getaddr(self, p: Peer, m: dict):
        addrs = [{"node_id": q.id, "host": q.addr[0], "port": q.listen_port} for q in self.peers.values()
                 if q is not p and q.listen_port]
        addrs.append({"node_id": self.node_id, "host": self.host, "port": self.port})
        p.send("addr", {"addrs": addrs[:100]})

    async def on_addr(self, p: Peer, m: dict):
        n = 0
        for a in m["addrs"]:
            if isinstance(a, dict) and isinstance(a.get("host"), str) and isinstance(a.get("port"), int) \
                    and a.get("node_id") != self.node_id:
                if (a["host"], a["port"]) not in self.known_addrs:
                    n += 1
                self.add_known(a["host"], a["port"], a.get("node_id"))
        if n:
            self.log("addr", p, learned=n)

    async def on_ping(self, p, m):
        p.send("pong", {"nonce": m["nonce"]})

    async def on_pong(self, p, m):
        if p.ping_nonce == m["nonce"]:
            p.rtt_ms = round((time.monotonic() - p.ping_sent) * 1000, 2)
            p.ping_nonce = None

    async def on_error(self, p, m):
        self.log("peer-error", p, code=m["code"], message=m["message"][:120])

    # ------------------------------------------------------------------ inventory relay
    def _have(self, kind: str, oid: str) -> bool:
        return (oid in self.mempool or oid in self.chain.ledger.applied) if kind == "tx" else (oid in self.chain.index)

    async def on_inv(self, p: Peer, m: dict):
        want = []
        now = time.monotonic()
        for it in m["items"]:
            p.known.add(it["id"])
            if self._have(it["type"], it["id"]) or it["id"] in self.seen:
                self.stats["inv-duplicate"] += 1
                continue
            if now - self.requested.get(it["id"], -1e9) < self.params.request_timeout:
                self.stats["inv-already-requested"] += 1
                continue
            self.requested[it["id"]] = now
            want.append(it)
        if want:
            p.send("getdata", {"items": want})
            self.log("getdata", p, obj=want[0]["id"][:16], count=len(want))

    async def on_getdata(self, p: Peer, m: dict):
        missing = []
        for it in m["items"]:
            if it["type"] == "tx" and it["id"] in self.mempool:
                p.send("tx", {"tx": self.mempool.get(it["id"]).to_dict()})
            elif it["type"] == "block" and it["id"] in self.chain.index:
                p.send("block", {"block": self.chain.index[it["id"]].block.to_dict()})
            else:
                missing.append(it)
            p.known.add(it["id"])
        if missing:
            p.send("notfound", {"items": missing})

    async def on_notfound(self, p, m):
        for it in m["items"]:
            self.requested.pop(it["id"], None)

    def relay(self, kind: str, oid: str, exclude: Peer | None = None):
        n = 0
        for q in self.peers.values():
            if q is exclude or oid in q.known:
                continue
            q.known.add(oid)
            q.send("inv", {"items": [{"type": kind, "id": oid}]})
            n += 1
        return n

    # ------------------------------------------------------------------ objects
    async def on_tx(self, p: Peer | None, m: dict):
        try:
            tx = Transaction.from_dict(m["tx"])
            txid = tx.txid
        except (TxFormatError, KeyError, TypeError, ValueError) as exc:
            if p:
                self.penalise(p, "malformed-object", str(exc))
            return
        self.submit_tx(tx, p)

    def submit_tx(self, tx: Transaction, source: Peer | None = None) -> tuple[str, str]:
        txid = tx.txid
        self.requested.pop(txid, None)
        if txid in self.seen and (txid in self.mempool or txid in self.chain.ledger.applied):
            self.stats["tx-duplicate"] += 1
            self.log("tx-duplicate", source, txid[:16])
            return "duplicate", ""
        self.seen.add(txid)
        st, why = self.mempool.add(tx, self.chain.ledger, time.time())
        if st in ("accepted", "replaced"):
            n = self.relay("tx", txid, exclude=source)
            self.log(f"tx-{st}", source, txid[:16], reason=why, relayed_to=n)
        else:
            self.seen.discard(txid)  # may become valid later (e.g. after a reorg)
            self.log("tx-rejected", source, txid[:16], reason=why)
            code = why.split(":")[0]
            if source and code in PUNISHABLE_TX:
                self.penalise(source, "invalid-tx", why)
        return st, why

    async def on_block(self, p: Peer | None, m: dict):
        try:
            b = block_from_dict(m["block"])
            bh = b.hash
        except (TxFormatError, KeyError, TypeError, ValueError) as exc:
            if p:
                self.penalise(p, "malformed-object", str(exc))
            return
        self.submit_block(b, p)

    def submit_block(self, b, source: Peer | None = None):
        bh = b.hash
        self.requested.pop(bh, None)
        if bh in self.chain.index:
            self.stats["block-duplicate"] += 1
            self.log("block-duplicate", source, bh[:16])
            return None
        res = self.chain.submit_block(b)
        if res.status in ("connected", "reorg"):
            dropped = self.mempool.revalidate(self.chain.ledger)
            back = self.mempool.reconsider(res.returned_txs, self.chain.ledger, time.time())
            n = self.relay("block", bh, exclude=source)
            self.log(f"block-{res.status}", source, bh[:16], height=self.chain.height, work=self.chain.chain_work(),
                     disconnected=[h[:12] for h in res.disconnected], relayed_to=n, mempool_dropped=len(dropped))
            for txid, st, why in back:
                self.log("mempool-reconsider", source, txid[:16], result=st, reason=why)
                if st in ("accepted", "replaced"):
                    self.relay("tx", txid)
        elif res.status == "side-branch":
            self.relay("block", bh, exclude=source)
            self.log("block-side-branch", source, bh[:16], reason=res.reason)
        elif res.status == "orphan":
            self.log("block-orphan", source, bh[:16])
            if source:
                source.send("getblocks", {"locator": self.chain.locator()[:200]})
        else:
            self.log("block-rejected", source, bh[:16], reason=res.reason)
            if source and res.status == "rejected":
                self.penalise(source, "invalid-block", res.reason)
        return res

    async def on_getblocks(self, p: Peer, m: dict):
        active = self.chain.active
        pos = {h: i for i, h in enumerate(active)}
        start = 0
        for h in m["locator"]:
            if h in pos:
                start = pos[h] + 1
                break
        items = [{"type": "block", "id": h} for h in active[start:start + 500] if h not in p.known]
        if items:
            p.send("inv", {"items": items})

    # ------------------------------------------------------------------ mining
    def mine(self, bits: int = 8, tag: str | None = None):
        b, attempts, _ = mine_block(self.chain, self.mempool.ordered(), self.miner_pkh, bits, tag or self.node_id)
        self.log("mined", None, b.hash[:16], height=self.chain.height + 1, txs=len(b.txs), attempts=attempts)
        self.submit_block(b, None)
        return b

    # ------------------------------------------------------------------ partition control
    def set_blocked(self, ids: set[str]):
        self.blocked = set(ids)
        for pid, p in list(self.peers.items()):
            if pid in self.blocked:
                self._close(p, "partition")

    # ------------------------------------------------------------------ maintenance
    async def _maintenance(self):
        try:
            while True:
                await asyncio.sleep(0.2)
                now = time.monotonic()
                for p in list(self.pending):
                    if now - p.connected_at > self.params.handshake_timeout:
                        self.log("timeout", p, what="handshake")
                        self._close(p, "handshake timeout")
                for p in list(self.peers.values()):
                    if p.ping_nonce is not None and now - p.ping_sent > self.params.ping_timeout:
                        self.log("timeout", p, what="pong")
                        self._close(p, "ping timeout")
                    elif p.ping_nonce is None and now - p.last_ping > self.params.ping_interval:
                        p.ping_nonce, p.ping_sent, p.last_ping = self.rng.getrandbits(48), now, now
                        p.send("ping", {"nonce": p.ping_nonce})
                        if len(self.peers) < self.params.max_outbound:
                            p.send("getaddr")  # periodic discovery while under-connected
                expired = self.mempool.expire(time.time())
                for t in expired:
                    self.log("mempool-expired", None, t[:16])
                self.requested = {k: v for k, v in self.requested.items() if now - v < 10}
                connected_addrs = {(q.addr[0], q.listen_port) for q in self.peers.values()} | \
                                  {q.addr for q in self.pending if q.outbound}
                outbound = sum(1 for q in self.peers.values() if q.outbound)
                for addr, nid in list(self.known_addrs.items()):
                    if outbound >= self.params.max_outbound:
                        break
                    if addr in connected_addrs or (nid and (nid in self.peers or nid in self.blocked)):
                        continue
                    if nid and self.banned.get(nid, 0) > time.time():
                        continue
                    if nid and nid < self.node_id:
                        continue  # the node with the larger id dials: avoids duplicate pairs
                    asyncio.create_task(self.connect(*addr))
                    outbound += 1
        except asyncio.CancelledError:
            pass
