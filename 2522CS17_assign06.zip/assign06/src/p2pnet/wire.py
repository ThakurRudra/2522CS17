"""Wire protocol P2P-1: length-prefixed frames carrying versioned JSON messages.

Frame (12-byte header + payload):
    magic     4 bytes  b"TCN6"                      (stream sync / wrong-network detection)
    length    u32 BE   payload length, <= MAX_MESSAGE_SIZE (1 MiB) - checked BEFORE reading
    checksum  4 bytes  SHA256(payload)[0:4]
    payload   UTF-8 JSON envelope {"v": 1, "type": <type>, "payload": {...}}

A reader never allocates more than MAX_MESSAGE_SIZE for one message. Bad magic or an oversize
length are fatal for the connection (the stream cannot be re-synchronised); a bad checksum or a
schema error only discards that one message.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import re
import struct

MAGIC = b"TCN6"
PROTOCOL_VERSION = 1
MAX_MESSAGE_SIZE = 1 << 20
HEADER = struct.Struct(">4sI4s")
MAX_INV = 1000
_H64 = re.compile(r"\A[0-9a-f]{64}\Z")

MESSAGE_TYPES = {
    "version":   "handshake: protocol version, node id, listen port, best tip and chain work",
    "verack":    "handshake acknowledgement",
    "getaddr":   "peer discovery request",
    "addr":      "peer discovery answer: list of {node_id, host, port}",
    "inv":       "inventory announcement: list of {type: tx|block, id}",
    "getdata":   "object request for announced ids",
    "notfound":  "requested objects that are not available",
    "tx":        "full transaction",
    "block":     "full block",
    "getblocks": "chain sync: locator of known block hashes; answered with an inv of the missing blocks",
    "ping":      "liveness check with nonce",
    "pong":      "answer to ping (same nonce)",
    "error":     "error response {code, message}",
}


class FrameError(Exception):
    def __init__(self, code: str, message: str, fatal: bool):
        super().__init__(f"{code}: {message}")
        self.code, self.message, self.fatal = code, message, fatal


def encode(msg_type: str, payload: dict | None = None) -> bytes:
    body = json.dumps({"v": PROTOCOL_VERSION, "type": msg_type, "payload": payload or {}},
                      separators=(",", ":"), sort_keys=True).encode()
    if len(body) > MAX_MESSAGE_SIZE:
        raise FrameError("too-large", f"outgoing message {len(body)} bytes", fatal=False)
    return HEADER.pack(MAGIC, len(body), hashlib.sha256(body).digest()[:4]) + body


def raw_frame(body: bytes, magic: bytes = MAGIC, length: int | None = None, checksum: bytes | None = None) -> bytes:
    """Build arbitrary (possibly malformed) frames - used by tests and the adversarial peer."""
    return HEADER.pack(magic, len(body) if length is None else length,
                       hashlib.sha256(body).digest()[:4] if checksum is None else checksum) + body


async def read_frame(reader: asyncio.StreamReader, max_size: int = MAX_MESSAGE_SIZE) -> bytes:
    head = await reader.readexactly(HEADER.size)
    magic, length, chk = HEADER.unpack(head)
    if magic != MAGIC:
        raise FrameError("bad-magic", f"magic {magic!r}", fatal=True)
    if length > max_size:
        raise FrameError("too-large", f"declared length {length} > {max_size}", fatal=True)
    body = await reader.readexactly(length)
    if hashlib.sha256(body).digest()[:4] != chk:
        raise FrameError("bad-checksum", "payload checksum mismatch", fatal=False)
    return body


def _items(p, name="items"):
    items = p.get(name)
    if not isinstance(items, list) or len(items) > MAX_INV:
        raise FrameError("bad-schema", f"{name} must be a list of at most {MAX_INV}", fatal=False)
    for it in items:
        if not isinstance(it, dict) or it.get("type") not in ("tx", "block") or not isinstance(it.get("id"), str) \
                or not _H64.match(it["id"]):
            raise FrameError("bad-schema", "inventory item must be {type: tx|block, id: 64 hex}", fatal=False)


def decode(body: bytes) -> tuple[str, dict]:
    try:
        msg = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise FrameError("bad-json", str(exc)[:80], fatal=False) from None
    if not isinstance(msg, dict) or set(msg) != {"v", "type", "payload"}:
        raise FrameError("bad-envelope", "envelope must be {v, type, payload}", fatal=False)
    if msg["v"] != PROTOCOL_VERSION:
        raise FrameError("unsupported-version", f"protocol version {msg['v']!r}", fatal=False)
    t, p = msg["type"], msg["payload"]
    if t not in MESSAGE_TYPES:
        raise FrameError("unknown-type", f"message type {t!r}", fatal=False)
    if not isinstance(p, dict):
        raise FrameError("bad-schema", "payload must be an object", fatal=False)
    # per-type schema checks (objects themselves are validated by the node)
    req = {"version": {"node_id": str, "listen_port": int, "height": int, "tip": str, "chain_work": str, "genesis": str},
           "addr": {"addrs": list}, "tx": {"tx": dict}, "block": {"block": dict}, "getblocks": {"locator": list},
           "ping": {"nonce": int}, "pong": {"nonce": int}, "error": {"code": str, "message": str}}.get(t, {})
    for k, typ in req.items():
        if not isinstance(p.get(k), typ) or (typ is int and isinstance(p.get(k), bool)):
            raise FrameError("bad-schema", f"{t}.{k} must be {typ.__name__}", fatal=False)
    if t in ("inv", "getdata", "notfound"):
        _items(p)
    if t == "getblocks" and (len(p["locator"]) > 200 or not all(isinstance(h, str) and _H64.match(h) for h in p["locator"])):
        raise FrameError("bad-schema", "locator must be <= 200 block hashes", fatal=False)
    if t == "addr" and len(p["addrs"]) > 100:
        raise FrameError("bad-schema", "addr list too long", fatal=False)
    return t, p
