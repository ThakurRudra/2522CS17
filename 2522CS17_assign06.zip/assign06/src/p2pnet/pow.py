"""(Reused from Assignment 5.) Toy Proof-of-Work miner and hash-rate measurement (laptop difficulty, not real mining)."""
from __future__ import annotations

import hashlib
import statistics
import time

from .block import SUBSIDY, Block, BlockHeader, Coinbase, merkle_root, target_from_bits, work_from_target
from .ledger import Rejected
from .tx import TxOut


def solve(hdr: BlockHeader, start_nonce: int = 0, max_attempts: int | None = None) -> tuple[int, int]:
    """Vary the nonce until int(SHA256d(header)) <= target. Returns (nonce, attempts)."""
    prefix, target = hdr.prefix(), hdr.target
    sha = hashlib.sha256
    n = start_nonce
    attempts = 0
    while max_attempts is None or attempts < max_attempts:
        attempts += 1
        if int.from_bytes(sha(sha(prefix + n.to_bytes(8, "big")).digest()).digest(), "big") <= target:
            return n, attempts
        n += 1
    raise RuntimeError("no solution within max_attempts")


def mine_block(chain, txs, miner_pkh: str, bits: int, tag: str = "", parent_hash: str | None = None,
               timestamp: int | None = None, start_nonce: int = 0):
    """Assemble and mine a block on top of `parent_hash` (default: active tip).

    Transactions are validated against the active UTXO set to compute fees; invalid ones are
    skipped (when building on the active tip). Returns (block, attempts, seconds)."""
    parent_hash = parent_hash or chain.tip.block.hash
    parent = chain.index[parent_hash]
    fees, chosen = 0, []
    if parent_hash == chain.tip.block.hash:
        view = chain.ledger.clone()
        for tx in txs:
            try:
                fees += view.apply(tx).fee
                chosen.append(tx)
            except Rejected:
                continue
    else:
        chosen = list(txs)
        fees = sum(t.fee for t in chosen)
    cb = Coinbase(parent.height + 1, (TxOut(SUBSIDY + fees, miner_pkh),), tag)
    ts = max(timestamp if timestamp is not None else int(time.time()), parent.block.header.timestamp)
    mroot = merkle_root([cb.txid] + [t.txid for t in chosen])
    hdr = BlockHeader(1, parent_hash, mroot, ts, target_from_bits(bits), 0)
    t0 = time.perf_counter()
    nonce, attempts = solve(hdr, start_nonce)
    dt = time.perf_counter() - t0
    hdr = BlockHeader(1, parent_hash, mroot, ts, hdr.target, nonce)
    return Block(hdr, cb, tuple(chosen)), attempts, dt


def hashrate(seconds: float = 1.0) -> float:
    """Raw SHA256d header hashes per second on this machine."""
    hdr = BlockHeader(1, "00" * 32, "11" * 32, 0, target_from_bits(255), 0)
    prefix = hdr.prefix()
    sha = hashlib.sha256
    n, t0 = 0, time.perf_counter()
    while True:
        for _ in range(10_000):
            sha(sha(prefix + n.to_bytes(8, "big")).digest()).digest()
            n += 1
        dt = time.perf_counter() - t0
        if dt >= seconds:
            return n / dt


def difficulty_experiment(bits_list=(8, 12, 16), trials=(200, 60, 12), seed_prefix: bytes = b"2522CS17") -> list[dict]:
    """Mine `trials` independent headers at each toy target; compare observed vs expected attempts."""
    rows = []
    for bits, n in zip(bits_list, trials):
        target = target_from_bits(bits)
        expected = work_from_target(target)  # = 2^bits
        attempts, times = [], []
        for t in range(n):
            mroot = hashlib.sha256(seed_prefix + f"{bits}-{t}".encode()).hexdigest()
            hdr = BlockHeader(1, "00" * 32, mroot, 1_767_225_600 + t, target, 0)
            t0 = time.perf_counter()
            _, a = solve(hdr)
            times.append(time.perf_counter() - t0)
            attempts.append(a)
        total_t = sum(times)
        rows.append({"zero_bits": bits, "target": f"{target:064x}", "trials": n, "expected_attempts": expected,
                     "observed_mean_attempts": round(statistics.mean(attempts), 1),
                     "observed_median_attempts": statistics.median(attempts),
                     "ratio_observed_expected": round(statistics.mean(attempts) / expected, 3),
                     "mean_seconds_per_block": round(total_t / n, 4),
                     "hashes_per_second": round(sum(attempts) / total_t)})
    return rows
