"""`p2p` CLI.

  p2p simulate [--quick] [--port 19100]      five-node partition experiment -> docs/network_report.md, logs
  p2p node --port 19001 [--peer 127.0.0.1:19000] [--mine-every 5] [--seconds 30]
                                            one standalone node process (run several in separate terminals)
  p2p protocol                               print the message types
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys

from .wire import MESSAGE_TYPES


def cmd_simulate(a):
    from .report import build
    from .simulation import run
    r = run(quick=a.quick, outdir=a.outdir, base_port=a.port)
    build(r, a.outdir)
    for row in r["timeline"]:
        print(f"{row['phase']:14s} {row['node']}: height={row['height']} tip={row['tip']} peers={len(row['peers'])} "
              f"mempool={row['mempool']}")
    print(f"\nconverged={r['converged']}  convergence after heal {r['convergence_after_heal_seconds']} s")
    for x in r["reconsidered"]:
        print(f"reconsidered on {x['node_id']}: {x['object_id']} -> {x['result']} ({x['reason'][:70]})")
    print("adversary:", json.dumps(r["adversary"]))
    print(f"wrote {a.outdir}/network_report.md, simulation_logs.jsonl ({r['log_count']} lines), convergence.png")
    return 0 if r["converged"] else 1


async def _run_node(a):
    from .chain import make_genesis
    from .node import Node
    from .tx import TxOut
    genesis = make_genesis([TxOut(1000, "11" * 20)])  # same deterministic genesis in every process
    n = Node(f"node{a.port}", genesis, a.port, miner_pkh="22" * 20, log=[])
    await n.start()
    for p in a.peer or []:
        h, port = p.rsplit(":", 1)
        await n.connect(h, int(port))
    t, last = 0.0, 0.0
    while t < a.seconds:
        await asyncio.sleep(0.5)
        t += 0.5
        if a.mine_every and t - last >= a.mine_every:
            last = t
            n.mine(10)
        print(json.dumps(n.status()), flush=True)
    await n.stop()


def main(argv=None):
    p = argparse.ArgumentParser(prog="p2p", description="Peer-to-peer mempool and block relay network")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("simulate"); s.add_argument("--quick", action="store_true")
    s.add_argument("--port", type=int, default=19100); s.add_argument("--outdir", default="docs")
    s.set_defaults(func=cmd_simulate)
    s = sub.add_parser("node"); s.add_argument("--port", type=int, required=True); s.add_argument("--peer", action="append")
    s.add_argument("--mine-every", type=float, default=0); s.add_argument("--seconds", type=float, default=30)
    s.set_defaults(func=lambda a: asyncio.run(_run_node(a)) or 0)
    s = sub.add_parser("protocol")
    s.set_defaults(func=lambda a: [print(f"{k:10s} {v}") for k, v in MESSAGE_TYPES.items()] and 0)
    a = p.parse_args(argv)
    return a.func(a)


if __name__ == "__main__":
    sys.exit(main())
