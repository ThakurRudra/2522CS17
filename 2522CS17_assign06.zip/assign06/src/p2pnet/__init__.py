"""p2pnet - peer-to-peer mempool and block relay network (Assignment 6)."""
__version__ = "1.0.0"
