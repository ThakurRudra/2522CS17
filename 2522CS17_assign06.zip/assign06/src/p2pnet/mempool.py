"""Mempool: validation, duplicate suppression, fee-rate ordering, expiry, conflict handling.

* Only transactions that are valid against the node's current UTXO set are admitted.
* Duplicate txids are ignored (and counted).
* Ordering for block templates: fee rate = fee / serialized size (units per byte), highest first;
  ties broken by arrival order.
* Expiry: entries older than `ttl` seconds are dropped.
* Conflicts: if a new tx spends an outpoint already spent by a mempool tx, it replaces the
  conflicting tx(s) only if its fee rate is strictly higher (replace-by-fee); otherwise rejected.
* After a block (or reorg) the pool is revalidated: confirmed and now-invalid transactions leave;
  transactions from disconnected blocks are reconsidered and re-admitted if still valid.
"""
from __future__ import annotations

from dataclasses import dataclass

from .ledger import Ledger, Rejected
from .tx import OutPoint, Transaction


@dataclass
class Entry:
    tx: Transaction
    fee: int
    size: int
    added: float
    seq: int

    @property
    def feerate(self) -> float:
        return self.fee / self.size


def tx_size(tx: Transaction) -> int:
    return len(tx.body_bytes()) + sum(len(i.pubkey) // 2 + len(i.signature) // 2 for i in tx.inputs)


class Mempool:
    def __init__(self, ttl: float = 120.0, max_entries: int = 5000):
        self.ttl, self.max_entries = ttl, max_entries
        self.entries: dict[str, Entry] = {}
        self.spends: dict[OutPoint, str] = {}
        self._seq = 0
        self.stats = {"accepted": 0, "duplicate": 0, "rejected": 0, "replaced": 0, "expired": 0, "evicted": 0}

    def __contains__(self, txid: str) -> bool:
        return txid in self.entries

    def __len__(self):
        return len(self.entries)

    def get(self, txid: str) -> Transaction | None:
        e = self.entries.get(txid)
        return e.tx if e else None

    def add(self, tx: Transaction, ledger: Ledger, now: float) -> tuple[str, str]:
        """Returns (status, reason); status in accepted | duplicate | rejected | replaced."""
        txid = tx.txid
        if txid in self.entries:
            self.stats["duplicate"] += 1
            return "duplicate", "already in mempool"
        try:
            rc = ledger.validate(tx)
        except Rejected as r:
            self.stats["rejected"] += 1
            return "rejected", f"{r.code}: {r.message}"
        size = tx_size(tx)
        new_rate = rc.fee / size
        conflicts = {self.spends[i.prev] for i in tx.inputs if i.prev in self.spends}
        if conflicts:
            best = max(self.entries[c].feerate for c in conflicts)
            if new_rate <= best:
                self.stats["rejected"] += 1
                return "rejected", (f"conflict: spends an input of mempool tx {sorted(conflicts)[0][:12]} "
                                    f"with fee rate {new_rate:.4f} <= {best:.4f}")
            for c in conflicts:
                self._remove(c)
            self.stats["replaced"] += len(conflicts)
        if len(self.entries) >= self.max_entries:
            worst = min(self.entries.values(), key=lambda e: (e.feerate, -e.seq))
            if worst.feerate >= new_rate:
                self.stats["rejected"] += 1
                return "rejected", "mempool full"
            self._remove(worst.tx.txid)
            self.stats["evicted"] += 1
        self._seq += 1
        self.entries[txid] = Entry(tx, rc.fee, size, now, self._seq)
        for i in tx.inputs:
            self.spends[i.prev] = txid
        self.stats["accepted"] += 1
        return ("replaced" if conflicts else "accepted"), f"fee {rc.fee}, {size} bytes, rate {new_rate:.4f}"

    def _remove(self, txid: str) -> None:
        e = self.entries.pop(txid, None)
        if e:
            for i in e.tx.inputs:
                if self.spends.get(i.prev) == txid:
                    del self.spends[i.prev]

    def ordered(self) -> list[Transaction]:
        return [e.tx for e in sorted(self.entries.values(), key=lambda e: (-e.feerate, e.seq))]

    def expire(self, now: float) -> list[str]:
        old = [t for t, e in self.entries.items() if now - e.added > self.ttl]
        for t in old:
            self._remove(t)
        self.stats["expired"] += len(old)
        return old

    def revalidate(self, ledger: Ledger) -> list[str]:
        """Drop confirmed or no-longer-valid transactions (e.g. inputs spent by a new block)."""
        dropped = []
        for txid, e in list(self.entries.items()):
            if txid in ledger.applied:
                self._remove(txid); dropped.append(txid)
                continue
            try:
                ledger.validate(e.tx)
            except Rejected:
                self._remove(txid); dropped.append(txid)
        return dropped

    def reconsider(self, txs, ledger: Ledger, now: float) -> list[tuple[str, str, str]]:
        """Transactions from disconnected (stale) blocks: re-admit those that are still valid."""
        out = []
        for tx in txs:
            st, why = self.add(tx, ledger, now)
            out.append((tx.txid, st, why))
        return out
