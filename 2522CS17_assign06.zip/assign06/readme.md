# Assignment 6 — A Peer-to-Peer Mempool and Block Relay Network (`p2p`)

**Student:** Rudra Pratap Singh · **Roll:** 2522CS17 · **Course:** Blockchain (Dr. Mayank Agarwal), IIT Patna

Five (or more) instances of the Assignment 5 node talk over **localhost TCP** with a versioned,
length-prefixed protocol. Nodes discover peers, relay transactions and blocks inventory-first, keep a
fee-rate-ordered mempool, rate-limit and score peers, and converge on the most-work chain after a partition.

## How to run
```bash
cd assign06
pip install -e .                 # installs the `p2p` command
pip install -r requirements.txt
pytest -v                        # 21 tests (framing, mempool, live 2-node and 5-node networks)
p2p simulate                     # partition experiment -> docs/network_report.md, docs/simulation_logs.jsonl, docs/convergence.png
p2p protocol                     # list of message types
```
Separate OS processes (one terminal each):
```bash
p2p node --port 19601 --mine-every 2 --seconds 60
p2p node --port 19602 --peer 127.0.0.1:19601 --seconds 60     # ... up to 19605
```
Colab: `notebook/Assignment06_p2p_Colab.ipynb` → Run all.

## Protocol P2P-1
* **Frame:** `magic "TCN6" | length u32 | SHA256(payload)[:4] | payload`, payload ≤ 1 MiB (checked before reading).
* **Envelope:** `{"v": 1, "type": ..., "payload": {...}}`.
* **Messages:** `version`/`verack` (handshake), `getaddr`/`addr` (discovery), `inv` (announcement), `getdata`/`notfound` (object request), `tx`, `block`, `getblocks` (sync after a partition), `ping`/`pong`, `error`.
* **Relay:** inventory before objects; per-peer known sets, a global seen set and in-flight requests suppress duplicates.

## Node policy
| Mechanism | Rule |
|---|---|
| Handshake timeout | 2–3 s to complete `version`/`verack`, else disconnect |
| Liveness | ping every interval, no pong within the timeout → disconnect |
| Rate limit | token bucket per peer (rate/burst); excess messages dropped, +1 point each |
| Malformed input | bad checksum/JSON/schema/type/version → `error` reply + points; bad magic or oversize length → `error`, points, disconnect |
| Invalid objects | invalid tx +10, invalid block +20, malformed object +20 |
| Ban | score ≥ 100 → disconnect and temporary ban |
| Mempool | UTXO validation, duplicate suppression, fee-rate ordering, TTL expiry, replace-by-fee for conflicts, revalidation after blocks, reconsideration of stale-block transactions |
| Latency | per-node one-way delay (10–70 ms) + jitter, FIFO per link |
| Partition | nodes refuse and drop peers of the other group; healing removes the block, nodes redial and sync with `getblocks` |
| Logs | JSON lines with `ts`, `node_id`, `peer_id`, `object_id`, `event` + details |

## Deliverables
* Source `src/p2pnet/`: `wire.py`, `mempool.py`, `node.py`, `simulation.py`, `report.py`, `cli.py` (+ reused A5 chain modules)
* Tests `tests/test_p2p_network.py`
* `docs/network_report.md`, `docs/simulation_logs.jsonl`, `docs/simulation_result.json`, `docs/convergence.png`

Video demo: *(add the unlisted YouTube link here)*
