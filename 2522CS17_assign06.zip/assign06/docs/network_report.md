# Network report — peer-to-peer mempool and block relay (Assignment 6)

Student: Rudra Pratap Singh (2522CS17). Five instances of the Assignment 5 node (own chain manager,
own mempool, own TCP listener on 127.0.0.1) communicate **only** through TCP sockets.

## Protocol P2P-1
Frame = `magic "TCN6" (4) | length u32 BE (4) | SHA256(payload)[0:4] (4) | payload`; maximum payload
1,048,576 bytes, checked before the payload is read. Payload = JSON envelope `{"v": 1, "type", "payload"}`.

| type | purpose |
|---|---|
| `version` | handshake: protocol version, node id, listen port, best tip and chain work |
| `verack` | handshake acknowledgement |
| `getaddr` | peer discovery request |
| `addr` | peer discovery answer: list of {node_id, host, port} |
| `inv` | inventory announcement: list of {type: tx|block, id} |
| `getdata` | object request for announced ids |
| `notfound` | requested objects that are not available |
| `tx` | full transaction |
| `block` | full block |
| `getblocks` | chain sync: locator of known block hashes; answered with an inv of the missing blocks |
| `ping` | liveness check with nonce |
| `pong` | answer to ping (same nonce) |
| `error` | error response {code, message} |

Peer policy: handshake (`version`/`verack`) must finish within the timeout; ping every interval, pong
timeout disconnects; token-bucket rate limit per peer (excess messages dropped, +1 point each);
penalty points for malformed frames/messages and invalid objects; at 100 points the peer is
disconnected and banned temporarily. Relay is inventory-first (`inv` → `getdata` → object) with
per-peer known-inventory sets, a global seen set and in-flight request tracking, so duplicates are
suppressed.

Mempool: validated against the UTXO set; duplicates ignored; ordered by fee rate (fee / bytes);
entries expire after a TTL; a conflicting spend replaces the existing one only with a strictly higher
fee rate; after every block/reorg the pool is revalidated and transactions from disconnected blocks
are reconsidered.

## Experiment
One-way link latencies (ms) per node: [10, 25, 40, 55, 70].
Partition: {node0, node1} | {node2, node3, node4}.

| phase | node0 | node1 | node2 | node3 | node4 |
|---|---|---|---|---|---|
| 0-mesh | h0 `00916d4d` (4 peers, mp 0) | h0 `00916d4d` (4 peers, mp 0) | h0 `00916d4d` (4 peers, mp 0) | h0 `00916d4d` (4 peers, mp 0) | h0 `00916d4d` (4 peers, mp 0) |
| 1-relay | h1 `00981217` (4 peers, mp 0) | h1 `00981217` (4 peers, mp 0) | h1 `00981217` (4 peers, mp 0) | h1 `00981217` (4 peers, mp 0) | h1 `00981217` (4 peers, mp 0) |
| 2-partitioned | h1 `00981217` (1 peers, mp 0) | h1 `00981217` (1 peers, mp 0) | h1 `00981217` (2 peers, mp 0) | h1 `00981217` (2 peers, mp 0) | h1 `00981217` (2 peers, mp 0) |
| 3-diverged | h2 `000acb55` (1 peers, mp 0) | h2 `000acb55` (1 peers, mp 0) | h3 `0037822d` (2 peers, mp 0) | h3 `0037822d` (2 peers, mp 0) | h3 `0037822d` (2 peers, mp 0) |
| 4-healed | h3 `0037822d` (4 peers, mp 1) | h3 `0037822d` (4 peers, mp 1) | h3 `0037822d` (4 peers, mp 1) | h3 `0037822d` (4 peers, mp 1) | h3 `0037822d` (4 peers, mp 1) |
| 5-final | h4 `00029eb6` (4 peers, mp 0) | h4 `00029eb6` (4 peers, mp 0) | h4 `00029eb6` (4 peers, mp 0) | h4 `00029eb6` (4 peers, mp 0) | h4 `00029eb6` (4 peers, mp 0) |
| 6-adversary | h4 `00029eb6` (4 peers, mp 0) | h4 `00029eb6` (4 peers, mp 0) | h4 `00029eb6` (4 peers, mp 0) | h4 `00029eb6` (4 peers, mp 0) | h4 `00029eb6` (4 peers, mp 0) |

![convergence](convergence.png)

* Full mesh by discovery (each node bootstrapped to one neighbour): 0.508 s.
* Transaction relay to all 5 mempools: 0.253 s; block relay to all: 0.205 s.
* During the partition side A mined `000acb558185` (Alice→Bob 85, Carol→Bob 20);
  side B mined `0080b6022aa2` (conflicting Alice→Erin 100) and then `0037822d4c22`.
* After healing, every honest node converged on the most-work chain in **0.254 s**;
  all honest nodes share tip `00029eb65a73a274…` (height 4) and UTXO hash `fde05780621dc062…`: **True**.
* Stale-block transactions reconsidered for the mempool:
  * node0: `6d84718ed49bda95` → **rejected** (double-spend: input 0 outpoint fbeb2bc33ed7…:1 already spent by 22223f1d33050968…)
  * node0: `b8f03b98d97e9fa2` → **accepted** (fee 1, 215 bytes, rate 0.0047)
  * node1: `6d84718ed49bda95` → **rejected** (double-spend: input 0 outpoint fbeb2bc33ed7…:1 already spent by 22223f1d33050968…)
  * node1: `b8f03b98d97e9fa2` → **accepted** (fee 1, 215 bytes, rate 0.0047)
* Carol→Bob was confirmed on every node after the next block: **True**;
  Alice→Bob (double-spent by Alice→Erin on the winning chain) dropped everywhere: **True**.
* Final balances: alice 7, bob 20, carol 34, dave 24, erin 100, miner0 0, miner1 51, miner2 104, miner3 0, miner4 50.

## Robustness against a misbehaving peer (attacking node2)
| attack | node behaviour |
|---|---|
| connect and send nothing | disconnected by handshake timeout after 2.15 s |
| bad checksum, invalid JSON, unknown type, wrong protocol version, schema violation | `error` replies ['bad-checksum', 'bad-json', 'unknown-type', 'unsupported-version', 'bad-schema'], message discarded, connection kept |
| invalid transaction, malformed block object | rejected, penalty points (score after all malformed input: 75) |
| duplicate `inv` of a known block | ignored, no `getdata` (duplicate suppression) |
| frame declaring length > 1 MiB | `error` ['too-large'] and disconnect: True |
| flood of pings | 100 messages dropped by the rate limiter, spammer banned: True |
| banned peer reconnects | ['closed'] |

Honest node3 → node2 ping RTT during the flood (ms): [100.33, 99.22, 91.9, 104.25, 100.12, 101.25] — node2 stayed responsive
(the RTT ≈ sum of the two one-way link latencies); honest peers still connected: ['node0', 'node1', 'node3', 'node4'].

## Traffic
Messages sent by all nodes: pong 271, addr 208, getaddr 145, ping 117, inv 76, version 36, verack 34, getdata 26, block 17, tx 11, error 7, getblocks 6.
Duplicate announcements/objects suppressed: 35. Log events: connect 36, phase 35, handshake 34, getdata 26, disconnect 20, block-connected 18, tx-accepted 15, addr 14, penalty 9, malformed 6, listen 5, mined 5, mempool-reconsider 4, block-side-branch 2.

## Structured logs
`docs/simulation_logs.jsonl` holds 237 JSON lines with `ts`, `node_id`, `peer_id`, `object_id`, `event` (+ details). Examples:
```
{"ts": 1795145529.1627, "node_id": "node4", "peer_id": null, "object_id": "7cbf85f4e5c2796f", "event": "tx-accepted", "reason": "fee 1, 215 bytes, rate 0.0047", "relayed_to": 4}
{"ts": 1795145529.2296, "node_id": "node1", "peer_id": "node4", "object_id": "7cbf85f4e5c2796f", "event": "getdata", "count": 1}
{"ts": 1795145529.2324, "node_id": "node2", "peer_id": "node4", "object_id": "7cbf85f4e5c2796f", "event": "getdata", "count": 1}
{"ts": 1795145529.2326, "node_id": "node3", "peer_id": "node4", "object_id": "7cbf85f4e5c2796f", "event": "getdata", "count": 1}
{"ts": 1795145529.2385, "node_id": "node0", "peer_id": "node4", "object_id": "7cbf85f4e5c2796f", "event": "getdata", "count": 1}
{"ts": 1795145529.3265, "node_id": "node1", "peer_id": "node4", "object_id": "7cbf85f4e5c2796f", "event": "tx-accepted", "reason": "fee 1, 215 bytes, rate 0.0047", "relayed_to": 3}
{"ts": 1795145529.3315, "node_id": "node0", "peer_id": "node4", "object_id": "7cbf85f4e5c2796f", "event": "tx-accepted", "reason": "fee 1, 215 bytes, rate 0.0047", "relayed_to": 3}
{"ts": 1795145529.3464, "node_id": "node2", "peer_id": "node4", "object_id": "7cbf85f4e5c2796f", "event": "tx-accepted", "reason": "fee 1, 215 bytes, rate 0.0047", "relayed_to": 2}
```
