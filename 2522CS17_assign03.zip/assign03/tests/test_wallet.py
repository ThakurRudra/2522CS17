"""Tests for toywallet (Assignment 3): keys, addresses, canonical transactions, rejections."""
import copy
import hashlib
import json
import os
import stat
import struct
import subprocess
import sys

import pytest
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature, encode_dss_signature

from toywallet import keys
from toywallet.address import (AddressError, B58_ALPHABET, address_from_pubkey, b58decode, b58encode,
                               decode_address, pubkey_hash)
from toywallet.transaction import (NonceStore, Transaction, TxError, memo_hash, sign_transaction,
                                   verify_signed)

HERE = os.path.dirname(__file__)
ROOT = os.path.abspath(os.path.join(HERE, ".."))
VEC = os.path.join(ROOT, "test_vectors")


# ------------------------------------------------------------------ fixtures
@pytest.fixture(scope="module")
def alice():
    k = keys.generate_private_key()
    return k, address_from_pubkey(keys.public_bytes(k.public_key()))


@pytest.fixture(scope="module")
def bob():
    k = keys.generate_private_key()
    return k, address_from_pubkey(keys.public_bytes(k.public_key()))


@pytest.fixture
def tx(alice, bob):
    return Transaction.from_dict({"version": 1, "network_id": "course-testnet", "sender": alice[1],
                                  "recipient": bob[1], "amount_units": 1250000, "nonce": 7,
                                  "memo_hash": memo_hash("test")})


@pytest.fixture
def signed(tx, alice):
    return sign_transaction(tx, alice[0])


def cli(*args, cwd=None):
    env = dict(os.environ, PYTHONPATH=os.path.join(ROOT, "src"))
    return subprocess.run([sys.executable, "-m", "toywallet", *args], capture_output=True, text=True,
                          env=env, cwd=cwd)


# ------------------------------------------------------------------ keys
def test_keys_are_random_and_in_range():
    a, b = keys.generate_private_key(), keys.generate_private_key()
    va, vb = (k.private_numbers().private_value for k in (a, b))
    assert va != vb and 1 <= va < keys.N and 1 <= vb < keys.N


def test_public_key_compressed_33_bytes(alice):
    pub = keys.public_bytes(alice[0].public_key())
    assert len(pub) == 33 and pub[0] in (2, 3)


def test_keygen_exports_public_only_by_default(tmp_path):
    r = cli("keygen", "--name", "carol", "--dir", str(tmp_path))
    assert r.returncode == 0
    assert sorted(os.listdir(tmp_path)) == ["carol.pub.json"]
    assert "private_key" not in (tmp_path / "carol.pub.json").read_text()


def test_private_file_mode_0600_and_warning(tmp_path):
    r = cli("keygen", "--name", "dev", "--dir", str(tmp_path), "--save-private")
    assert r.returncode == 0 and "TEST-ONLY" in r.stderr
    p = tmp_path / "dev.DEV-ONLY.key.json"
    assert stat.S_IMODE(os.stat(p).st_mode) == 0o600
    assert "TEST-ONLY DEVELOPMENT KEY" in json.loads(p.read_text())["WARNING"]
    keys.read_private_file(str(p))  # accepted


def test_private_file_with_open_permissions_refused(tmp_path, alice):
    p = tmp_path / "k.json"
    keys.write_private_file(str(p), alice[0], alice[1], "a")
    os.chmod(p, 0o644)
    with pytest.raises(keys.KeyError_, match="too open"):
        keys.read_private_file(str(p))


def test_keygen_refuses_mainnet(tmp_path):
    assert cli("keygen", "--name", "x", "--dir", str(tmp_path), "--network", "mainnet").returncode == 2


# ------------------------------------------------------------------ addresses
def test_address_structure(alice):
    pub = keys.public_bytes(alice[0].public_key())
    addr = address_from_pubkey(pub)
    raw = b58decode(addr)
    assert addr.startswith("t") and len(raw) == 25 and raw[0] == 0x7F
    assert raw[1:21] == pubkey_hash(pub) == hashlib.blake2b(pub, digest_size=20).digest()
    assert raw[21:] == hashlib.sha256(hashlib.sha256(raw[:21]).digest()).digest()[:4]
    assert decode_address(addr) == ("course-testnet", raw[:21])


def test_b58_roundtrip_leading_zeros():
    for data in (b"\x00", b"\x00\x00\x01", os.urandom(25)):
        assert b58decode(b58encode(data)) == data


@pytest.mark.parametrize("bad_char", ["0", "O", "I", "l", "+", " "])
def test_malformed_address_char(alice, bad_char):
    with pytest.raises(AddressError, match="malformed"):
        decode_address(alice[1][:-1] + bad_char)


def test_malformed_address_length(alice):
    with pytest.raises(AddressError, match="malformed"):
        decode_address(alice[1][:-3])


def test_invalid_checksum(alice):
    a = alice[1]
    last = a[-1]
    repl = B58_ALPHABET[(B58_ALPHABET.index(last) + 1) % 58]
    with pytest.raises(AddressError, match="checksum"):
        decode_address(a[:-1] + repl)


def test_unknown_version_byte():
    payload = bytes([0x55]) + b"\x11" * 20
    from toywallet.address import checksum
    with pytest.raises(AddressError, match="version"):
        decode_address(b58encode(payload + checksum(payload)))


# ------------------------------------------------------------------ canonical serialisation
def test_signing_bytes_layout(tx):
    b = tx.signing_bytes()
    assert len(b) == 97 + len("course-testnet") == 111
    assert b[:4] == b"CTX1" and struct.unpack(">H", b[4:6])[0] == 1 and b[6] == 14
    assert struct.unpack(">Q", b[63:71])[0] == 1250000 and struct.unpack(">Q", b[71:79])[0] == 7


def test_whitespace_and_key_order_same_bytes():
    a = Transaction.from_json(open(os.path.join(VEC, "tx_pretty.json")).read())
    b = Transaction.from_json(open(os.path.join(VEC, "tx_reordered_compact.json")).read())
    exp = json.load(open(os.path.join(VEC, "expected_signing_bytes.json")))
    assert a.signing_bytes() == b.signing_bytes()
    assert a.signing_bytes().hex() == exp["signing_bytes_hex"] and a.txid() == exp["txid"]


@pytest.mark.parametrize("field,value", [("amount_units", 1.5), ("amount_units", -1), ("amount_units", 0),
                                         ("amount_units", 2**64), ("nonce", True), ("version", 2),
                                         ("network_id", "Course Testnet"), ("memo_hash", "ab"),
                                         ("amount_units", "1250000")])
def test_bad_field_values_rejected(tx, field, value):
    d = tx.to_dict()
    d[field] = value
    with pytest.raises(TxError):
        Transaction.from_dict(d)


def test_extra_or_missing_field_rejected(tx):
    d = tx.to_dict(); d["fee"] = 1
    with pytest.raises(TxError, match="exactly"):
        Transaction.from_dict(d)
    d = tx.to_dict(); del d["nonce"]
    with pytest.raises(TxError, match="exactly"):
        Transaction.from_dict(d)


def test_float_in_json_text_rejected(tx):
    text = json.dumps(tx.to_dict()).replace("1250000", "1250000.0")
    with pytest.raises(TxError, match="non-integer"):
        Transaction.from_json(text)


# ------------------------------------------------------------------ sign / verify
def test_sign_and_verify(signed):
    assert verify_signed(signed).amount_units == 1250000


def test_signature_is_canonical_low_s(signed):
    r, s = keys.check_canonical_der(bytes.fromhex(signed["signature"]))
    assert s <= keys.HALF_N


@pytest.mark.parametrize("field,new", [("amount_units", 1250001), ("nonce", 8), ("memo_hash", "00" * 32),
                                       ("recipient", None)])
def test_changing_any_signed_field_fails(signed, alice, field, new):
    s = copy.deepcopy(signed)
    if field == "recipient":
        new = alice[1]  # still a valid address, but a different one
    s["tx"][field] = new
    with pytest.raises(TxError, match="does not verify"):
        verify_signed(s)


def test_changed_amount_fails(signed):
    s = copy.deepcopy(signed); s["tx"]["amount_units"] = 9_999_999
    with pytest.raises(TxError, match="does not verify"):
        verify_signed(s)


def test_wrong_network_rejected(signed):
    with pytest.raises(TxError, match="wrong network"):
        verify_signed(signed, expected_network="other-testnet")


def test_network_field_changed_rejected(signed):
    s = copy.deepcopy(signed); s["tx"]["network_id"] = "mainnet"
    with pytest.raises(TxError, match="belongs to network"):
        verify_signed(s, expected_network="mainnet")


def test_wrong_signer_pubkey_rejected(signed, bob):
    s = copy.deepcopy(signed)
    s["public_key"] = keys.public_bytes(bob[0].public_key()).hex()
    with pytest.raises(TxError, match="wrong signer"):
        verify_signed(s)


def test_signature_from_other_key_rejected(signed, tx, bob):
    s = copy.deepcopy(signed)
    s["signature"] = keys.sign(bob[0], tx.signing_bytes()).hex()  # bob signs alice's tx
    with pytest.raises(TxError, match="does not verify"):
        verify_signed(s)


def test_cannot_sign_for_someone_else(tx, bob):
    with pytest.raises(TxError, match="does not control"):
        sign_transaction(tx, bob[0])


def test_replayed_nonce_rejected(signed, tmp_path):
    store = NonceStore(str(tmp_path / "n.json"))
    verify_signed(signed, nonces=store)
    with pytest.raises(TxError, match="replayed"):
        verify_signed(signed, nonces=NonceStore(str(tmp_path / "n.json")))  # survives reload


def test_stale_lower_nonce_rejected(alice, bob, tmp_path):
    store = NonceStore()
    for n in (5, 3):
        t = Transaction.from_dict({"version": 1, "network_id": "course-testnet", "sender": alice[1],
                                   "recipient": bob[1], "amount_units": 1, "nonce": n, "memo_hash": "00" * 32})
        s = sign_transaction(t, alice[0])
        if n == 5:
            verify_signed(s, nonces=store)
        else:
            with pytest.raises(TxError, match="stale"):
                verify_signed(s, nonces=store)


def test_high_s_signature_rejected(signed):
    r, s = decode_dss_signature(bytes.fromhex(signed["signature"]))
    high = encode_dss_signature(r, keys.N - s)  # mathematically valid but malleated
    bad = copy.deepcopy(signed); bad["signature"] = high.hex()
    with pytest.raises(TxError, match="high-S"):
        verify_signed(bad)


def test_non_minimal_der_rejected(signed):
    sig = bytes.fromhex(signed["signature"])
    r, s = decode_dss_signature(sig)
    rb = b"\x00\x00" + r.to_bytes(32, "big")          # needless leading zero padding
    sb = s.to_bytes((s.bit_length() + 8) // 8, "big")
    body = b"\x02" + bytes([len(rb)]) + rb + b"\x02" + bytes([len(sb)]) + sb
    padded = b"\x30" + bytes([len(body)]) + body
    bad = copy.deepcopy(signed); bad["signature"] = padded.hex()
    with pytest.raises(TxError, match="DER"):
        verify_signed(bad)


def test_trailing_bytes_rejected(signed):
    bad = copy.deepcopy(signed); bad["signature"] += "00"
    with pytest.raises(TxError):
        verify_signed(bad)


def test_refuse_to_sign_mainnet(alice, bob):
    pub = keys.public_bytes(alice[0].public_key())
    t = Transaction.from_dict({"version": 1, "network_id": "mainnet",
                               "sender": address_from_pubkey(pub, "mainnet"),
                               "recipient": address_from_pubkey(keys.public_bytes(bob[0].public_key()), "mainnet"),
                               "amount_units": 1, "nonce": 0, "memo_hash": "00" * 32})
    with pytest.raises(TxError, match="mainnet"):
        sign_transaction(t, alice[0])


# ------------------------------------------------------------------ independent verification
def spec_signing_bytes(txd: dict) -> bytes:
    """Re-implementation of docs/transaction_format.md that does NOT use toywallet code."""
    def payload(addr):
        n = 0
        for c in addr:
            n = n * 58 + B58_ALPHABET.index(c)
        return n.to_bytes(25, "big")[:21]
    net = txd["network_id"].encode()
    return (b"CTX1" + txd["version"].to_bytes(2, "big") + bytes([len(net)]) + net + payload(txd["sender"])
            + payload(txd["recipient"]) + txd["amount_units"].to_bytes(8, "big")
            + txd["nonce"].to_bytes(8, "big") + bytes.fromhex(txd["memo_hash"]))


def test_instructor_vector_verifies_with_independent_library():
    ecdsa = pytest.importorskip("ecdsa")
    from ecdsa.util import sigdecode_der
    signed = json.load(open(os.path.join(VEC, "valid_signed_tx.json")))
    vk = ecdsa.VerifyingKey.from_string(bytes.fromhex(signed["public_key"]), curve=ecdsa.SECP256k1)
    msg = spec_signing_bytes(signed["tx"])
    assert vk.verify(bytes.fromhex(signed["signature"]), msg, hashfunc=hashlib.sha256, sigdecode=sigdecode_der)
    assert verify_signed(signed).sender == json.load(open(os.path.join(VEC, "alice.pub.json")))["address"]


def test_cli_end_to_end(tmp_path):
    assert cli("keygen", "--name", "a", "--save-private", cwd=tmp_path).returncode == 0
    assert cli("keygen", "--name", "b", cwd=tmp_path).returncode == 0
    bob_addr = json.loads((tmp_path / "b.pub.json").read_text())["address"]
    r = cli("newtx", "--from", "a.pub.json", "--to", bob_addr, "--amount", "5", "--nonce", "1", cwd=tmp_path)
    (tmp_path / "tx.json").write_text(r.stdout)
    assert cli("sign", "--key", "a.DEV-ONLY.key.json", "--tx", "tx.json", "--out", "s.json", cwd=tmp_path).returncode == 0
    assert cli("verify", "--signed", "s.json", "--nonce-db", "n.json", cwd=tmp_path).returncode == 0
    r = cli("verify", "--signed", "s.json", "--nonce-db", "n.json", cwd=tmp_path)
    assert r.returncode == 2 and "replayed" in r.stderr
