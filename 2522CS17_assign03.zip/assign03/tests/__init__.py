"""Tests for toywallet."""
