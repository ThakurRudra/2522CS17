# Byte-level transaction format (TX-1)

Student: Rudra Pratap Singh (2522CS17) · Assignment 3

This document is the complete specification an independent verifier needs. A verifier that
follows it can check `test_vectors/valid_signed_tx.json` with any secp256k1 library and without
using this repository's code (see `tests/test_wallet.py::test_instructor_vector_verifies_with_independent_library`,
which uses the separate `ecdsa` package).

## 1. Keys
* Curve: **secp256k1**. Private key: 32-byte scalar `k`, `1 ≤ k < n`, drawn from the OS CSPRNG
  (`secrets.token_bytes` → `os.urandom`) by rejection sampling.
* Public key: **33-byte SEC1 compressed point** `0x02|0x03 ‖ X` (hex in JSON).

## 2. Address
| step | bytes | definition |
|---|---|---|
| pubkey hash | 20 | `BLAKE2b-160(pubkey33)` (BLAKE2b with `digest_size=20`, no key, no salt) |
| payload | 21 | `version_byte ‖ pubkey_hash` |
| checksum | 4 | `SHA256(SHA256(payload))[0:4]` |
| address | 25 → text | Base58 (Bitcoin alphabet `123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz`) of `payload ‖ checksum`; each leading `0x00` byte becomes a leading `1` |

Version bytes: `0x7f` = `course-testnet` (addresses start with **t**); `0x00` = `mainnet`
(reserved; the wallet refuses to create keys or sign for it). Any other version is rejected.

## 3. Transaction JSON (input/transport form)
```json
{
  "version": 1,
  "network_id": "course-testnet",
  "sender": "<address>",
  "recipient": "<address>",
  "amount_units": 1250000,
  "nonce": 7,
  "memo_hash": "<64 lowercase hex = SHA256(UTF-8 memo)>"
}
```
Parsing rules: exactly these seven keys; integers only (no floats, booleans or strings for numbers);
`version = 1`; `network_id` matches `[a-z0-9-]{1,32}`; both addresses decode with a valid
checksum and their version byte must belong to `network_id`; `1 ≤ amount_units ≤ 2^64−1`;
`0 ≤ nonce ≤ 2^64−1`; `memo_hash` is 64 lowercase hex characters.
**JSON whitespace and key order are irrelevant**: the signature never covers JSON text.

## 4. Signing bytes (what is actually signed)
All integers are unsigned big-endian. `L = len(network_id)`.

| offset | size | field | encoding |
|---:|---:|---|---|
| 0 | 4 | magic | ASCII `CTX1` = `43 54 58 31` (domain separation: these bytes can never be confused with another message type) |
| 4 | 2 | version | uint16 (`00 01`) |
| 6 | 1 | network_id length | uint8 = L |
| 7 | L | network_id | ASCII |
| 7+L | 21 | sender | address payload (version byte ‖ 20-byte pubkey hash); checksum is not included |
| 28+L | 21 | recipient | address payload |
| 49+L | 8 | amount_units | uint64 |
| 57+L | 8 | nonce | uint64 |
| 65+L | 32 | memo_hash | raw 32 bytes |
| | **97+L** | total | **111 bytes** for `course-testnet` |

Example (`wallet inspect --tx test_vectors/valid_signed_tx.json` prints this table with real bytes):
```
   0   4  magic         43545831
   4   2  version       0001
   6   1  net_len       0e
   7  14  network_id    636f757273652d746573746e6574
  21  21  sender        7f ‖ 20-byte hash
  42  21  recipient     7f ‖ 20-byte hash
  63   8  amount_units  00000000001312d0          (1,250,000)
  71   8  nonce         0000000000000007
  79  32  memo_hash     ...
```

## 5. Signature and transaction id
* `signature = ECDSA_secp256k1(SHA-256(signing_bytes))`, encoded as **strict DER**
  (`30 len 02 len r 02 len s`, minimal-length positive integers, no trailing bytes).
* **Low-S rule:** `s ≤ n/2`. The signer normalises `s → n − s` when needed; the verifier rejects
  high-S signatures, non-minimal DER, extra bytes and `r`/`s` outside `[1, n−1]`, which removes
  signature malleability (a third party cannot create a second valid encoding).
* `txid = SHA-256(signing_bytes)` (hex).

## 6. Signed transaction envelope
```json
{"tx": { ...seven fields... }, "public_key": "<66 hex>", "signature": "<DER hex>"}
```
Exactly these three keys.

## 7. Verification algorithm (in order; first failure is the rejection reason)
1. Envelope keys exact; parse `tx` with the rules of §3 (malformed address / invalid checksum caught here).
2. `tx.network_id` must equal the verifier's network (wrong network).
3. `public_key` must be a valid compressed secp256k1 point.
4. `address(public_key, network_id)` must equal `tx.sender` (wrong signer).
5. Signature encoding must be canonical (§5), then must verify over the signing bytes (changed field ⇒ fails).
6. Replay protection: per sender, `nonce` must be strictly greater than the last accepted nonce
   (`--nonce-db` file); the accepted nonce is then recorded.
