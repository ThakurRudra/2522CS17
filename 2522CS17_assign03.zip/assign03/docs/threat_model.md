# Threat model — educational wallet (Assignment 3)

Student: Rudra Pratap Singh (2522CS17)

**Assets:** the private key (controls every coin at the address), the integrity of what the user
approves (recipient, amount, network), and the uniqueness of each signed transaction.
**Out of scope:** the toy chain's consensus, a compromised operating system kernel, hardware attacks.

| Threat | What can go wrong | Mitigation in this wallet | Residual risk / what a real wallet adds |
|---|---|---|---|
| **Key theft** | Anyone who reads the private key can sign any transaction; signatures cannot be revoked. | Private key is **not exported by default** (`keygen` writes only `*.pub.json`). With `--save-private` the file is created atomically with mode **0600** (`os.open(..., O_EXCL, 0o600)`), carries a conspicuous `TEST-ONLY DEVELOPMENT KEY` warning, and `sign` **refuses** a key file whose permissions are wider than 0600 or that lacks the warning. `*.DEV-ONLY.key.json` is in `.gitignore`; test vectors are signed with keys that are discarded immediately. | The file is still plaintext on disk. Real wallets encrypt keys with a passphrase (scrypt/Argon2 + AEAD), use OS keystores or hardware wallets/secure elements, and support multisig. |
| **Weak randomness** | A predictable or repeated scalar `k`, or a repeated ECDSA nonce, leaks the private key (e.g. the PlayStation 3 and 2013 Android `SecureRandom` incidents). | The private scalar comes from the **OS CSPRNG** (`secrets.token_bytes`) with rejection sampling for `1 ≤ k < n`; no custom RNG, no `random` module, no seeds. ECDSA signing (including its per-signature nonce) is done by OpenSSL via `cryptography`. | Virtual machines cloned from a snapshot can repeat RNG state; deterministic RFC 6979 nonces or hardware RNGs reduce this further. |
| **Replay** | A valid signed transaction is broadcast again, paying twice; or replayed on another network. | Every transaction has a **nonce**; the verifier stores the last accepted nonce per sender and rejects `nonce ≤ last` (tested, survives restart). Network replay is blocked because `network_id` is inside the signed bytes **and** the address version byte must match the network. The `CTX1` magic prevents a signature from being reused as a signature over a different message type. | A verifier with an empty nonce store would accept an old transaction; on a real chain the nonce/UTXO rule is enforced by consensus (Assignment 4 uses UTXOs). |
| **Clipboard replacement** | Malware swaps a copied address for the attacker's look-alike address. | Base58Check makes **typos and random corruption** detectable (4-byte checksum, 1 in 4.3 billion); the CLI echoes sender → recipient → amount before/after signing so the user can compare. | A malicious substitute is a *valid* address, so a checksum cannot catch it. Users must compare several characters at start **and** end, use address books, or confirm on a separate trusted display (hardware wallet). |
| **Phishing** | A fake website or message tricks the user into signing a transaction they did not intend, or into revealing the key. | The wallet signs only the fixed, human-readable transaction structure (no blind signing of arbitrary bytes); `inspect` shows every signed byte; the key never needs to be pasted anywhere because signing happens locally. | Social engineering cannot be solved in code: never share the key file, verify the domain, prefer hardware confirmation. |
| **Accidental mainnet use** | A test key or test transaction is used where real value exists. | Separate version bytes (`t…` addresses for course-testnet); `keygen --network mainnet` and signing a `mainnet` transaction are **refused**; the verifier rejects any transaction whose `network_id` differs from its own; every dev key file says TEST-ONLY. | A user could still copy the scalar into another wallet — the warning text is the only control there. |

## Additional checks that close related attacks
* **Signature malleability:** high-S and non-minimal DER signatures are rejected, so the same
  transaction cannot appear with two different valid signatures.
* **Ambiguous serialisation:** the signature covers a fixed binary layout, not JSON text; floats,
  booleans-as-integers, extra or missing fields are rejected, so two different-looking documents
  cannot mean different things under the same signature.
* **Wrong signer:** the public key must hash to the sender address before the signature is checked.
