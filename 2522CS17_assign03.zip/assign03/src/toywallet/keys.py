"""Key generation, key files, ECDSA/secp256k1 signing and strict signature checks.

All elliptic-curve arithmetic is done by the maintained `cryptography` library (OpenSSL).
The 32-byte private scalar comes from the operating system CSPRNG (`secrets` -> os.urandom).
We never implement curve arithmetic or a random-number generator ourselves.
"""
from __future__ import annotations

import json
import os
import secrets
import stat
from dataclasses import dataclass

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import (decode_dss_signature,
                                                             encode_dss_signature)

CURVE = ec.SECP256K1()
# group order n of secp256k1 (public constant, used only for range checks and low-S rule)
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
HALF_N = N // 2

DEV_WARNING = ("TEST-ONLY DEVELOPMENT KEY. Never use on mainnet, never fund it with real value, "
               "never reuse it outside the Blockchain course test network.")


class KeyError_(ValueError):
    pass


class SignatureError(ValueError):
    pass


def generate_private_key() -> ec.EllipticCurvePrivateKey:
    """Draw a uniform scalar 1 <= k < n from the OS CSPRNG (rejection sampling)."""
    while True:
        k = int.from_bytes(secrets.token_bytes(32), "big")
        if 1 <= k < N:
            return ec.derive_private_key(k, CURVE)


def public_bytes(pub: ec.EllipticCurvePublicKey) -> bytes:
    """33-byte SEC1 compressed public key (0x02/0x03 || X)."""
    return pub.public_bytes(serialization.Encoding.X962, serialization.PublicFormat.CompressedPoint)


def load_public(data: bytes) -> ec.EllipticCurvePublicKey:
    if len(data) != 33 or data[0] not in (2, 3):
        raise KeyError_("public key must be 33-byte SEC1 compressed (02/03 prefix)")
    try:
        return ec.EllipticCurvePublicKey.from_encoded_point(CURVE, data)
    except ValueError:
        raise KeyError_("public key is not a valid secp256k1 point") from None


def private_scalar_hex(priv: ec.EllipticCurvePrivateKey) -> str:
    return priv.private_numbers().private_value.to_bytes(32, "big").hex()


def private_from_hex(h: str) -> ec.EllipticCurvePrivateKey:
    k = int(h, 16)
    if not 1 <= k < N:
        raise KeyError_("private scalar out of range")
    return ec.derive_private_key(k, CURVE)


# ------------------------------------------------------------------ key files
def write_public_file(path: str, pub_hex: str, address: str, name: str) -> None:
    with open(path, "w") as fh:
        json.dump({"name": name, "curve": "secp256k1", "public_key": pub_hex, "address": address},
                  fh, indent=2)
        fh.write("\n")


def write_private_file(path: str, priv: ec.EllipticCurvePrivateKey, address: str, name: str) -> None:
    """Create the file with mode 0600 from the start (no window where it is world-readable)."""
    payload = {"WARNING": DEV_WARNING, "name": name, "curve": "secp256k1",
               "private_key": private_scalar_hex(priv), "address": address}
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, "w") as fh:
        json.dump(payload, fh, indent=2)
        fh.write("\n")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def read_private_file(path: str, enforce_permissions: bool = True) -> ec.EllipticCurvePrivateKey:
    if enforce_permissions and os.name == "posix":
        mode = stat.S_IMODE(os.stat(path).st_mode)
        if mode & 0o077:
            raise KeyError_(f"refusing to use {path}: permissions {oct(mode)} are too open (need 0600)")
    with open(path) as fh:
        data = json.load(fh)
    if "WARNING" not in data:
        raise KeyError_("private key file lacks the test-only warning; refusing")
    return private_from_hex(data["private_key"])


# ------------------------------------------------------------------ signatures
def sign(priv: ec.EllipticCurvePrivateKey, message: bytes) -> bytes:
    """ECDSA-SHA256 over `message`; output strict DER with low-S (BIP-62 style)."""
    der = priv.sign(message, ec.ECDSA(hashes.SHA256()))
    r, s = decode_dss_signature(der)
    if s > HALF_N:
        s = N - s
    return encode_dss_signature(r, s)


def check_canonical_der(sig: bytes) -> tuple[int, int]:
    """Reject non-canonical encodings: non-DER, non-minimal integers, trailing bytes, high S."""
    if not 8 <= len(sig) <= 72:
        raise SignatureError("signature length outside DER bounds")
    try:
        r, s = decode_dss_signature(sig)
    except ValueError:
        raise SignatureError("signature is not valid DER") from None
    if encode_dss_signature(r, s) != sig:
        raise SignatureError("non-canonical DER encoding (padding, length or trailing bytes)")
    if not (1 <= r < N and 1 <= s < N):
        raise SignatureError("signature integers out of range")
    if s > HALF_N:
        raise SignatureError("non-canonical signature: high-S value (malleable)")
    return r, s


def verify(pub: ec.EllipticCurvePublicKey, message: bytes, sig: bytes) -> None:
    check_canonical_der(sig)
    try:
        pub.verify(sig, message, ec.ECDSA(hashes.SHA256()))
    except InvalidSignature:
        raise SignatureError("signature does not verify for this public key and message") from None


@dataclass
class KeyPair:
    private: ec.EllipticCurvePrivateKey

    @property
    def public(self) -> bytes:
        return public_bytes(self.private.public_key())
