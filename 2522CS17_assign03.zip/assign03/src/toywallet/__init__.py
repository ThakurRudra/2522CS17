"""toywallet - keys, addresses and signed transactions for a toy chain (Assignment 3)."""
__version__ = "1.0.0"
