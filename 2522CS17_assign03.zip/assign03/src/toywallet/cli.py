"""`wallet` CLI - keygen, address, sign, verify (+ newtx, inspect).

  wallet keygen --name alice                      # writes alice.pub.json only
  wallet keygen --name alice --save-private       # also alice.DEV-ONLY.key.json (mode 0600)
  wallet address --pubkey alice.pub.json          # or --pubkey-hex 02ab...
  wallet newtx --from alice.pub.json --to <addr> --amount 1250000 --nonce 7 --memo "lunch" > tx.json
  wallet sign --key alice.DEV-ONLY.key.json --tx tx.json --out signed.json
  wallet verify --signed signed.json [--network course-testnet] [--nonce-db nonces.json]
  wallet inspect --tx tx.json                     # byte-level dump of the signed bytes
"""
from __future__ import annotations

import argparse
import json
import os
import sys

from . import keys
from .address import DEFAULT_NETWORK, NETWORKS, AddressError, address_from_pubkey, decode_address
from .transaction import NonceStore, Transaction, TxError, memo_hash, sign_transaction, verify_signed


def cmd_keygen(a):
    if a.network == "mainnet":
        raise TxError("refusing to create mainnet keys with a course wallet")
    priv = keys.generate_private_key()
    pub = keys.public_bytes(priv.public_key())
    addr = address_from_pubkey(pub, a.network)
    os.makedirs(a.dir, exist_ok=True)
    pub_path = os.path.join(a.dir, f"{a.name}.pub.json")
    keys.write_public_file(pub_path, pub.hex(), addr, a.name)
    print(f"public key : {pub.hex()}\naddress    : {addr}\nwritten    : {pub_path}")
    if a.save_private:
        path = os.path.join(a.dir, f"{a.name}.DEV-ONLY.key.json")
        keys.write_private_file(path, priv, addr, a.name)
        print(f"private key: {path}  (mode 0600)")
        print(f"!!! {keys.DEV_WARNING}", file=sys.stderr)
    else:
        print("private key: NOT exported (use --save-private for a test-only development key file)")
    return 0


def _load_pub(path_or_none, hex_or_none) -> bytes:
    if hex_or_none:
        return bytes.fromhex(hex_or_none)
    with open(path_or_none) as fh:
        return bytes.fromhex(json.load(fh)["public_key"])


def cmd_address(a):
    pub = _load_pub(a.pubkey, a.pubkey_hex)
    keys.load_public(pub)  # validates the point
    print(address_from_pubkey(pub, a.network))
    return 0


def cmd_check_address(a):
    net, payload = decode_address(a.address)
    print(f"valid {net} address; version=0x{payload[0]:02x} pubkey_hash={payload[1:].hex()}")
    return 0


def cmd_newtx(a):
    sender = a.sender
    if a.from_pub:
        with open(a.from_pub) as fh:
            sender = json.load(fh)["address"]
    tx = Transaction.from_dict({"version": 1, "network_id": a.network, "sender": sender,
                                "recipient": a.to, "amount_units": a.amount, "nonce": a.nonce,
                                "memo_hash": memo_hash(a.memo)})
    print(json.dumps(tx.to_dict(), indent=2))
    return 0


def cmd_sign(a):
    priv = keys.read_private_file(a.key)
    with open(a.tx) as fh:
        tx = Transaction.from_json(fh.read())
    signed = sign_transaction(tx, priv)
    text = json.dumps(signed, indent=2)
    if a.out:
        with open(a.out, "w") as fh:
            fh.write(text + "\n")
        print(f"signed txid {tx.txid()} -> {a.out}")
    else:
        print(text)
    return 0


def cmd_verify(a):
    with open(a.signed) as fh:
        try:
            signed = json.load(fh)
        except json.JSONDecodeError as exc:
            raise TxError(f"invalid JSON: {exc}") from None
    store = NonceStore(a.nonce_db) if a.nonce_db else None
    tx = verify_signed(signed, a.network, store)
    print(f"VALID  txid={tx.txid()}  {tx.sender} -> {tx.recipient}  amount_units={tx.amount_units}  nonce={tx.nonce}")
    return 0


def cmd_inspect(a):
    with open(a.tx) as fh:
        obj = json.load(fh)
    tx = Transaction.from_dict(obj.get("tx", obj))
    b = tx.signing_bytes()
    L = len(tx.network_id)
    layout = [("magic", 0, 4), ("version", 4, 2), ("net_len", 6, 1), ("network_id", 7, L),
              ("sender", 7 + L, 21), ("recipient", 28 + L, 21), ("amount_units", 49 + L, 8),
              ("nonce", 57 + L, 8), ("memo_hash", 65 + L, 32)]
    for name, off, size in layout:
        print(f"{off:4d} {size:3d}  {name:13s} {b[off:off + size].hex()}")
    print(f"total {len(b)} bytes\nsigning_bytes {b.hex()}\ntxid {tx.txid()}")
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="wallet", description="Educational secp256k1 wallet for a toy chain")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("keygen"); s.add_argument("--name", required=True); s.add_argument("--dir", default=".")
    s.add_argument("--network", default=DEFAULT_NETWORK, choices=sorted(NETWORKS))
    s.add_argument("--save-private", action="store_true"); s.set_defaults(func=cmd_keygen)
    s = sub.add_parser("address"); g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--pubkey"); g.add_argument("--pubkey-hex")
    s.add_argument("--network", default=DEFAULT_NETWORK, choices=sorted(NETWORKS)); s.set_defaults(func=cmd_address)
    s = sub.add_parser("check-address"); s.add_argument("address"); s.set_defaults(func=cmd_check_address)
    s = sub.add_parser("newtx"); g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--from", dest="from_pub"); g.add_argument("--sender")
    s.add_argument("--to", required=True); s.add_argument("--amount", type=int, required=True)
    s.add_argument("--nonce", type=int, required=True); s.add_argument("--memo", default="")
    s.add_argument("--network", default=DEFAULT_NETWORK); s.set_defaults(func=cmd_newtx)
    s = sub.add_parser("sign"); s.add_argument("--key", required=True); s.add_argument("--tx", required=True)
    s.add_argument("--out"); s.set_defaults(func=cmd_sign)
    s = sub.add_parser("verify"); s.add_argument("--signed", required=True)
    s.add_argument("--network", default=DEFAULT_NETWORK); s.add_argument("--nonce-db")
    s.set_defaults(func=cmd_verify)
    s = sub.add_parser("inspect"); s.add_argument("--tx", required=True); s.set_defaults(func=cmd_inspect)
    return p


def main(argv=None):
    a = build_parser().parse_args(argv)
    try:
        return a.func(a)
    except (TxError, AddressError, keys.KeyError_, keys.SignatureError, OSError, ValueError, KeyError) as exc:
        print(f"REJECTED: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
