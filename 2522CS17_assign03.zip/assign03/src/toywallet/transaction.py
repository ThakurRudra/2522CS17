"""Canonical transaction format (TX-1), signing and verification.

The signed bytes are a fixed binary layout built from the parsed fields, NOT the JSON text.
Two JSON documents that differ only in whitespace or key order therefore produce identical
signed bytes. Byte layout (all integers big-endian) - see docs/transaction_format.md:

    off  size  field
    0     4    magic           "CTX1" (0x43 0x54 0x58 0x31)  domain separation for signatures
    4     2    version         uint16, must be 1
    6     1    len(network_id) uint8, 1..32
    7     L    network_id      ASCII [a-z0-9-]
    7+L   21   sender          address payload: version byte || 20-byte pubkey hash
    28+L  21   recipient       address payload
    49+L  8    amount_units    uint64, smallest unit, 1 .. 2^64-1
    57+L  8    nonce           uint64
    65+L  32   memo_hash       32 bytes (SHA-256 of the memo, or 32 zero bytes)
    total = 97 + L bytes   (111 bytes for "course-testnet")

signature = ECDSA-secp256k1-SHA256(signing_bytes), strict DER, low-S
txid      = SHA256(signing_bytes)
"""
from __future__ import annotations

import hashlib
import json
import re
import struct
from dataclasses import dataclass

from . import keys
from .address import AddressError, address_from_pubkey, decode_address

MAGIC = b"CTX1"
TX_FIELDS = ("version", "network_id", "sender", "recipient", "amount_units", "nonce", "memo_hash")
SIGNED_FIELDS = {"tx", "public_key", "signature"}
_NET_RE = re.compile(r"\A[a-z0-9-]{1,32}\Z")
_HEX64 = re.compile(r"\A[0-9a-f]{64}\Z")
_HEX = re.compile(r"\A(?:[0-9a-f]{2})+\Z")
U64_MAX = 2**64 - 1


class TxError(ValueError):
    """Any rejection; the message is the precise reason."""


def _no_float(s: str):
    raise TxError(f"non-integer number {s!r} not allowed")


def memo_hash(memo: str) -> str:
    return hashlib.sha256(memo.encode("utf-8")).hexdigest()


def _int_field(tx: dict, name: str, lo: int, hi: int) -> int:
    v = tx[name]
    if not isinstance(v, int) or isinstance(v, bool):
        raise TxError(f"{name} must be an integer (got {type(v).__name__})")
    if not lo <= v <= hi:
        raise TxError(f"{name}={v} outside range {lo}..{hi}")
    return v


@dataclass(frozen=True)
class Transaction:
    version: int
    network_id: str
    sender: str
    recipient: str
    amount_units: int
    nonce: int
    memo_hash: str

    @staticmethod
    def from_dict(tx: dict) -> "Transaction":
        if not isinstance(tx, dict):
            raise TxError("transaction must be a JSON object")
        if set(tx) != set(TX_FIELDS):
            raise TxError(f"transaction fields must be exactly {list(TX_FIELDS)}; "
                          f"missing={sorted(set(TX_FIELDS) - set(tx))} extra={sorted(set(tx) - set(TX_FIELDS))}")
        version = _int_field(tx, "version", 1, 1)
        net = tx["network_id"]
        if not isinstance(net, str) or not _NET_RE.match(net):
            raise TxError("network_id must match [a-z0-9-]{1,32}")
        for f in ("sender", "recipient"):
            try:
                addr_net, _ = decode_address(tx[f])
            except AddressError as exc:
                raise TxError(f"{f}: {exc}") from None
            if addr_net != net:
                raise TxError(f"{f} address belongs to network {addr_net!r}, transaction says {net!r}")
        amount = _int_field(tx, "amount_units", 1, U64_MAX)
        nonce = _int_field(tx, "nonce", 0, U64_MAX)
        mh = tx["memo_hash"]
        if not isinstance(mh, str) or not _HEX64.match(mh):
            raise TxError("memo_hash must be 64 lowercase hex characters")
        return Transaction(version, net, tx["sender"], tx["recipient"], amount, nonce, mh)

    @staticmethod
    def from_json(text: str) -> "Transaction":
        try:
            obj = json.loads(text, parse_float=_no_float, parse_constant=_no_float)
        except json.JSONDecodeError as exc:
            raise TxError(f"invalid JSON: {exc}") from None
        return Transaction.from_dict(obj)

    def to_dict(self) -> dict:
        return {f: getattr(self, f) for f in TX_FIELDS}

    def signing_bytes(self) -> bytes:
        net = self.network_id.encode("ascii")
        _, s_payload = decode_address(self.sender)
        _, r_payload = decode_address(self.recipient)
        return b"".join([
            MAGIC, struct.pack(">H", self.version), struct.pack(">B", len(net)), net,
            s_payload, r_payload, struct.pack(">Q", self.amount_units), struct.pack(">Q", self.nonce),
            bytes.fromhex(self.memo_hash)])

    def txid(self) -> str:
        return hashlib.sha256(self.signing_bytes()).hexdigest()


def sign_transaction(tx: Transaction, priv, allow_mainnet: bool = False) -> dict:
    if tx.network_id == "mainnet" and not allow_mainnet:
        raise TxError("refusing to sign a mainnet transaction with a course wallet (accidental mainnet use)")
    pub = keys.public_bytes(priv.public_key())
    if address_from_pubkey(pub, tx.network_id) != tx.sender:
        raise TxError("this key does not control the sender address")
    sig = keys.sign(priv, tx.signing_bytes())
    return {"tx": tx.to_dict(), "public_key": pub.hex(), "signature": sig.hex()}


class NonceStore:
    """Replay protection: per sender, a nonce must be strictly greater than the last accepted one."""

    def __init__(self, path: str | None = None):
        self.path = path
        self.last: dict[str, int] = {}
        if path:
            try:
                with open(path) as fh:
                    self.last = json.load(fh)
            except FileNotFoundError:
                pass

    def check(self, sender: str, nonce: int) -> None:
        if sender in self.last and nonce <= self.last[sender]:
            raise TxError(f"replayed or stale nonce {nonce} (last accepted for sender: {self.last[sender]})")

    def accept(self, sender: str, nonce: int) -> None:
        self.last[sender] = nonce
        if self.path:
            with open(self.path, "w") as fh:
                json.dump(self.last, fh, indent=2)


def verify_signed(signed: dict, expected_network: str = "course-testnet",
                  nonces: NonceStore | None = None) -> Transaction:
    """Full independent verification. Returns the transaction or raises TxError(reason)."""
    if not isinstance(signed, dict) or set(signed) != SIGNED_FIELDS:
        raise TxError(f"signed transaction must have exactly {sorted(SIGNED_FIELDS)}")
    tx = Transaction.from_dict(signed["tx"])
    if tx.network_id != expected_network:
        raise TxError(f"wrong network: transaction is for {tx.network_id!r}, verifier expects {expected_network!r}")
    pk_hex, sig_hex = signed["public_key"], signed["signature"]
    if not isinstance(pk_hex, str) or not _HEX.match(pk_hex) or not isinstance(sig_hex, str) or not _HEX.match(sig_hex):
        raise TxError("public_key and signature must be lowercase hex")
    pub_raw = bytes.fromhex(pk_hex)
    try:
        pub = keys.load_public(pub_raw)
    except keys.KeyError_ as exc:
        raise TxError(str(exc)) from None
    if address_from_pubkey(pub_raw, tx.network_id) != tx.sender:
        raise TxError("wrong signer: public key does not hash to the sender address")
    try:
        keys.verify(pub, tx.signing_bytes(), bytes.fromhex(sig_hex))
    except keys.SignatureError as exc:
        raise TxError(str(exc)) from None
    if nonces is not None:
        nonces.check(tx.sender, tx.nonce)
        nonces.accept(tx.sender, tx.nonce)
    return tx
