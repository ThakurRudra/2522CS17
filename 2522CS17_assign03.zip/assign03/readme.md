# Assignment 3 — Keys, Addresses, and Signed Transactions (`wallet`)

**Student:** Rudra Pratap Singh · **Roll:** 2522CS17 · **Course:** Blockchain (Dr. Mayank Agarwal), IIT Patna

An educational wallet for a toy chain. secp256k1 ECDSA comes from the maintained `cryptography`
library; the private scalar comes from the OS CSPRNG. No curve arithmetic or RNG is implemented here.

## How to run
```bash
cd assign03
pip install -e .                 # installs the `wallet` command (depends on cryptography)
pip install -r requirements.txt  # pytest + ecdsa (independent cross-check)
pytest -v                        # 50 tests
```
Colab: `notebook/Assignment03_wallet_Colab.ipynb` → Run all.

## Commands
```bash
wallet keygen --name alice                    # alice.pub.json only (public key + address)
wallet keygen --name alice --save-private     # + alice.DEV-ONLY.key.json, mode 0600, TEST-ONLY warning
wallet address --pubkey alice.pub.json        # derive the Base58Check address
wallet check-address tXXXX...                 # decode/validate an address
wallet newtx --from alice.pub.json --to <bob-address> --amount 1250000 --nonce 7 --memo "lunch" > tx.json
wallet sign --key alice.DEV-ONLY.key.json --tx tx.json --out signed.json
wallet verify --signed signed.json --network course-testnet --nonce-db nonces.json
wallet inspect --tx signed.json               # byte-level dump of the signed bytes
```
Exit code 0 = OK, 2 = rejected (reason printed after `REJECTED:`).

## Design summary
* **Address:** `Base58Check(0x7f ‖ BLAKE2b-160(compressed pubkey))`, checksum = first 4 bytes of double SHA-256. Testnet addresses start with `t`.
* **Canonical transaction:** fixed 111-byte binary layout (`CTX1` magic, version, network id, sender, recipient, amount, nonce, memo hash) — JSON whitespace/key order cannot change the signed bytes.
* **Signature:** ECDSA-SHA256, strict DER, low-S enforced.
* **Rejections:** changed amount (or any field), wrong network, wrong signer, replayed/stale nonce, malformed address, invalid checksum, non-canonical signature (high-S, padded DER, trailing bytes), floats, extra fields, mainnet signing.

## Deliverables
* Source: `src/toywallet/` (`keys.py`, `address.py`, `transaction.py`, `cli.py`)
* Tests: `tests/test_wallet.py` (includes verification of the vector with the independent `ecdsa` library)
* Byte-level format: `docs/transaction_format.md` · Threat model: `docs/threat_model.md`
* Public test vectors for the instructor: `test_vectors/valid_signed_tx.json`, `alice.pub.json`, `bob.pub.json`, `tx_pretty.json` and `tx_reordered_compact.json` (same transaction, different whitespace/key order), `expected_signing_bytes.json`. Regenerate with `python scripts/make_test_vectors.py` (private keys are discarded).

**Instructor verification:** `wallet verify --signed test_vectors/valid_signed_tx.json` → `VALID`.

Video demo: *(add the unlisted YouTube link here)*
