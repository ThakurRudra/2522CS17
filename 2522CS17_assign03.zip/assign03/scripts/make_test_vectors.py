"""Create the public test vectors in test_vectors/ (run from assign03/).

Keys are generated in memory from OS randomness; the private keys are used once to sign and
are then discarded, so no private key is ever committed to the repository.
"""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from toywallet import keys  # noqa: E402
from toywallet.address import address_from_pubkey  # noqa: E402
from toywallet.transaction import Transaction, memo_hash, sign_transaction  # noqa: E402

os.makedirs("test_vectors", exist_ok=True)
people = {}
for name in ("alice", "bob"):
    priv = keys.generate_private_key()
    pub = keys.public_bytes(priv.public_key())
    addr = address_from_pubkey(pub)
    keys.write_public_file(f"test_vectors/{name}.pub.json", pub.hex(), addr, name)
    people[name] = (priv, addr)

tx = Transaction.from_dict({"version": 1, "network_id": "course-testnet",
                            "sender": people["alice"][1], "recipient": people["bob"][1],
                            "amount_units": 1250000, "nonce": 7, "memo_hash": memo_hash("course demo payment")})
signed = sign_transaction(tx, people["alice"][0])
with open("test_vectors/valid_signed_tx.json", "w") as fh:
    json.dump(signed, fh, indent=2); fh.write("\n")

d = tx.to_dict()
with open("test_vectors/tx_pretty.json", "w") as fh:                 # spec key order, indented
    json.dump(d, fh, indent=4); fh.write("\n")
with open("test_vectors/tx_reordered_compact.json", "w") as fh:      # reversed keys, no spaces
    fh.write(json.dumps(dict(reversed(list(d.items()))), separators=(",", ":")))
with open("test_vectors/expected_signing_bytes.json", "w") as fh:
    json.dump({"signing_bytes_hex": tx.signing_bytes().hex(), "length": len(tx.signing_bytes()),
               "txid": tx.txid()}, fh, indent=2); fh.write("\n")
print("alice", people["alice"][1], "\nbob  ", people["bob"][1], "\ntxid ", tx.txid())
