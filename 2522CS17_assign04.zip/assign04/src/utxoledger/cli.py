"""`utxo` CLI.

  utxo trace                                 run the Alice/Bob scenario, write docs/transaction_trace.md + snapshots
  utxo init --ledger L.json --wallets w/     genesis: alice 40+70, carol 50 (dev keys in w/, mode 0600)
  utxo pay  --ledger L.json --wallets w/ --from alice --to bob --amount 85 --fee 2 [--out tx.json]
  utxo submit --ledger L.json --tx tx.json   validate + apply atomically, save the ledger
  utxo show --ledger L.json --wallets w/     balances and UTXOs
"""
from __future__ import annotations

import argparse
import json
import os
import sys

from . import keys
from .address import address_from_pubkey
from .ledger import Ledger, Rejected
from .trace import run_scenario
from .tx import Transaction, TxFormatError, TxOut
from .wallet import InsufficientFunds, Wallet


def _wallet(dirpath, name, create=False) -> Wallet:
    path = os.path.join(dirpath, f"{name}.DEV-ONLY.key.json")
    if create and not os.path.exists(path):
        w = Wallet.generate(name)
        keys.write_private_file(path, w.private, address_from_pubkey(w.pubkey), name)
        return w
    return Wallet(name, keys.read_private_file(path))


def cmd_trace(a):
    tr = run_scenario(a.outdir, a.snapdir)
    for i, t in enumerate(tr, 1):
        print(f"{i:2d}. {t['result']:9s} {t.get('code', ''):17s} {t['step']}")
    print(f"\nwritten: {a.outdir}/transaction_trace.md, {a.outdir}/trace.jsonl, {a.snapdir}/ledger_*.json")
    return 0


def cmd_init(a):
    os.makedirs(a.wallets, exist_ok=True)
    al, _, ca = (_wallet(a.wallets, n, create=True) for n in ("alice", "bob", "carol"))
    L = Ledger()
    L.add_genesis([TxOut(40, al.pkh), TxOut(70, al.pkh), TxOut(50, ca.pkh)])
    L.save(a.ledger)
    print(f"genesis written to {a.ledger}; wallets in {a.wallets}/ (TEST-ONLY keys)")
    return 0


def cmd_pay(a):
    L = Ledger.load(a.ledger)
    src, dst = _wallet(a.wallets, a.sender), _wallet(a.wallets, a.to)
    tx = src.build_payment(L, dst.pkh, a.amount, a.fee)
    text = json.dumps(tx.to_dict(), indent=2)
    if a.out:
        open(a.out, "w").write(text + "\n")
        print(f"built txid {tx.txid} ({len(tx.inputs)} inputs, {len(tx.outputs)} outputs) -> {a.out}")
    else:
        print(text)
    return 0


def cmd_submit(a):
    L = Ledger.load(a.ledger)
    tx = Transaction.from_dict(json.load(open(a.tx)))
    rc = L.apply(tx)
    L.save(a.ledger)
    print(f"ACCEPTED txid={rc.txid} inputs={rc.inputs_total} outputs={rc.outputs_total} fee={rc.fee}")
    return 0


def cmd_show(a):
    L = Ledger.load(a.ledger)
    names = {}
    if a.wallets and os.path.isdir(a.wallets):
        for f in sorted(os.listdir(a.wallets)):
            if f.endswith(".DEV-ONLY.key.json"):
                w = _wallet(a.wallets, f.split(".")[0])
                names[w.pkh] = w.name
    for op, o in sorted(L.utxos.items()):
        print(f"{op.txid[:16]}…:{op.vout}  {o.value:>6}  {names.get(o.pkh, o.pkh[:12])}")
    for pkh, n in names.items():
        print(f"balance {n:6s} {L.balance(pkh)}")
    print(f"total {L.total()}  state_hash {L.state_hash()}")
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="utxo", description="UTXO ledger and transaction validator")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("trace"); s.add_argument("--outdir", default="docs"); s.add_argument("--snapdir", default="test_vectors")
    s.set_defaults(func=cmd_trace)
    s = sub.add_parser("init"); s.add_argument("--ledger", required=True); s.add_argument("--wallets", default="wallets")
    s.set_defaults(func=cmd_init)
    s = sub.add_parser("pay"); s.add_argument("--ledger", required=True); s.add_argument("--wallets", default="wallets")
    s.add_argument("--from", dest="sender", required=True); s.add_argument("--to", required=True)
    s.add_argument("--amount", type=int, required=True); s.add_argument("--fee", type=int, default=0)
    s.add_argument("--out"); s.set_defaults(func=cmd_pay)
    s = sub.add_parser("submit"); s.add_argument("--ledger", required=True); s.add_argument("--tx", required=True)
    s.set_defaults(func=cmd_submit)
    s = sub.add_parser("show"); s.add_argument("--ledger", required=True); s.add_argument("--wallets", default="wallets")
    s.set_defaults(func=cmd_show)
    return p


def main(argv=None):
    a = build_parser().parse_args(argv)
    try:
        return a.func(a)
    except Rejected as r:
        print(f"REJECTED {r.code}: {r.message}", file=sys.stderr)
        return 1
    except (TxFormatError, InsufficientFunds, keys.KeyError_, OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
