"""In-memory UTXO ledger with an all-or-nothing validator.

`Ledger.apply(tx)` validates EVERY rule first and only then mutates state, so a rejected
transaction leaves the UTXO set byte-for-byte unchanged. Rejections raise `Rejected` whose
`code` is a stable machine-readable reason and whose message is human-readable.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass

from . import keys
from .address import pubkey_hash
from .tx import MAX_VALUE, OutPoint, Transaction, TxFormatError, TxIn, TxOut


class Rejected(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code, self.message = code, message


@dataclass
class Receipt:
    txid: str
    fee: int
    inputs_total: int
    outputs_total: int


class Ledger:
    def __init__(self):
        self.utxos: dict[OutPoint, TxOut] = {}
        self.spent_by: dict[OutPoint, str] = {}  # history, for precise double-spend messages
        self.applied: set[str] = set()

    # ------------------------------------------------------------ genesis
    def add_genesis(self, outputs: list[TxOut], tag: str = "genesis") -> str:
        """Create coins out of nothing (only for initial balances in this toy ledger)."""
        txid = hashlib.sha256(b"GENESIS|" + tag.encode() + json.dumps(
            [o.to_dict() for o in outputs], sort_keys=True).encode()).hexdigest()
        if txid in self.applied:
            raise Rejected("duplicate-tx", f"genesis {tag} already applied")
        for i, o in enumerate(outputs):
            if not 0 < o.value <= MAX_VALUE:
                raise Rejected("bad-value", "genesis value out of range")
        for i, o in enumerate(outputs):
            self.utxos[OutPoint(txid, i)] = o
        self.applied.add(txid)
        return txid

    # ------------------------------------------------------------ validation
    def validate(self, tx: Transaction) -> Receipt:
        if not tx.inputs:
            raise Rejected("no-inputs", "transaction has no inputs")
        if not tx.outputs:
            raise Rejected("no-outputs", "transaction has no outputs")
        # output ranges and overflow (checked before serialisation, which needs uint64 values)
        out_total = 0
        for i, o in enumerate(tx.outputs):
            if o.value <= 0:
                raise Rejected("bad-value", f"output {i} value {o.value} must be positive")
            if o.value > MAX_VALUE:
                raise Rejected("overflow", f"output {i} value {o.value} exceeds MAX_VALUE")
            out_total += o.value
            if out_total > MAX_VALUE:
                raise Rejected("overflow", "sum of outputs overflows int64")
        if tx.fee < 0:
            raise Rejected("bad-value", f"fee {tx.fee} is negative")
        if tx.fee > MAX_VALUE:
            raise Rejected("overflow", "fee exceeds MAX_VALUE")
        try:
            txid = tx.txid
        except TxFormatError as exc:
            raise Rejected("bad-format", str(exc)) from None
        if txid in self.applied:
            raise Rejected("duplicate-tx", f"transaction {txid[:16]}… was already accepted")
        seen = set()
        for i, txin in enumerate(tx.inputs):
            if txin.prev in seen:
                raise Rejected("duplicate-input", f"input {i} repeats outpoint {txin.prev} within one transaction")
            seen.add(txin.prev)
        # referenced outputs + authorisation
        in_total = 0
        for i, txin in enumerate(tx.inputs):
            utxo = self.utxos.get(txin.prev)
            if utxo is None:
                if txin.prev in self.spent_by:
                    raise Rejected("double-spend", f"input {i} outpoint {txin.prev} already spent by "
                                                   f"{self.spent_by[txin.prev][:16]}…")
                raise Rejected("missing-input", f"input {i} references nonexistent output {txin.prev}")
            self._check_authorisation(tx, i, txin, utxo)
            in_total += utxo.value
            if in_total > MAX_VALUE:
                raise Rejected("overflow", "sum of inputs overflows int64")
        if out_total > in_total:
            raise Rejected("value-creation", f"outputs {out_total} exceed inputs {in_total}")
        if in_total != out_total + tx.fee:
            raise Rejected("incorrect-change", f"inputs {in_total} != outputs {out_total} + declared fee {tx.fee} "
                                               f"(change is off by {in_total - out_total - tx.fee})")
        return Receipt(txid, tx.fee, in_total, out_total)

    @staticmethod
    def _check_authorisation(tx: Transaction, i: int, txin: TxIn, utxo: TxOut) -> None:
        try:
            pub_raw = bytes.fromhex(txin.pubkey)
            pub = keys.load_public(pub_raw)
        except (ValueError, keys.KeyError_):
            raise Rejected("bad-pubkey", f"input {i}: malformed public key") from None
        if pubkey_hash(pub_raw).hex() != utxo.pkh:
            raise Rejected("wrong-key", f"input {i}: public key does not match the p2pkh lock")
        try:
            keys.verify(pub, tx.sighash(i), bytes.fromhex(txin.signature))
        except (ValueError, keys.SignatureError) as exc:
            raise Rejected("bad-signature", f"input {i}: {exc}") from None

    # ------------------------------------------------------------ atomic update
    def apply(self, tx: Transaction) -> Receipt:
        rc = self.validate(tx)            # raises -> nothing below runs, state untouched
        new_utxos = dict(self.utxos)      # build the new state on the side ...
        for txin in tx.inputs:
            del new_utxos[txin.prev]
        for i, o in enumerate(tx.outputs):
            new_utxos[OutPoint(rc.txid, i)] = o
        self.utxos = new_utxos            # ... and swap it in with one assignment
        for txin in tx.inputs:
            self.spent_by[txin.prev] = rc.txid
        self.applied.add(rc.txid)
        return rc

    # ------------------------------------------------------------ queries
    def balance(self, pkh: str) -> int:
        return sum(o.value for o in self.utxos.values() if o.pkh == pkh)

    def utxos_for(self, pkh: str) -> list[tuple[OutPoint, TxOut]]:
        return [(op, o) for op, o in self.utxos.items() if o.pkh == pkh]

    def total(self) -> int:
        return sum(o.value for o in self.utxos.values())

    # ------------------------------------------------------------ persistence
    def to_dict(self) -> dict:
        return {"format": "utxo-snapshot-v1",
                "utxos": [{"txid": op.txid, "vout": op.vout, **o.to_dict()} for op, o in sorted(self.utxos.items())],
                "spent": [{"txid": op.txid, "vout": op.vout, "spent_by": t} for op, t in sorted(self.spent_by.items())],
                "applied": sorted(self.applied)}

    def state_hash(self) -> str:
        """Hash of the logical UTXO set only (order-independent, canonical)."""
        canon = json.dumps(self.to_dict()["utxos"], sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canon.encode()).hexdigest()

    def save(self, path: str) -> None:
        d = os.path.dirname(os.path.abspath(path))
        fd, tmp = tempfile.mkstemp(dir=d, prefix=".snapshot-")
        with os.fdopen(fd, "w") as fh:
            json.dump(self.to_dict(), fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.replace(tmp, path)  # atomic on POSIX: never a half-written snapshot

    @staticmethod
    def load(path: str) -> "Ledger":
        with open(path) as fh:
            d = json.load(fh)
        if d.get("format") != "utxo-snapshot-v1":
            raise ValueError("unknown snapshot format")
        L = Ledger()
        for u in d["utxos"]:
            L.utxos[OutPoint(u["txid"], u["vout"])] = TxOut(u["value"], u["lock"]["pkh"])
        for s in d["spent"]:
            L.spent_by[OutPoint(s["txid"], s["vout"])] = s["spent_by"]
        L.applied = set(d["applied"])
        return L
