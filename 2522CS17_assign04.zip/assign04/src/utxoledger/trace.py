"""Scripted scenario producing the accepted/rejected trace and the ledger snapshots.

Alice controls 40 + 70 units and pays Bob 85 with fee 2 (change 23); then every rejection
rule from the brief is exercised. For each attempt the UTXO-set hash is recorded before and
after, proving that a failed validation leaves state unchanged.
"""
from __future__ import annotations

import json
import os
from dataclasses import replace

from .ledger import Ledger, Rejected
from .tx import MAX_VALUE, OutPoint, Transaction, TxIn, TxOut
from .wallet import Wallet


def run_scenario(outdir: str = "docs", snapdir: str = "test_vectors") -> list[dict]:
    os.makedirs(outdir, exist_ok=True)
    os.makedirs(snapdir, exist_ok=True)
    alice, bob, carol = Wallet.generate("alice"), Wallet.generate("bob"), Wallet.generate("carol")
    names = {alice.pkh: "alice", bob.pkh: "bob", carol.pkh: "carol"}
    L = Ledger()
    g = L.add_genesis([TxOut(40, alice.pkh), TxOut(70, alice.pkh), TxOut(50, carol.pkh)])
    L.save(os.path.join(snapdir, "ledger_initial.json"))
    trace: list[dict] = []

    def attempt(label: str, tx: Transaction, expect: str):
        before = L.state_hash()
        try:
            rc = L.apply(tx)
            res = {"step": label, "result": "ACCEPTED", "txid": rc.txid, "fee": rc.fee,
                   "inputs": rc.inputs_total, "outputs": rc.outputs_total}
        except Rejected as r:
            res = {"step": label, "result": "REJECTED", "code": r.code, "reason": r.message}
        after = L.state_hash()
        res.update(expected=expect, state_before=before[:16], state_after=after[:16],
                   state_unchanged=(before == after),
                   balances={n: L.balance(p) for p, n in names.items()}, total=L.total())
        trace.append(res)
        return res

    # 1. the example payment ---------------------------------------------------
    pay = alice.build_payment(L, bob.pkh, 85, 2)
    attempt("Alice pays Bob 85 (fee 2) using 70+40, change 23", pay, "ACCEPTED")
    L.save(os.path.join(snapdir, "ledger_after_payment.json"))
    with open(os.path.join(snapdir, "alice_pays_bob_85_tx.json"), "w") as fh:
        json.dump(pay.to_dict(), fh, indent=2)

    # 2. same signed transaction again ----------------------------------------
    attempt("Submit the SAME signed transaction again", pay, "REJECTED duplicate-tx")

    # 3. a different transaction re-using an already consumed outpoint ----------
    re_spend = alice.sign(Transaction(1, (TxIn(OutPoint(g, 1)),), (TxOut(68, carol.pkh),), 2))
    attempt("Alice re-spends consumed output genesis:1", re_spend, "REJECTED double-spend")

    # 4. nonexistent input ------------------------------------------------------
    ghost = alice.sign(Transaction(1, (TxIn(OutPoint("ab" * 32, 0)),), (TxOut(5, bob.pkh),), 0))
    attempt("Input references an output that never existed", ghost, "REJECTED missing-input")

    change_op = OutPoint(pay.txid, 1)        # Alice's 23-unit change
    bob_op = OutPoint(pay.txid, 0)           # Bob's 85 units

    # 5. same outpoint twice inside one transaction ---------------------------
    dup = alice.sign(Transaction(1, (TxIn(change_op), TxIn(change_op)), (TxOut(45, bob.pkh),), 1))
    attempt("Same outpoint used twice in one transaction", dup, "REJECTED duplicate-input")

    # 6. authorisation failures -------------------------------------------------
    steal = bob.sign(Transaction(1, (TxIn(change_op),), (TxOut(23, bob.pkh),), 0))
    attempt("Bob tries to spend Alice's change with his own key", steal, "REJECTED wrong-key")
    good = alice.sign(Transaction(1, (TxIn(change_op),), (TxOut(20, carol.pkh), TxOut(2, alice.pkh)), 1))
    tampered = replace(good, outputs=(TxOut(22, carol.pkh),), fee=1)  # outputs edited after signing
    attempt("Outputs modified after Alice signed (sig no longer matches)", tampered, "REJECTED bad-signature")
    forged = good.with_witness([(alice.pubkey.hex(), "3006020101020101")])
    attempt("Garbage signature with Alice's public key", forged, "REJECTED bad-signature")

    # 7. value rules ------------------------------------------------------------
    # a negative value cannot be serialised (uint64), so it cannot be signed either: send it unsigned
    neg = Transaction(1, (TxIn(change_op, alice.pubkey.hex(), ""),), (TxOut(30, bob.pkh), TxOut(-8, alice.pkh)), 1)
    attempt("Negative output value (30 + -8)", neg, "REJECTED bad-value")
    over = alice.sign(Transaction(1, (TxIn(change_op),), (TxOut(MAX_VALUE, bob.pkh), TxOut(MAX_VALUE, bob.pkh)), 0))
    attempt("Outputs whose sum overflows int64", over, "REJECTED overflow")
    create = alice.sign(Transaction(1, (TxIn(change_op),), (TxOut(1000, alice.pkh),), 0))
    attempt("Excessive creation of value (23 in, 1000 out)", create, "REJECTED value-creation")
    wrong_change = alice.sign(Transaction(1, (TxIn(change_op),), (TxOut(10, bob.pkh), TxOut(5, alice.pkh)), 2))
    attempt("Incorrect change (23 in, 10 + 5 out, fee 2 -> 6 units unaccounted)", wrong_change, "REJECTED incorrect-change")

    # 8. a final valid transaction ---------------------------------------------
    b2c = bob.build_payment(L, carol.pkh, 30, 1)
    attempt("Bob pays Carol 30 (fee 1) from his 85, change 54", b2c, "ACCEPTED")
    L.save(os.path.join(snapdir, "ledger_final.json"))

    # 9. persistence round trip -------------------------------------------------
    reloaded = Ledger.load(os.path.join(snapdir, "ledger_final.json"))
    trace.append({"step": "Save + reload final snapshot", "result": "OK" if reloaded.state_hash() == L.state_hash() else "MISMATCH",
                  "state_before": L.state_hash()[:16], "state_after": reloaded.state_hash()[:16],
                  "state_unchanged": reloaded.state_hash() == L.state_hash(), "expected": "OK",
                  "balances": {n: reloaded.balance(p) for p, n in names.items()}, "total": reloaded.total()})

    with open(os.path.join(outdir, "trace.jsonl"), "w") as fh:
        for t in trace:
            fh.write(json.dumps(t) + "\n")
    with open(os.path.join(outdir, "transaction_trace.md"), "w") as fh:
        fh.write(render_markdown(trace, names, g))
    return trace


def render_markdown(trace, names, genesis_txid) -> str:
    rows = ["| # | attempt | result | reason code | precise reason | UTXO state hash before → after | unchanged | alice / bob / carol |",
            "|---:|---|---|---|---|---|:---:|---|"]
    for i, t in enumerate(trace, 1):
        b = t["balances"]
        reason = t.get("reason", f"txid {t['txid'][:16]}…, fee {t['fee']}" if t["result"] == "ACCEPTED" else "")
        rows.append(f"| {i} | {t['step']} | **{t['result']}** | `{t.get('code', '-')}` | {reason} | "
                    f"`{t['state_before']}` → `{t['state_after']}` | {'yes' if t['state_unchanged'] else 'changed'} | "
                    f"{b['alice']} / {b['bob']} / {b['carol']} |")
    ok = all((t["result"] == t["expected"].split()[0]) and (t["expected"].split()[1:] in ([], [t.get("code")]))
             for t in trace)
    return "\n".join([
        "# Transaction trace — UTXO ledger (Assignment 4)", "",
        "Student: Rudra Pratap Singh (2522CS17). Generated by `utxo trace` (keys are fresh each run, so txids differ between runs).", "",
        f"Genesis transaction `{genesis_txid[:16]}…` creates: alice 40 (vout 0), alice 70 (vout 1), carol 50 (vout 2). Total supply 160.", "",
        *rows, "",
        f"All outcomes matched expectations: **{ok}**. Total supply after the run: {trace[-1]['total']} "
        f"(160 minus fees 2 + 1 = 157).", "",
        "Every rejected attempt shows the same UTXO hash before and after: validation is complete before any state changes.",
    ]) + "\n"
