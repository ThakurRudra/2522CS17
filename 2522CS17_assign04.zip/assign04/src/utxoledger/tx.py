"""UTXO transaction model, canonical serialisation, txid and signature hashes (UTX-1).

Transaction JSON:
{
  "version": 1,
  "inputs":  [{"txid": "<64 hex>", "vout": 0, "pubkey": "<66 hex>", "signature": "<DER hex>"}],
  "outputs": [{"value": 85, "lock": {"type": "p2pkh", "pkh": "<40 hex>"}}],
  "fee": 2
}

Body bytes (everything except pubkey/signature), big-endian:
  "UTX1" | version u16 | n_in u16 | n_in x (txid 32 | vout u32)
         | n_out u16 | n_out x (value u64 | lock_type u8 (1 = p2pkh) | pkh 20) | fee u64
txid       = SHA256(body)                       -> signatures cannot change the txid (no malleability)
sighash(i) = SHA256("UTXO-SIGHASH-ALL" | i u16 | body)   -> each input signs the whole transaction
The explicit `fee` field lets the validator prove the change is correct:
  sum(inputs) == sum(outputs) + fee   must hold exactly.
"""
from __future__ import annotations

import hashlib
import re
import struct
from dataclasses import dataclass, field

MAGIC = b"UTX1"
SIGHASH_TAG = b"UTXO-SIGHASH-ALL"
MAX_VALUE = 2**63 - 1          # int64 ceiling: any single value or total above this is "overflow"
_H64 = re.compile(r"\A[0-9a-f]{64}\Z")
_H40 = re.compile(r"\A[0-9a-f]{40}\Z")
_HEX = re.compile(r"\A(?:[0-9a-f]{2})*\Z")


class TxFormatError(ValueError):
    pass


def _int(v, name, lo, hi):
    if not isinstance(v, int) or isinstance(v, bool):
        raise TxFormatError(f"{name} must be an integer")
    if not lo <= v <= hi:
        raise TxFormatError(f"{name}={v} out of range [{lo}, {hi}]")
    return v


@dataclass(frozen=True, order=True)
class OutPoint:
    txid: str
    vout: int

    def __str__(self):
        return f"{self.txid[:12]}…:{self.vout}"

    def key(self) -> str:
        return f"{self.txid}:{self.vout}"


@dataclass(frozen=True)
class TxOut:
    value: int
    pkh: str  # p2pkh lock: 20-byte pubkey hash, hex

    def to_dict(self):
        return {"value": self.value, "lock": {"type": "p2pkh", "pkh": self.pkh}}


@dataclass(frozen=True)
class TxIn:
    prev: OutPoint
    pubkey: str = ""
    signature: str = ""

    def to_dict(self):
        return {"txid": self.prev.txid, "vout": self.prev.vout, "pubkey": self.pubkey, "signature": self.signature}


@dataclass(frozen=True)
class Transaction:
    version: int
    inputs: tuple
    outputs: tuple
    fee: int
    coinbase: bool = field(default=False, compare=False)

    # ------------------------------------------------------------ parsing
    @staticmethod
    def from_dict(d: dict) -> "Transaction":
        """Structural parsing only (types, hex, sizes). Value rules live in the validator so
        that it can report precise reasons (negative value, overflow, ...)."""
        if not isinstance(d, dict) or set(d) != {"version", "inputs", "outputs", "fee"}:
            raise TxFormatError("transaction must have exactly version, inputs, outputs, fee")
        version = _int(d["version"], "version", 1, 1)
        if not isinstance(d["inputs"], list) or not isinstance(d["outputs"], list):
            raise TxFormatError("inputs and outputs must be lists")
        ins = []
        for i, x in enumerate(d["inputs"]):
            if not isinstance(x, dict) or set(x) != {"txid", "vout", "pubkey", "signature"}:
                raise TxFormatError(f"input {i}: needs exactly txid, vout, pubkey, signature")
            if not isinstance(x["txid"], str) or not _H64.match(x["txid"]):
                raise TxFormatError(f"input {i}: txid must be 64 lowercase hex")
            vout = _int(x["vout"], f"input {i} vout", 0, 2**32 - 1)
            for k in ("pubkey", "signature"):
                if not isinstance(x[k], str) or not _HEX.match(x[k]):
                    raise TxFormatError(f"input {i}: {k} must be lowercase hex")
            ins.append(TxIn(OutPoint(x["txid"], vout), x["pubkey"], x["signature"]))
        outs = []
        for i, o in enumerate(d["outputs"]):
            if not isinstance(o, dict) or set(o) != {"value", "lock"}:
                raise TxFormatError(f"output {i}: needs exactly value and lock")
            lock = o["lock"]
            if not isinstance(lock, dict) or lock.get("type") != "p2pkh" or set(lock) != {"type", "pkh"}:
                raise TxFormatError(f"output {i}: only p2pkh locks are supported")
            if not isinstance(lock["pkh"], str) or not _H40.match(lock["pkh"]):
                raise TxFormatError(f"output {i}: pkh must be 40 lowercase hex")
            v = o["value"]
            if not isinstance(v, int) or isinstance(v, bool):
                raise TxFormatError(f"output {i}: value must be an integer")
            outs.append(TxOut(v, lock["pkh"]))
        fee = d["fee"]
        if not isinstance(fee, int) or isinstance(fee, bool):
            raise TxFormatError("fee must be an integer")
        return Transaction(version, tuple(ins), tuple(outs), fee)

    def to_dict(self) -> dict:
        return {"version": self.version, "inputs": [i.to_dict() for i in self.inputs],
                "outputs": [o.to_dict() for o in self.outputs], "fee": self.fee}

    # ------------------------------------------------------------ bytes
    def body_bytes(self) -> bytes:
        """Raises TxFormatError if a value cannot be encoded (negative / > uint64)."""
        try:
            parts = [MAGIC, struct.pack(">HH", self.version, len(self.inputs))]
            for i in self.inputs:
                parts.append(bytes.fromhex(i.prev.txid) + struct.pack(">I", i.prev.vout))
            parts.append(struct.pack(">H", len(self.outputs)))
            for o in self.outputs:
                parts.append(struct.pack(">QB", o.value, 1) + bytes.fromhex(o.pkh))
            parts.append(struct.pack(">Q", self.fee))
        except struct.error as exc:
            raise TxFormatError(f"value not encodable as uint64 ({exc})") from None
        return b"".join(parts)

    @property
    def txid(self) -> str:
        return hashlib.sha256(self.body_bytes()).hexdigest()

    def sighash(self, index: int) -> bytes:
        return hashlib.sha256(SIGHASH_TAG + struct.pack(">H", index) + self.body_bytes()).digest()

    def with_witness(self, witnesses: list[tuple[str, str]]) -> "Transaction":
        ins = tuple(TxIn(i.prev, pk, sig) for i, (pk, sig) in zip(self.inputs, witnesses))
        return Transaction(self.version, ins, self.outputs, self.fee)
