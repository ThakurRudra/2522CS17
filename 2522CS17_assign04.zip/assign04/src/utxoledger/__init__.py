"""utxoledger - in-memory UTXO ledger, validator and wallet builder (Assignment 4)."""
__version__ = "1.0.0"
