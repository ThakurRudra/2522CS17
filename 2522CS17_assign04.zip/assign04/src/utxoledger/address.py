"""Address derivation: version byte + public-key hash + checksum, Base58Check encoded.

    pkh      = BLAKE2b-160(compressed_public_key)          (20 bytes, hashlib.blake2b digest_size=20)
    payload  = version_byte || pkh                          (21 bytes)
    checksum = SHA256(SHA256(payload))[0:4]                 (4 bytes)
    address  = Base58(payload || checksum)                  (25 bytes -> 33/34 characters)

Version bytes (one per network, so an address cannot silently cross networks):
    0x7f  course-testnet   -> addresses start with 't'
    0x00  mainnet          -> reserved; the wallet refuses to create or sign for it
"""
from __future__ import annotations

import hashlib

B58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_B58_INDEX = {c: i for i, c in enumerate(B58_ALPHABET)}

NETWORKS = {"course-testnet": 0x7F, "mainnet": 0x00}
VERSION_TO_NETWORK = {v: k for k, v in NETWORKS.items()}
DEFAULT_NETWORK = "course-testnet"


class AddressError(ValueError):
    pass


def b58encode(data: bytes) -> str:
    n = int.from_bytes(data, "big")
    out = []
    while n:
        n, r = divmod(n, 58)
        out.append(B58_ALPHABET[r])
    pad = len(data) - len(data.lstrip(b"\x00"))
    return "1" * pad + "".join(reversed(out))


def b58decode(s: str) -> bytes:
    if not s:
        raise AddressError("empty address")
    n = 0
    for c in s:
        if c not in _B58_INDEX:
            raise AddressError(f"malformed address: invalid Base58 character {c!r}")
        n = n * 58 + _B58_INDEX[c]
    body = n.to_bytes((n.bit_length() + 7) // 8, "big") if n else b""
    pad = len(s) - len(s.lstrip("1"))
    return b"\x00" * pad + body


def checksum(payload: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]


def pubkey_hash(pubkey33: bytes) -> bytes:
    return hashlib.blake2b(pubkey33, digest_size=20).digest()


def address_from_pubkey(pubkey33: bytes, network: str = DEFAULT_NETWORK) -> str:
    if network not in NETWORKS:
        raise AddressError(f"unknown network {network!r}")
    payload = bytes([NETWORKS[network]]) + pubkey_hash(pubkey33)
    return b58encode(payload + checksum(payload))


def decode_address(addr: str) -> tuple[str, bytes]:
    """Return (network, 21-byte payload). Raises on any malformation."""
    if not isinstance(addr, str):
        raise AddressError("address must be a string")
    raw = b58decode(addr)
    if len(raw) != 25:
        raise AddressError(f"malformed address: decodes to {len(raw)} bytes, expected 25")
    payload, chk = raw[:21], raw[21:]
    if checksum(payload) != chk:
        raise AddressError("invalid address checksum")
    version = payload[0]
    if version not in VERSION_TO_NETWORK:
        raise AddressError(f"unknown address version byte 0x{version:02x}")
    return VERSION_TO_NETWORK[version], payload
