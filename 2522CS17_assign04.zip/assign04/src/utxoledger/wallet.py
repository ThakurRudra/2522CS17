"""Wallet-side transaction builder with deterministic LARGEST-FIRST coin selection.

Coin selection strategy (documented, deterministic):
  1. Take the wallet's spendable UTXOs.
  2. Sort by value descending; ties broken by (txid, vout) ascending.
  3. Add coins in that order until  selected >= amount + fee.
  4. change = selected - amount - fee; a change output to the sender is added only if change > 0.
Largest-first minimises the number of inputs (smaller transactions), at the cost of
consolidating fewer small coins. The same wallet state always yields the same transaction.
"""
from __future__ import annotations

from dataclasses import dataclass

from . import keys
from .address import pubkey_hash
from .ledger import Ledger
from .tx import OutPoint, Transaction, TxIn, TxOut


class InsufficientFunds(Exception):
    pass


@dataclass
class Wallet:
    name: str
    private: object  # cryptography EC private key

    @property
    def pubkey(self) -> bytes:
        return keys.public_bytes(self.private.public_key())

    @property
    def pkh(self) -> str:
        return pubkey_hash(self.pubkey).hex()

    @staticmethod
    def generate(name: str) -> "Wallet":
        return Wallet(name, keys.generate_private_key())

    def select_coins(self, ledger: Ledger, target: int) -> list[tuple[OutPoint, TxOut]]:
        coins = sorted(ledger.utxos_for(self.pkh), key=lambda c: (-c[1].value, c[0].txid, c[0].vout))
        chosen, total = [], 0
        for c in coins:
            if total >= target:
                break
            chosen.append(c)
            total += c[1].value
        if total < target:
            raise InsufficientFunds(f"{self.name} has {total} spendable units, needs {target}")
        return chosen

    def build_payment(self, ledger: Ledger, to_pkh: str, amount: int, fee: int) -> Transaction:
        if amount <= 0 or fee < 0:
            raise ValueError("amount must be positive and fee non-negative")
        chosen = self.select_coins(ledger, amount + fee)
        selected = sum(o.value for _, o in chosen)
        change = selected - amount - fee
        outputs = [TxOut(amount, to_pkh)]
        if change > 0:
            outputs.append(TxOut(change, self.pkh))
        assert selected == amount + fee + change  # wallet-side change check
        unsigned = Transaction(1, tuple(TxIn(op) for op, _ in chosen), tuple(outputs), fee)
        return self.sign(unsigned)

    def sign(self, unsigned: Transaction) -> Transaction:
        wits = [(self.pubkey.hex(), keys.sign(self.private, unsigned.sighash(i)).hex())
                for i in range(len(unsigned.inputs))]
        return unsigned.with_witness(wits)
