"""Tests for the UTXO ledger, validator and wallet builder (Assignment 4)."""
import json
import os
import subprocess
import sys
from dataclasses import replace

import pytest

from utxoledger.ledger import Ledger, Rejected
from utxoledger.tx import MAX_VALUE, OutPoint, Transaction, TxFormatError, TxIn, TxOut
from utxoledger.wallet import InsufficientFunds, Wallet

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


@pytest.fixture
def world():
    alice, bob, carol = Wallet.generate("alice"), Wallet.generate("bob"), Wallet.generate("carol")
    L = Ledger()
    g = L.add_genesis([TxOut(40, alice.pkh), TxOut(70, alice.pkh), TxOut(50, carol.pkh)])
    return L, alice, bob, carol, g


def rejects(L, tx, code):
    before = L.state_hash(), dict(L.utxos), set(L.applied)
    with pytest.raises(Rejected) as e:
        L.apply(tx)
    assert e.value.code == code, e.value
    assert (L.state_hash(), dict(L.utxos), set(L.applied)) == before  # state unchanged
    return e.value


# ---------------------------------------------------------------- the example scenario
def test_alice_pays_bob_85_fee_2(world):
    L, alice, bob, _, _ = world
    tx = alice.build_payment(L, bob.pkh, 85, 2)
    assert [o.value for o in tx.outputs] == [85, 23] and len(tx.inputs) == 2
    rc = L.apply(tx)
    assert rc.fee == 2 and L.balance(bob.pkh) == 85 and L.balance(alice.pkh) == 23
    assert L.total() == 160 - 2


def test_same_signed_tx_twice_does_not_pay_twice(world):
    L, alice, bob, _, _ = world
    tx = alice.build_payment(L, bob.pkh, 85, 2)
    L.apply(tx)
    rejects(L, tx, "duplicate-tx")
    assert L.balance(bob.pkh) == 85


def test_largest_first_selection_is_deterministic(world):
    L, alice, bob, _, g = world
    t1 = alice.build_payment(L, bob.pkh, 50, 1)
    t2 = alice.build_payment(L, bob.pkh, 50, 1)
    assert [i.prev for i in t1.inputs] == [OutPoint(g, 1)]  # the 70 coin alone suffices
    assert t1.txid == t2.txid  # same state -> same transaction body
    assert [o.value for o in t1.outputs] == [50, 19]


def test_largest_first_uses_both_when_needed(world):
    L, alice, bob, _, g = world
    tx = alice.build_payment(L, bob.pkh, 85, 2)
    assert [i.prev.vout for i in tx.inputs] == [1, 0]  # 70 first, then 40


def test_no_change_output_when_exact(world):
    L, alice, bob, _, _ = world
    tx = alice.build_payment(L, bob.pkh, 108, 2)
    assert len(tx.outputs) == 1 and L.apply(tx).fee == 2


def test_insufficient_funds(world):
    L, alice, bob, _, _ = world
    with pytest.raises(InsufficientFunds):
        alice.build_payment(L, bob.pkh, 200, 1)


# ---------------------------------------------------------------- rejection rules
def test_reject_nonexistent_input(world):
    L, alice, bob, _, _ = world
    tx = alice.sign(Transaction(1, (TxIn(OutPoint("cd" * 32, 0)),), (TxOut(1, bob.pkh),), 0))
    rejects(L, tx, "missing-input")


def test_reject_nonexistent_vout_of_real_tx(world):
    L, alice, bob, _, g = world
    tx = alice.sign(Transaction(1, (TxIn(OutPoint(g, 7)),), (TxOut(1, bob.pkh),), 0))
    rejects(L, tx, "missing-input")


def test_reject_repeated_outpoint_in_one_tx(world):
    L, alice, bob, _, g = world
    tx = alice.sign(Transaction(1, (TxIn(OutPoint(g, 1)), TxIn(OutPoint(g, 1))), (TxOut(140, bob.pkh),), 0))
    rejects(L, tx, "duplicate-input")


def test_reject_second_spend_of_consumed_output(world):
    L, alice, bob, carol, g = world
    L.apply(alice.build_payment(L, bob.pkh, 85, 2))
    again = alice.sign(Transaction(1, (TxIn(OutPoint(g, 0)),), (TxOut(40, carol.pkh),), 0))
    e = rejects(L, again, "double-spend")
    assert "already spent" in e.message


def test_reject_wrong_key(world):
    L, alice, bob, _, g = world
    tx = bob.sign(Transaction(1, (TxIn(OutPoint(g, 0)),), (TxOut(40, bob.pkh),), 0))
    rejects(L, tx, "wrong-key")


def test_reject_bad_signature_after_tampering(world):
    L, alice, bob, carol, _ = world
    tx = alice.build_payment(L, bob.pkh, 85, 2)
    evil = replace(tx, outputs=(TxOut(85, carol.pkh), tx.outputs[1]))  # redirect payment, keep sigs
    rejects(L, evil, "bad-signature")


def test_reject_signature_swapped_between_inputs(world):
    L, alice, bob, _, _ = world
    tx = alice.build_payment(L, bob.pkh, 85, 2)
    w = [(i.pubkey, i.signature) for i in tx.inputs]
    rejects(L, tx.with_witness(list(reversed(w))), "bad-signature")  # sighash commits to input index


def test_reject_malformed_pubkey(world):
    L, alice, bob, _, g = world
    tx = alice.sign(Transaction(1, (TxIn(OutPoint(g, 0)),), (TxOut(40, bob.pkh),), 0))
    rejects(L, tx.with_witness([("05" + "11" * 32, tx.inputs[0].signature)]), "bad-pubkey")


@pytest.mark.parametrize("value", [0, -1, -40])
def test_reject_non_positive_output(world, value):
    L, alice, bob, _, g = world
    tx = Transaction(1, (TxIn(OutPoint(g, 0), alice.pubkey.hex(), ""),), (TxOut(value, bob.pkh),), 0)
    rejects(L, tx, "bad-value")


def test_reject_single_output_above_max(world):
    L, alice, bob, _, g = world
    tx = Transaction(1, (TxIn(OutPoint(g, 0), alice.pubkey.hex(), ""),), (TxOut(MAX_VALUE + 1, bob.pkh),), 0)
    rejects(L, tx, "overflow")


def test_reject_sum_overflow(world):
    L, alice, bob, _, g = world
    tx = alice.sign(Transaction(1, (TxIn(OutPoint(g, 0)),), (TxOut(MAX_VALUE, bob.pkh), TxOut(MAX_VALUE, bob.pkh)), 0))
    rejects(L, tx, "overflow")


def test_reject_negative_fee(world):
    L, alice, bob, _, g = world
    tx = Transaction(1, (TxIn(OutPoint(g, 0), alice.pubkey.hex(), ""),), (TxOut(41, bob.pkh),), -1)
    rejects(L, tx, "bad-value")


def test_reject_value_creation(world):
    L, alice, bob, _, g = world
    tx = alice.sign(Transaction(1, (TxIn(OutPoint(g, 0)),), (TxOut(41, bob.pkh),), 0))
    rejects(L, tx, "value-creation")


@pytest.mark.parametrize("change", [20, 25, 0])
def test_reject_incorrect_change(world, change):
    L, alice, bob, _, g = world
    outs = (TxOut(85, bob.pkh),) + ((TxOut(change, alice.pkh),) if change else ())
    tx = alice.sign(Transaction(1, (TxIn(OutPoint(g, 1)), TxIn(OutPoint(g, 0))), outs, 2))
    rejects(L, tx, "value-creation" if 85 + change > 110 else "incorrect-change")


def test_reject_empty_inputs_and_outputs(world):
    L, alice, bob, _, g = world
    rejects(L, Transaction(1, (), (TxOut(1, bob.pkh),), 0), "no-inputs")
    rejects(L, Transaction(1, (TxIn(OutPoint(g, 0)),), (), 40), "no-outputs")


def test_failure_in_last_input_leaves_first_unspent(world):
    """Atomicity: input 0 is valid, input 1 is invalid -> input 0 must remain unspent."""
    L, alice, bob, carol, g = world
    tx = alice.sign(Transaction(1, (TxIn(OutPoint(g, 0)), TxIn(OutPoint(g, 2))), (TxOut(89, bob.pkh),), 1))
    rejects(L, tx, "wrong-key")  # g:2 belongs to carol
    assert OutPoint(g, 0) in L.utxos


# ---------------------------------------------------------------- txid and parsing
def test_txid_independent_of_signatures(world):
    L, alice, bob, _, _ = world
    tx = alice.build_payment(L, bob.pkh, 85, 2)
    resigned = alice.sign(replace(tx, inputs=tuple(TxIn(i.prev) for i in tx.inputs)))
    assert resigned.txid == tx.txid  # ECDSA is randomised but the txid is not affected


def test_json_roundtrip_and_strict_parsing(world):
    L, alice, bob, _, _ = world
    tx = alice.build_payment(L, bob.pkh, 85, 2)
    back = Transaction.from_dict(json.loads(json.dumps(tx.to_dict())))
    assert back == tx and back.txid == tx.txid
    d = tx.to_dict(); d["outputs"][0]["value"] = 85.0
    with pytest.raises(TxFormatError):
        Transaction.from_dict(d)
    d = tx.to_dict(); d["extra"] = 1
    with pytest.raises(TxFormatError):
        Transaction.from_dict(d)


# ---------------------------------------------------------------- persistence
def test_persist_and_reload_identical(world, tmp_path):
    L, alice, bob, _, _ = world
    L.apply(alice.build_payment(L, bob.pkh, 85, 2))
    p = tmp_path / "ledger.json"
    L.save(str(p))
    R = Ledger.load(str(p))
    assert R.utxos == L.utxos and R.state_hash() == L.state_hash()
    assert R.spent_by == L.spent_by and R.applied == L.applied
    R.save(str(tmp_path / "again.json"))
    assert (tmp_path / "again.json").read_text() == p.read_text()  # byte-identical snapshot


def test_reloaded_ledger_still_rejects_replay(world, tmp_path):
    L, alice, bob, _, _ = world
    tx = alice.build_payment(L, bob.pkh, 85, 2)
    L.apply(tx)
    L.save(str(tmp_path / "l.json"))
    rejects(Ledger.load(str(tmp_path / "l.json")), tx, "duplicate-tx")


def test_trace_scenario_all_expected(tmp_path):
    from utxoledger.trace import run_scenario
    tr = run_scenario(str(tmp_path / "docs"), str(tmp_path / "snap"))
    for t in tr:
        exp = t["expected"].split()
        assert t["result"] == exp[0] and (len(exp) == 1 or t["code"] == exp[1]), t
        if t["result"] == "REJECTED":
            assert t["state_unchanged"]
    assert (tmp_path / "docs" / "transaction_trace.md").exists()


def test_cli_flow(tmp_path):
    env = dict(os.environ, PYTHONPATH=os.path.join(ROOT, "src"))
    run = lambda *a: subprocess.run([sys.executable, "-m", "utxoledger", *a], cwd=tmp_path, env=env,
                                    capture_output=True, text=True)
    assert run("init", "--ledger", "L.json").returncode == 0
    assert run("pay", "--ledger", "L.json", "--from", "alice", "--to", "bob", "--amount", "85", "--fee", "2",
               "--out", "tx.json").returncode == 0
    assert run("submit", "--ledger", "L.json", "--tx", "tx.json").returncode == 0
    r = run("submit", "--ledger", "L.json", "--tx", "tx.json")
    assert r.returncode == 1 and "duplicate-tx" in r.stderr
    assert "balance bob    85" in run("show", "--ledger", "L.json").stdout
