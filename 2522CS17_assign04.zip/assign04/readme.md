# Assignment 4 — A UTXO Ledger and Transaction Validator (`utxo`)

**Student:** Rudra Pratap Singh · **Roll:** 2522CS17 · **Course:** Blockchain (Dr. Mayank Agarwal), IIT Patna

In-memory UTXO ledger with pay-to-public-key-hash outputs, an all-or-nothing validator,
a wallet-side builder with deterministic coin selection, and JSON persistence.
Keys and addresses reuse the Assignment 3 design (secp256k1 via `cryptography`, BLAKE2b-160 pubkey hash).

## How to run
```bash
cd assign04
pip install -e .          # installs the `utxo` command
pip install -r requirements.txt
pytest -v                 # 32 tests
utxo trace                # Alice/Bob scenario -> docs/transaction_trace.md, test_vectors/ledger_*.json
```
Step by step:
```bash
utxo init --ledger L.json                       # genesis: alice 40 + 70, carol 50 (TEST-ONLY keys in wallets/)
utxo pay --ledger L.json --from alice --to bob --amount 85 --fee 2 --out tx.json
utxo submit --ledger L.json --tx tx.json        # ACCEPTED
utxo submit --ledger L.json --tx tx.json        # REJECTED duplicate-tx (Bob is not paid twice)
utxo show --ledger L.json
```
Colab: `notebook/Assignment04_utxo_Colab.ipynb` → Run all.

## Model (UTX-1)
* **Outpoint** = `txid + output_index` · **Output** = integer `value` + lock `{"type":"p2pkh","pkh":<20-byte hash>}`
* **Input** = outpoint + unlocking data (`pubkey`, `signature`).
* **P2PKH:** the input's public key must hash (BLAKE2b-160) to the output's `pkh`, and its signature must verify over `sighash(i)`.
* **txid** = `SHA256(body)` where `body` is the canonical binary serialisation **without** signatures
  (`"UTX1" | version | inputs (txid, vout) | outputs (value u64, type, pkh) | fee u64`), so the txid cannot be malleated.
* **sighash(i)** = `SHA256("UTXO-SIGHASH-ALL" | i | body)` — every input commits to all inputs, all outputs, the fee and its own index.
* **Explicit fee:** the validator requires `Σinputs = Σoutputs + fee` exactly, which makes an incorrect change output detectable.

## Validation rules (reason codes)
`no-inputs`, `no-outputs`, `bad-value` (≤ 0 or negative fee), `overflow` (value or running sum > 2⁶³−1),
`duplicate-tx`, `duplicate-input`, `missing-input`, `double-spend`, `bad-pubkey`, `wrong-key`, `bad-signature`,
`value-creation` (Σout > Σin), `incorrect-change` (Σin ≠ Σout + fee).
`Ledger.apply` validates everything first, builds the new UTXO map on the side and swaps it in with one assignment;
a rejection therefore leaves the state untouched (the trace prints the UTXO-set hash before and after every attempt).

## Coin selection
**Largest-first**, deterministic: sort spendable UTXOs by value descending, ties by `(txid, vout)`;
take coins until `selected ≥ amount + fee`; change = `selected − amount − fee` back to the sender (omitted if 0).
For the example, Alice's 70 and 40 are both needed: outputs Bob 85, Alice 23, fee 2.

## Deliverables
* Validator `src/utxoledger/ledger.py` · transaction model `tx.py` · wallet builder `wallet.py` · trace `trace.py` · CLI `cli.py`
* Tests: `tests/test_utxo_ledger.py`
* Snapshots: `test_vectors/ledger_initial.json`, `ledger_after_payment.json`, `ledger_final.json`, `alice_pays_bob_85_tx.json`
* Trace: `docs/transaction_trace.md` (+ `docs/trace.jsonl`)

Video demo: *(add the unlisted YouTube link here)*
